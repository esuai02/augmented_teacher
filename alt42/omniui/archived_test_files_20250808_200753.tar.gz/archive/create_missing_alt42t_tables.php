<?php
header('Content-Type: text/html; charset=utf-8');

include_once("/home/moodle/public_html/moodle/config.php"); 
global $DB;
require_login();

// 관리자 권한 확인
$context = context_system::instance();
if (!has_capability('moodle/site:config', $context)) {
    echo "<p style='color:red'>관리자 권한이 필요합니다.</p>";
    exit;
}

$dbman = $DB->get_manager();

echo "<h2>누락된 테이블 생성 중...</h2>";

// 1. alt42t_users 테이블
$table = new xmldb_table('alt42t_users');
if (!$dbman->table_exists($table)) {
    echo "<p>alt42t_users 테이블 생성 중...</p>";
    
    $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE);
    $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL);
    $table->add_field('username', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL);
    $table->add_field('email', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL);
    $table->add_field('school', XMLDB_TYPE_CHAR, '255');
    $table->add_field('grade', XMLDB_TYPE_CHAR, '50');
    $table->add_field('created_at', XMLDB_TYPE_DATETIME);
    $table->add_field('updated_at', XMLDB_TYPE_DATETIME);
    
    $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
    $table->add_key('userid_fk', XMLDB_KEY_FOREIGN, array('userid'), 'user', array('id'));
    $table->add_index('userid_idx', XMLDB_INDEX_UNIQUE, array('userid'));
    
    try {
        $dbman->create_table($table);
        echo "<p style='color:green'>✓ alt42t_users 테이블 생성 완료</p>";
    } catch (Exception $e) {
        echo "<p style='color:red'>✗ alt42t_users 테이블 생성 실패: " . $e->getMessage() . "</p>";
    }
} else {
    echo "<p>alt42t_users 테이블은 이미 존재합니다.</p>";
}

// 2. alt42t_exams 테이블
$table = new xmldb_table('alt42t_exams');
if (!$dbman->table_exists($table)) {
    echo "<p>alt42t_exams 테이블 생성 중...</p>";
    
    $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE);
    $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL);
    $table->add_field('exam_name', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL);
    $table->add_field('start_date', XMLDB_TYPE_DATE);
    $table->add_field('end_date', XMLDB_TYPE_DATE);
    $table->add_field('status', XMLDB_TYPE_CHAR, '50');
    $table->add_field('created_at', XMLDB_TYPE_DATETIME);
    $table->add_field('updated_at', XMLDB_TYPE_DATETIME);
    
    $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
    $table->add_key('userid_fk', XMLDB_KEY_FOREIGN, array('userid'), 'user', array('id'));
    $table->add_index('userid_idx', XMLDB_INDEX_NOTUNIQUE, array('userid'));
    
    try {
        $dbman->create_table($table);
        echo "<p style='color:green'>✓ alt42t_exams 테이블 생성 완료</p>";
    } catch (Exception $e) {
        echo "<p style='color:red'>✗ alt42t_exams 테이블 생성 실패: " . $e->getMessage() . "</p>";
    }
} else {
    echo "<p>alt42t_exams 테이블은 이미 존재합니다.</p>";
}

// 3. alt42t_exam_dates 테이블
$table = new xmldb_table('alt42t_exam_dates');
if (!$dbman->table_exists($table)) {
    echo "<p>alt42t_exam_dates 테이블 생성 중...</p>";
    
    $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE);
    $table->add_field('exam_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL);
    $table->add_field('subject', XMLDB_TYPE_CHAR, '100', null, XMLDB_NOTNULL);
    $table->add_field('exam_date', XMLDB_TYPE_DATE, null, null, XMLDB_NOTNULL);
    $table->add_field('exam_time', XMLDB_TYPE_CHAR, '50');
    $table->add_field('created_at', XMLDB_TYPE_DATETIME);
    $table->add_field('updated_at', XMLDB_TYPE_DATETIME);
    
    $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
    $table->add_key('exam_fk', XMLDB_KEY_FOREIGN, array('exam_id'), 'alt42t_exams', array('id'));
    $table->add_index('exam_idx', XMLDB_INDEX_NOTUNIQUE, array('exam_id'));
    
    try {
        $dbman->create_table($table);
        echo "<p style='color:green'>✓ alt42t_exam_dates 테이블 생성 완료</p>";
    } catch (Exception $e) {
        echo "<p style='color:red'>✗ alt42t_exam_dates 테이블 생성 실패: " . $e->getMessage() . "</p>";
    }
} else {
    echo "<p>alt42t_exam_dates 테이블은 이미 존재합니다.</p>";
}

// 4. alt42t_exam_resources 테이블
$table = new xmldb_table('alt42t_exam_resources');
if (!$dbman->table_exists($table)) {
    echo "<p>alt42t_exam_resources 테이블 생성 중...</p>";
    
    $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE);
    $table->add_field('exam_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL);
    $table->add_field('resource_type', XMLDB_TYPE_CHAR, '50', null, XMLDB_NOTNULL);
    $table->add_field('resource_path', XMLDB_TYPE_TEXT);
    $table->add_field('resource_name', XMLDB_TYPE_CHAR, '255');
    $table->add_field('created_at', XMLDB_TYPE_DATETIME);
    $table->add_field('updated_at', XMLDB_TYPE_DATETIME);
    
    $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
    $table->add_key('exam_fk', XMLDB_KEY_FOREIGN, array('exam_id'), 'alt42t_exams', array('id'));
    $table->add_index('exam_idx', XMLDB_INDEX_NOTUNIQUE, array('exam_id'));
    
    try {
        $dbman->create_table($table);
        echo "<p style='color:green'>✓ alt42t_exam_resources 테이블 생성 완료</p>";
    } catch (Exception $e) {
        echo "<p style='color:red'>✗ alt42t_exam_resources 테이블 생성 실패: " . $e->getMessage() . "</p>";
    }
} else {
    echo "<p>alt42t_exam_resources 테이블은 이미 존재합니다.</p>";
}

// 5. alt42t_study_status 테이블
$table = new xmldb_table('alt42t_study_status');
if (!$dbman->table_exists($table)) {
    echo "<p>alt42t_study_status 테이블 생성 중...</p>";
    
    $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE);
    $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL);
    $table->add_field('status', XMLDB_TYPE_CHAR, '50');
    $table->add_field('last_active', XMLDB_TYPE_DATETIME);
    $table->add_field('created_at', XMLDB_TYPE_DATETIME);
    $table->add_field('updated_at', XMLDB_TYPE_DATETIME);
    
    $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
    $table->add_key('userid_fk', XMLDB_KEY_FOREIGN, array('userid'), 'user', array('id'));
    $table->add_index('userid_idx', XMLDB_INDEX_UNIQUE, array('userid'));
    
    try {
        $dbman->create_table($table);
        echo "<p style='color:green'>✓ alt42t_study_status 테이블 생성 완료</p>";
    } catch (Exception $e) {
        echo "<p style='color:red'>✗ alt42t_study_status 테이블 생성 실패: " . $e->getMessage() . "</p>";
    }
} else {
    echo "<p>alt42t_study_status 테이블은 이미 존재합니다.</p>";
}

// 6. alt42t_aggregated_resources 테이블
$table = new xmldb_table('alt42t_aggregated_resources');
if (!$dbman->table_exists($table)) {
    echo "<p>alt42t_aggregated_resources 테이블 생성 중...</p>";
    
    $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE);
    $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL);
    $table->add_field('resource_type', XMLDB_TYPE_CHAR, '50');
    $table->add_field('resource_data', XMLDB_TYPE_TEXT);
    $table->add_field('created_at', XMLDB_TYPE_DATETIME);
    $table->add_field('updated_at', XMLDB_TYPE_DATETIME);
    
    $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
    $table->add_key('userid_fk', XMLDB_KEY_FOREIGN, array('userid'), 'user', array('id'));
    $table->add_index('userid_idx', XMLDB_INDEX_NOTUNIQUE, array('userid'));
    
    try {
        $dbman->create_table($table);
        echo "<p style='color:green'>✓ alt42t_aggregated_resources 테이블 생성 완료</p>";
    } catch (Exception $e) {
        echo "<p style='color:red'>✗ alt42t_aggregated_resources 테이블 생성 실패: " . $e->getMessage() . "</p>";
    }
} else {
    echo "<p>alt42t_aggregated_resources 테이블은 이미 존재합니다.</p>";
}

echo "<h2>테이블 생성 작업 완료</h2>";
echo "<p><a href='check_alt42t_tables.php'>테이블 확인 페이지로 돌아가기</a></p>";
?>