-- 알림 테이블 생성
CREATE TABLE IF NOT EXISTS mdl_alt42t_notifications (
    notification_id INT AUTO_INCREMENT PRIMARY KEY,
    exam_id INT NOT NULL,
    user_id INT NOT NULL,
    notification_type VARCHAR(50) DEFAULT 'resource_update',
    message TEXT NOT NULL,
    resource_type VARCHAR(20) DEFAULT NULL, -- 'file' or 'tip'
    resource_id INT DEFAULT NULL,
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    read_at TIMESTAMP NULL DEFAULT NULL,
    
    INDEX idx_exam_id (exam_id),
    INDEX idx_user_id (user_id),
    INDEX idx_is_read (is_read),
    INDEX idx_created_at (created_at),
    
    FOREIGN KEY (exam_id) REFERENCES mdl_alt42t_exams(exam_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES mdl_alt42t_users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 알림 설정 테이블 (선택사항)
CREATE TABLE IF NOT EXISTS mdl_alt42t_notification_settings (
    setting_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    receive_file_updates TINYINT(1) DEFAULT 1,
    receive_tip_updates TINYINT(1) DEFAULT 1,
    last_checked TIMESTAMP NULL DEFAULT NULL,
    
    FOREIGN KEY (user_id) REFERENCES mdl_alt42t_users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;