<?php
require_once('/home/moodle/public_html/moodle/config.php');
require_once($CFG->libdir.'/adminlib.php');

// 관리자 권한 확인
require_login();
require_capability('moodle/site:config', context_system::instance());

global $DB;

// 테이블 이름 (mdl_ 접두사 제외)
$tablename = 'alt42t_exam_user_info';
  
// 테이블이 이미 존재하는지 확인
$dbman = $DB->get_manager();
$table = new xmldb_table($tablename);
  
if ($dbman->table_exists($table)) {
    echo "테이블 '$tablename'이(가) 이미 존재합니다.<br>";
} else {
    // 테이블 구조 정의
    $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
    $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('school', XMLDB_TYPE_CHAR, '255', null, null, null, null);
    $table->add_field('grade', XMLDB_TYPE_CHAR, '50', null, null, null, null);
    $table->add_field('exam_type', XMLDB_TYPE_CHAR, '100', null, null, null, null);
    $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);

    // 키 추가
    $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
    $table->add_key('userid_fk', XMLDB_KEY_FOREIGN, array('userid'), 'user', array('id'));

    // 테이블 생성
    $dbman->create_table($table);
    
    echo "테이블 '$tablename'이(가) 성공적으로 생성되었습니다.<br>";
    echo "생성된 필드:<br>";
    echo "- id (primary key)<br>";
    echo "- userid (외래키, user 테이블 참조)<br>";
    echo "- school (학교명)<br>";
    echo "- grade (학년)<br>";
    echo "- exam_type (시험 유형)<br>";
    echo "- timecreated (생성 시간)<br>";
    echo "- timemodified (수정 시간)<br>";
}
?>