<?php
header('Content-Type: text/html; charset=utf-8');

include_once("/home/moodle/public_html/moodle/config.php"); 
global $DB;
require_login();

echo "<h1>mdl_alt42t 테이블 확인</h1>";

// 확인할 테이블 목록
$tables = [
    'alt42t_aggregated_resources',
    'alt42t_exams',
    'alt42t_exam_dates',
    'alt42t_exam_resources',
    'alt42t_exam_user_info',
    'alt42t_study_status',
    'alt42t_users'
];

$dbman = $DB->get_manager();

foreach ($tables as $tablename) {
    echo "<h2>테이블: mdl_{$tablename}</h2>";
    
    $table = new xmldb_table($tablename);
    
    if ($dbman->table_exists($table)) {
        echo "<p style='color:green'>✓ 테이블이 존재합니다</p>";
        
        // 테이블 구조 확인
        try {
            $columns = $DB->get_columns($tablename);
            echo "<h3>컬럼 정보:</h3>";
            echo "<table border='1' style='border-collapse: collapse;'>";
            echo "<tr><th>컬럼명</th><th>타입</th><th>Null 허용</th><th>기본값</th></tr>";
            
            foreach ($columns as $column) {
                echo "<tr>";
                echo "<td>{$column->name}</td>";
                echo "<td>{$column->type}</td>";
                echo "<td>" . ($column->not_null ? 'NO' : 'YES') . "</td>";
                echo "<td>" . ($column->has_default ? $column->default_value : '-') . "</td>";
                echo "</tr>";
            }
            echo "</table>";
            
            // 데이터 개수 확인
            $count = $DB->count_records($tablename);
            echo "<p>총 레코드 수: {$count}</p>";
            
            // 샘플 데이터 (최대 3개)
            if ($count > 0) {
                $records = $DB->get_records($tablename, array(), 'id DESC', '*', 0, 3);
                echo "<h3>최근 데이터 (최대 3개):</h3>";
                echo "<pre>";
                foreach ($records as $record) {
                    print_r($record);
                    echo "\n---\n";
                }
                echo "</pre>";
            }
            
        } catch (Exception $e) {
            echo "<p style='color:red'>테이블 정보 조회 실패: " . $e->getMessage() . "</p>";
        }
    } else {
        echo "<p style='color:red'>✗ 테이블이 존재하지 않습니다</p>";
        echo "<p>테이블을 생성해야 합니다.</p>";
    }
    
    echo "<hr>";
}

// 테이블 생성 스크립트 제공
echo "<h2>누락된 테이블 생성하기</h2>";
?>

<button onclick="createMissingTables()">누락된 테이블 생성</button>
<div id="create-result"></div>

<script>
function createMissingTables() {
    if (!confirm('누락된 테이블을 생성하시겠습니까?')) {
        return;
    }
    
    fetch('create_missing_alt42t_tables.php')
        .then(response => response.text())
        .then(result => {
            document.getElementById('create-result').innerHTML = result;
        })
        .catch(error => {
            document.getElementById('create-result').innerHTML = 
                '<p style="color:red">오류: ' + error + '</p>';
        });
}
</script>