<?php
header('Content-Type: text/html; charset=utf-8');

include_once("/home/moodle/public_html/moodle/config.php"); 
global $DB, $USER;
require_login();
?>
<!DOCTYPE html>
<html>
<head>
    <title>ALT42 테이블 전체 확인</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .success { color: green; }
        .error { color: red; }
        .warning { color: orange; }
        table { border-collapse: collapse; margin: 10px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .section { margin: 20px 0; padding: 20px; border: 1px solid #ddd; background: #f9f9f9; }
    </style>
</head>
<body>
    <h1>ALT42 전체 테이블 확인</h1>
    
    <?php
    $tables = [
        'alt42t_users' => '사용자 기본 정보 (학교, 학년)',
        'alt42t_exams' => '시험 정의 (학교별/학년별/시험종류별)',
        'alt42t_exam_dates' => '시험 일정 (시작일, 종료일, 수학시험일)',
        'alt42t_exam_user_info' => '사용자별 시험 정보 (통합)',
        'alt42t_study_status' => '학습 상태 (개념공부/복습/유형공부)',
        'alt42t_exam_resources' => '시험 자료',
        'alt42t_aggregated_resources' => '집계된 자료'
    ];
    
    $dbman = $DB->get_manager();
    $missing_tables = [];
    
    foreach ($tables as $tablename => $description) {
        echo "<div class='section'>";
        echo "<h2>$tablename - $description</h2>";
        
        $table = new xmldb_table($tablename);
        
        if ($dbman->table_exists($table)) {
            echo "<p class='success'>✓ 테이블이 존재합니다.</p>";
            
            // 레코드 수 확인
            $count = $DB->count_records($tablename);
            echo "<p>레코드 수: $count</p>";
            
            // 컬럼 구조 확인
            $columns = $DB->get_columns($tablename);
            echo "<table>";
            echo "<tr><th>컬럼명</th><th>타입</th><th>NULL 허용</th></tr>";
            
            foreach ($columns as $name => $info) {
                $important = false;
                if (in_array($name, ['school_name', 'grade', 'exam_type', 'start_date', 'end_date', 'math_date', 'status', 'exam_scope'])) {
                    $important = true;
                }
                
                echo "<tr" . ($important ? " style='background-color: #ffffcc;'" : "") . ">";
                echo "<td>" . ($important ? "<strong>$name</strong>" : $name) . "</td>";
                echo "<td>{$info->type}</td>";
                echo "<td>" . ($info->not_null ? 'NO' : 'YES') . "</td>";
                echo "</tr>";
            }
            echo "</table>";
            
            // 현재 사용자 데이터 확인
            if (in_array($tablename, ['alt42t_users', 'alt42t_exam_user_info'])) {
                $user_data = $DB->get_record($tablename, array('userid' => $USER->id));
                if ($user_data) {
                    echo "<p class='success'>현재 사용자 데이터가 있습니다:</p>";
                    echo "<pre>" . print_r($user_data, true) . "</pre>";
                } else {
                    echo "<p class='warning'>현재 사용자 데이터가 없습니다.</p>";
                }
            }
            
        } else {
            echo "<p class='error'>✗ 테이블이 존재하지 않습니다!</p>";
            $missing_tables[] = $tablename;
        }
        
        echo "</div>";
    }
    
    if (!empty($missing_tables)) {
        echo "<div class='section' style='background-color: #ffe6e6;'>";
        echo "<h2>누락된 테이블</h2>";
        echo "<p class='error'>다음 테이블들이 누락되었습니다:</p>";
        echo "<ul>";
        foreach ($missing_tables as $table) {
            echo "<li>$table</li>";
        }
        echo "</ul>";
        echo "<p>create_alt42_tables.php 또는 create_alt42_tables.sql을 실행하여 테이블을 생성하세요.</p>";
        echo "</div>";
    }
    
    // 데이터 관계 확인
    echo "<div class='section'>";
    echo "<h2>데이터 저장 순서</h2>";
    echo "<ol>";
    echo "<li><strong>alt42t_users</strong> - 사용자 등록 (userid, school_name, grade)</li>";
    echo "<li><strong>alt42t_exams</strong> - 시험 정의 (school_name, grade, exam_type)</li>";
    echo "<li><strong>alt42t_exam_dates</strong> - 시험 일정 (exam_id, user_id 참조)</li>";
    echo "<li><strong>alt42t_study_status</strong> - 학습 상태 (exam_id, user_id 참조)</li>";
    echo "</ol>";
    echo "</div>";
    ?>
</body>
</html>