<?php
require_once('/home/moodle/public_html/moodle/config.php');
require_login();

global $DB;

// 관리자 권한 체크
$context = context_system::instance();
require_capability('moodle/site:config', $context);

echo "<h2>alt42t 테이블 구조 확인</h2>";

// 확인할 테이블 목록
$tables = [
    'alt42t_exam_user_info',
    'alt42t_users', 
    'alt42t_exams',
    'alt42t_exam_dates',
    'alt42t_exam_resources',
    'alt42t_study_status',
    'alt42t_aggregated_resources'
];

$dbman = $DB->get_manager();

foreach ($tables as $table) {
    echo "<h3>테이블: mdl_$table</h3>";
    
    $table_obj = new xmldb_table($table);
    if ($dbman->table_exists($table_obj)) {
        echo "<p style='color:green;'>✓ 테이블 존재</p>";
        
        // 컬럼 정보 출력
        try {
            $columns = $DB->get_columns($table);
            echo "<table border='1' style='border-collapse: collapse;'>";
            echo "<tr><th>컬럼명</th><th>타입</th><th>Null 허용</th><th>기본값</th></tr>";
            
            foreach ($columns as $column) {
                echo "<tr>";
                echo "<td>{$column->name}</td>";
                echo "<td>{$column->type}</td>";
                echo "<td>" . ($column->not_null ? 'NO' : 'YES') . "</td>";
                echo "<td>" . ($column->has_default ? $column->default_value : '-') . "</td>";
                echo "</tr>";
            }
            echo "</table><br>";
            
            // 레코드 수 확인
            $count = $DB->count_records($table);
            echo "<p>총 레코드 수: $count</p>";
            
        } catch (Exception $e) {
            echo "<p style='color:red;'>컬럼 정보 가져오기 실패: " . $e->getMessage() . "</p>";
        }
        
    } else {
        echo "<p style='color:red;'>✗ 테이블이 존재하지 않습니다!</p>";
    }
    
    echo "<hr>";
}

// 현재 사용자의 데이터 확인
echo "<h2>현재 사용자(ID: {$USER->id})의 exam_user_info 데이터</h2>";
try {
    $user_data = $DB->get_record('alt42t_exam_user_info', ['userid' => $USER->id]);
    if ($user_data) {
        echo "<pre>";
        print_r($user_data);
        echo "</pre>";
    } else {
        echo "<p style='color:orange;'>데이터가 없습니다.</p>";
    }
} catch (Exception $e) {
    echo "<p style='color:red;'>오류: " . $e->getMessage() . "</p>";
}
?>