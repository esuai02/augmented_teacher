<?php
header('Content-Type: text/plain; charset=utf-8');

include_once("/home/moodle/public_html/moodle/config.php"); 
global $DB, $USER;
require_login();

echo "=== ALT42 테이블 확인 ===\n\n";

$tables = [
    'alt42t_aggregated_resources',
    'alt42t_exams',
    'alt42t_exam_dates',
    'alt42t_exam_resources',
    'alt42t_exam_user_info',
    'alt42t_study_status',
    'alt42t_users'
];

$dbman = $DB->get_manager();
$missing_tables = [];
$existing_tables = [];

foreach ($tables as $tablename) {
    $table = new xmldb_table($tablename);
    
    if ($dbman->table_exists($table)) {
        $existing_tables[] = $tablename;
        echo "✓ $tablename 테이블이 존재합니다.\n";
        
        // 테이블의 레코드 수 확인
        try {
            $count = $DB->count_records($tablename);
            echo "  - 레코드 수: $count\n";
            
            // 현재 사용자의 데이터 확인
            if (in_array($tablename, ['alt42t_users', 'alt42t_exam_user_info'])) {
                $user_data = $DB->get_record($tablename, array('userid' => $USER->id));
                if ($user_data) {
                    echo "  - 현재 사용자 데이터: 있음\n";
                } else {
                    echo "  - 현재 사용자 데이터: 없음\n";
                }
            }
        } catch (Exception $e) {
            echo "  - 오류: " . $e->getMessage() . "\n";
        }
        
        echo "\n";
    } else {
        $missing_tables[] = $tablename;
        echo "✗ $tablename 테이블이 없습니다!\n\n";
    }
}

echo "\n=== 요약 ===\n";
echo "존재하는 테이블: " . count($existing_tables) . "개\n";
echo "누락된 테이블: " . count($missing_tables) . "개\n";

if (count($missing_tables) > 0) {
    echo "\n누락된 테이블을 생성하려면 create_alt42_tables.php를 실행하세요.\n";
}

// 현재 사용자의 전체 데이터 상태 확인
echo "\n=== 현재 사용자(" . $USER->firstname . " " . $USER->lastname . ")의 데이터 상태 ===\n";

// alt42t_exam_user_info 확인
$exam_info = $DB->get_record('alt42t_exam_user_info', array('userid' => $USER->id));
if ($exam_info) {
    echo "\n[exam_user_info 데이터]\n";
    echo "- School: " . ($exam_info->school ?? 'NULL') . "\n";
    echo "- Grade: " . ($exam_info->grade ?? 'NULL') . "\n";
    echo "- Exam Type: " . ($exam_info->exam_type ?? 'NULL') . "\n";
    echo "- Study Status: " . ($exam_info->study_status ?? 'NULL') . "\n";
}

// alt42t_users 확인
$user_data = $DB->get_record('alt42t_users', array('userid' => $USER->id));
if ($user_data) {
    echo "\n[users 데이터]\n";
    echo "- User ID: " . $user_data->user_id . "\n";
    echo "- Name: " . $user_data->name . "\n";
    echo "- School: " . $user_data->school_name . "\n";
    echo "- Grade: " . $user_data->grade . "\n";
}

echo "\n=== 확인 완료 ===\n";
?>