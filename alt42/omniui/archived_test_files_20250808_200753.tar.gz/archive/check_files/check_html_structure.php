<?php
// HTML 구조 검증을 위한 간단한 스크립트
$content = file_get_contents('index.php');

// script 태그 카운트
$script_open = substr_count($content, '<script');
$script_close = substr_count($content, '</script>');

echo "HTML 구조 검증 결과:\n";
echo "===================\n";
echo "<script> 태그 수: $script_open\n";
echo "</script> 태그 수: $script_close\n";

if ($script_open !== $script_close) {
    echo "\n⚠️  경고: script 태그가 올바르게 닫히지 않았습니다!\n";
}

// 의심스러운 패턴 찾기
$patterns = [
    '/loadUserCoals/' => 'loadUserCoals 오타 발견',
    '/페이지 로드 시 초기화[^<]*loadUser/' => '잘못된 위치의 JavaScript 코드',
    '/>>[^<]*페이지 로드 시/' => 'HTML 태그 밖의 JavaScript 주석'
];

echo "\n의심스러운 패턴:\n";
foreach ($patterns as $pattern => $description) {
    if (preg_match($pattern, $content, $matches)) {
        echo "- $description\n";
        echo "  매치된 내용: " . substr($matches[0], 0, 100) . "...\n";
    }
}

// 3950-3960 라인 근처 확인
$lines = explode("\n", $content);
echo "\n3950-3960 라인 근처:\n";
for ($i = 3949; $i < 3961 && $i < count($lines); $i++) {
    echo ($i + 1) . ": " . $lines[$i] . "\n";
}
?>