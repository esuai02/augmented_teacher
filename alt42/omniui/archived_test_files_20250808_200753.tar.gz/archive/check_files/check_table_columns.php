<?php
header('Content-Type: text/plain; charset=utf-8');

include_once("/home/moodle/public_html/moodle/config.php"); 
global $DB, $USER;
require_login();

echo "=== alt42t_exam_user_info 테이블 구조 확인 ===\n\n";

try {
    // 테이블 존재 확인
    $dbman = $DB->get_manager();
    $table = new xmldb_table('alt42t_exam_user_info');
    
    if ($dbman->table_exists($table)) {
        echo "✓ 테이블이 존재합니다.\n\n";
        
        // 컬럼 정보 가져오기
        $columns = $DB->get_columns('alt42t_exam_user_info');
        
        echo "컬럼 구조:\n";
        echo str_pad("컬럼명", 25) . str_pad("타입", 15) . str_pad("NULL 허용", 10) . str_pad("기본값", 15) . "\n";
        echo str_repeat("-", 65) . "\n";
        
        foreach ($columns as $column_name => $column_info) {
            $null_allowed = $column_info->not_null ? 'NO' : 'YES';
            $default = $column_info->has_default ? $column_info->default_value : 'NULL';
            
            echo str_pad($column_name, 25);
            echo str_pad($column_info->type, 15);
            echo str_pad($null_allowed, 10);
            echo str_pad($default, 15);
            echo "\n";
            
            // 날짜 관련 필드 상세 확인
            if (strpos($column_name, 'date') !== false) {
                echo "  → 날짜 필드 타입: " . $column_info->type . " (최대 길이: " . ($column_info->max_length ?? 'N/A') . ")\n";
            }
        }
        
        echo "\n현재 사용자의 데이터:\n";
        $user_data = $DB->get_record('alt42t_exam_user_info', array('userid' => $USER->id));
        if ($user_data) {
            echo "- ID: " . $user_data->id . "\n";
            echo "- User ID: " . $user_data->userid . "\n";
            echo "- School: " . ($user_data->school ?? 'NULL') . "\n";
            echo "- Grade: " . ($user_data->grade ?? 'NULL') . "\n";
            echo "- Exam Type: " . ($user_data->exam_type ?? 'NULL') . "\n";
            echo "- Exam Start Date: " . ($user_data->exam_start_date ?? 'NULL') . "\n";
            echo "- Exam End Date: " . ($user_data->exam_end_date ?? 'NULL') . "\n";
            echo "- Math Exam Date: " . ($user_data->math_exam_date ?? 'NULL') . "\n";
            echo "- Exam Scope: " . ($user_data->exam_scope ?? 'NULL') . "\n";
            echo "- Exam Status: " . ($user_data->exam_status ?? 'NULL') . "\n";
            echo "- Study Status: " . ($user_data->study_status ?? 'NULL') . "\n";
        } else {
            echo "현재 사용자의 데이터가 없습니다.\n";
        }
        
    } else {
        echo "✗ 테이블이 존재하지 않습니다!\n";
    }
    
} catch (Exception $e) {
    echo "오류 발생: " . $e->getMessage() . "\n";
}

echo "\n=== 확인 완료 ===\n";
?>