<?php
require_once('/home/moodle/public_html/moodle/config.php');
require_login();

global $DB, $USER;

// 관리자 권한 체크
$context = context_system::instance();
require_capability('moodle/site:config', $context);

echo "<h2>alt42t_ 테이블 구조 및 데이터 확인</h2>";

// 1. 테이블 존재 확인
$tables = ['alt42t_users', 'alt42t_exams', 'alt42t_exam_dates', 'alt42t_study_status', 'alt42t_exam_resources', 'alt42t_aggregated_resources'];
$dbman = $DB->get_manager();

echo "<h3>테이블 존재 여부</h3>";
echo "<table border='1' style='border-collapse:collapse;'>";
echo "<tr><th>테이블명</th><th>존재여부</th></tr>";
foreach ($tables as $table) {
    $table_obj = new xmldb_table($table);
    $exists = $dbman->table_exists($table_obj) ? '✓ 존재' : '✗ 없음';
    $color = $dbman->table_exists($table_obj) ? 'green' : 'red';
    echo "<tr><td>mdl_$table</td><td style='color:$color;'>$exists</td></tr>";
}
echo "</table>";

// 2. 현재 사용자의 데이터 확인
echo "<h3>현재 사용자(ID: {$USER->id})의 데이터</h3>";

// alt42t_users 데이터
$user_data = $DB->get_record('alt42t_users', ['userid' => $USER->id]);
if ($user_data) {
    echo "<h4>alt42t_users 데이터:</h4>";
    echo "<pre style='background:#f0f0f0;padding:10px;'>";
    print_r($user_data);
    echo "</pre>";
    
    // 관련 시험 정보
    if ($user_data->school_name && $user_data->grade) {
        $exam_data = $DB->get_records('alt42t_exams', [
            'school_name' => $user_data->school_name,
            'grade' => $user_data->grade
        ]);
        
        if ($exam_data) {
            echo "<h4>관련 시험 정보 (alt42t_exams):</h4>";
            foreach ($exam_data as $exam) {
                echo "<pre style='background:#f0f0f0;padding:10px;'>";
                print_r($exam);
                echo "</pre>";
                
                // 시험 날짜 정보
                $date_data = $DB->get_record('alt42t_exam_dates', [
                    'exam_id' => $exam->exam_id,
                    'user_id' => $user_data->user_id
                ]);
                
                if ($date_data) {
                    echo "<h5>시험 날짜 정보 (alt42t_exam_dates):</h5>";
                    echo "<pre style='background:#e0e0e0;padding:10px;'>";
                    print_r($date_data);
                    echo "</pre>";
                }
                
                // 학습 상태
                $status_data = $DB->get_record('alt42t_study_status', [
                    'exam_id' => $exam->exam_id,
                    'user_id' => $user_data->user_id
                ]);
                
                if ($status_data) {
                    echo "<h5>학습 상태 (alt42t_study_status):</h5>";
                    echo "<pre style='background:#e0e0e0;padding:10px;'>";
                    print_r($status_data);
                    echo "</pre>";
                }
                
                // 시험 자료
                $resource_data = $DB->get_records('alt42t_exam_resources', [
                    'exam_id' => $exam->exam_id,
                    'user_id' => $user_data->user_id
                ]);
                
                if ($resource_data) {
                    echo "<h5>시험 자료 (alt42t_exam_resources):</h5>";
                    foreach ($resource_data as $resource) {
                        echo "<pre style='background:#e0e0e0;padding:10px;'>";
                        print_r($resource);
                        echo "</pre>";
                    }
                }
            }
        } else {
            echo "<p>관련 시험 정보가 없습니다.</p>";
        }
    }
} else {
    echo "<p style='color:orange;'>사용자 데이터가 없습니다.</p>";
    echo "<p>테스트 데이터를 추가하시겠습니까?</p>";
    echo '<form method="post">';
    echo '<input type="hidden" name="action" value="insert_test">';
    echo '<button type="submit" style="background:#4CAF50;color:white;padding:10px;">테스트 데이터 추가</button>';
    echo '</form>';
}

// 테스트 데이터 추가 처리
if (optional_param('action', '', PARAM_TEXT) === 'insert_test') {
    echo "<h3>테스트 데이터 추가 중...</h3>";
    
    try {
        $now = time();
        
        // 1. alt42t_users에 추가
        $user_data = new stdClass();
        $user_data->name = $USER->firstname . ' ' . $USER->lastname;
        $user_data->school_name = '서울고등학교';
        $user_data->grade = 1;
        $user_data->created_at = date('Y-m-d H:i:s');
        $user_data->userid = $USER->id;
        $user_data->timecreated = $now;
        $user_data->timemodified = $now;
        
        $user_id = $DB->insert_record('alt42t_users', $user_data);
        echo "<p style='color:green;'>✓ alt42t_users에 추가 완료 (user_id: $user_id)</p>";
        
        // 2. alt42t_exams에 추가
        $exam_data = new stdClass();
        $exam_data->school_name = '서울고등학교';
        $exam_data->grade = 1;
        $exam_data->exam_type = '1학기 중간고사';
        $exam_data->userid = $USER->id;
        $exam_data->timecreated = $now;
        $exam_data->timemodified = $now;
        
        $exam_id = $DB->insert_record('alt42t_exams', $exam_data);
        echo "<p style='color:green;'>✓ alt42t_exams에 추가 완료 (exam_id: $exam_id)</p>";
        
        // 3. alt42t_exam_dates에 추가
        $date_data = new stdClass();
        $date_data->exam_id = $exam_id;
        $date_data->user_id = $user_id;
        $date_data->start_date = '2024-04-15';
        $date_data->end_date = '2024-04-19';
        $date_data->math_date = '2024-04-17';
        $date_data->status = '확정';
        $date_data->created_at = date('Y-m-d H:i:s');
        $date_data->userid = $USER->id;
        $date_data->timecreated = $now;
        $date_data->timemodified = $now;
        
        $DB->insert_record('alt42t_exam_dates', $date_data);
        echo "<p style='color:green;'>✓ alt42t_exam_dates에 추가 완료</p>";
        
        // 4. alt42t_study_status에 추가
        $status_data = new stdClass();
        $status_data->user_id = $user_id;
        $status_data->exam_id = $exam_id;
        $status_data->status = '개념공부';
        $status_data->created_at = date('Y-m-d H:i:s');
        $status_data->userid = $USER->id;
        $status_data->timecreated = $now;
        $status_data->timemodified = $now;
        
        $DB->insert_record('alt42t_study_status', $status_data);
        echo "<p style='color:green;'>✓ alt42t_study_status에 추가 완료</p>";
        
        // 5. alt42t_exam_resources에 시험 범위 추가
        $resource_data = new stdClass();
        $resource_data->exam_id = $exam_id;
        $resource_data->user_id = $user_id;
        $resource_data->tip_text = '시험 범위: 1단원~3단원 (도형의 성질까지)';
        $resource_data->created_at = date('Y-m-d H:i:s');
        $resource_data->userid = $USER->id;
        $resource_data->timecreated = $now;
        $resource_data->timemodified = $now;
        
        $DB->insert_record('alt42t_exam_resources', $resource_data);
        echo "<p style='color:green;'>✓ alt42t_exam_resources에 추가 완료</p>";
        
        echo '<p><a href="test_alt42t_tables.php">페이지 새로고침</a></p>';
        
    } catch (Exception $e) {
        echo "<p style='color:red;'>오류: " . $e->getMessage() . "</p>";
    }
}

// 3. 전체 데이터 수 확인
echo "<h3>전체 데이터 수</h3>";
echo "<table border='1' style='border-collapse:collapse;'>";
echo "<tr><th>테이블</th><th>레코드 수</th></tr>";
foreach ($tables as $table) {
    try {
        $count = $DB->count_records($table);
        echo "<tr><td>mdl_$table</td><td>$count</td></tr>";
    } catch (Exception $e) {
        echo "<tr><td>mdl_$table</td><td style='color:red;'>오류</td></tr>";
    }
}
echo "</table>";

echo "<hr>";
echo '<p><a href="index.php" style="padding:10px;background:#4CAF50;color:white;text-decoration:none;border-radius:5px;">메인 페이지로</a></p>';
echo '<p><a href="manual_save_test.php" style="padding:10px;background:#2196F3;color:white;text-decoration:none;border-radius:5px;">수동 저장 테스트</a></p>';
?>