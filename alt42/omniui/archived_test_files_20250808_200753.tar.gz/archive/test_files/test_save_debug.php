<?php
header('Content-Type: application/json; charset=utf-8');

// 에러 리포팅 활성화
error_reporting(E_ALL);
ini_set('display_errors', 1);

// 출력 버퍼 시작
ob_start();

try {
    require_once('/home/moodle/public_html/moodle/config.php');
    global $DB, $USER;
    require_login();
    
    // 디버깅 정보
    $debug_info = [
        'user_id' => $USER->id,
        'username' => $USER->username,
        'request_method' => $_SERVER['REQUEST_METHOD'],
        'content_type' => $_SERVER['CONTENT_TYPE'] ?? 'not set'
    ];
    
    // POST 데이터 받기
    $input_raw = file_get_contents("php://input");
    $input = json_decode($input_raw, true);
    
    $debug_info['raw_input'] = substr($input_raw, 0, 500); // 처음 500자만
    $debug_info['decoded_input'] = $input;
    
    if (!$input) {
        throw new Exception('입력 데이터가 없거나 JSON 파싱 실패');
    }
    
    // 테이블 존재 확인
    $dbman = $DB->get_manager();
    $table = new xmldb_table('alt42t_exam_user_info');
    
    if (!$dbman->table_exists($table)) {
        throw new Exception('alt42t_exam_user_info 테이블이 존재하지 않습니다');
    }
    
    // 기존 데이터 확인
    $existing = $DB->get_record('alt42t_exam_user_info', ['userid' => $USER->id]);
    $debug_info['existing_record'] = $existing ? 'found' : 'not found';
    
    // 섹션 0 테스트: 기본 정보 저장
    if ($input['test'] === 'basic') {
        $data = new stdClass();
        $data->userid = $USER->id;
        $data->school = '테스트학교';
        $data->grade = '1';
        $data->exam_type = '1mid';
        
        if ($existing) {
            $data->id = $existing->id;
            $data->timemodified = time();
            $debug_info['operation'] = 'update';
            $result = $DB->update_record('alt42t_exam_user_info', $data);
            $debug_info['result'] = $result;
        } else {
            $data->timecreated = time();
            $data->timemodified = time();
            $debug_info['operation'] = 'insert';
            $newid = $DB->insert_record('alt42t_exam_user_info', $data);
            $debug_info['new_id'] = $newid;
        }
        
        // 저장 후 확인
        $after = $DB->get_record('alt42t_exam_user_info', ['userid' => $USER->id]);
        $debug_info['after_save'] = $after;
    }
    
    // 섹션 1 테스트: 시험 일정 저장
    if ($input['test'] === 'schedule') {
        if (!$existing) {
            throw new Exception('기본 정보를 먼저 저장해주세요');
        }
        
        $data = clone $existing;
        $data->exam_start_date = '2024-04-15';
        $data->exam_end_date = '2024-04-19';
        $data->math_exam_date = '2024-04-17';
        $data->exam_scope = '1단원~3단원 (도형의 성질까지)';
        $data->exam_status = 'expected';
        $data->timemodified = time();
        
        $debug_info['operation'] = 'update_schedule';
        $result = $DB->update_record('alt42t_exam_user_info', $data);
        $debug_info['result'] = $result;
        
        // 저장 후 확인
        $after = $DB->get_record('alt42t_exam_user_info', ['userid' => $USER->id]);
        $debug_info['after_save'] = $after;
    }
    
    ob_clean();
    echo json_encode([
        'success' => true,
        'message' => '테스트 완료',
        'debug' => $debug_info
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    ob_clean();
    
    $error_info = [
        'file' => $e->getFile(),
        'line' => $e->getLine(),
        'trace' => $e->getTraceAsString()
    ];
    
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
        'error_info' => $error_info,
        'debug' => $debug_info ?? []
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}
exit;
?>