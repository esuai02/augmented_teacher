<?php
header('Content-Type: text/html; charset=utf-8');

include_once("/home/moodle/public_html/moodle/config.php"); 
global $DB, $USER;
require_login();

echo "<h1>퀴즈 데이터 테스트</h1>";
echo "<p>사용자 ID: {$USER->id}</p>";

// 1. quiz_attempts 테이블 확인
echo "<h2>1. 퀴즈 시도 데이터</h2>";

$oneWeekAgo = time() - 604800;
$todayStart = strtotime('today');

try {
    // 전체 퀴즈 시도 (최근 1주)
    $sql = "SELECT qa.*, q.name AS quiz_name, q.sumgrades AS total_grades,
                   c.fullname AS course_name
            FROM {quiz_attempts} qa
            JOIN {quiz} q ON qa.quiz = q.id
            JOIN {course} c ON q.course = c.id
            WHERE qa.userid = ? 
            AND qa.timestart > ?
            AND qa.state = 'finished'
            ORDER BY qa.timestart DESC
            LIMIT 10";
    
    $attempts = $DB->get_records_sql($sql, array($USER->id, $oneWeekAgo));
    
    echo "<p>최근 1주간 퀴즈 시도: " . count($attempts) . "개</p>";
    
    if (!empty($attempts)) {
        echo "<table border='1'>";
        echo "<tr><th>퀴즈명</th><th>코스</th><th>점수</th><th>날짜</th></tr>";
        
        foreach ($attempts as $attempt) {
            $score = $attempt->sumgrades && $attempt->total_grades > 0 
                ? round(($attempt->sumgrades / $attempt->total_grades) * 100, 1) 
                : 0;
            
            echo "<tr>";
            echo "<td>{$attempt->quiz_name}</td>";
            echo "<td>{$attempt->course_name}</td>";
            echo "<td>{$score}%</td>";
            echo "<td>" . date('Y-m-d H:i', $attempt->timestart) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
} catch (Exception $e) {
    echo "<p style='color:red'>오류: " . $e->getMessage() . "</p>";
}

// 2. 전체 시도 확인 (기간 제한 없이)
echo "<h2>2. 전체 퀴즈 시도 (기간 제한 없음)</h2>";

try {
    $allAttempts = $DB->count_records('quiz_attempts', array('userid' => $USER->id, 'state' => 'finished'));
    echo "<p>전체 완료된 퀴즈 시도: {$allAttempts}개</p>";
    
    // 최근 5개만 표시
    $recentAttempts = $DB->get_records('quiz_attempts', 
        array('userid' => $USER->id, 'state' => 'finished'), 
        'timestart DESC', '*', 0, 5);
    
    if (!empty($recentAttempts)) {
        echo "<p>최근 5개 시도:</p>";
        echo "<ul>";
        foreach ($recentAttempts as $attempt) {
            echo "<li>Quiz ID: {$attempt->quiz}, 시작: " . date('Y-m-d H:i', $attempt->timestart) . "</li>";
        }
        echo "</ul>";
    }
    
} catch (Exception $e) {
    echo "<p style='color:red'>오류: " . $e->getMessage() . "</p>";
}

// 3. get_dashboard_goals 함수 테스트
echo "<h2>3. get_dashboard_goals 함수 결과</h2>";

require_once(__DIR__ . '/get_dashboard_goals.php');
$dashboardData = getDashboardGoals($USER->id);

echo "<pre>";
print_r($dashboardData);
echo "</pre>";
?>