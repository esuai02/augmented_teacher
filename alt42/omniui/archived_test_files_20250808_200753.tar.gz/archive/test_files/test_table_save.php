<?php
header('Content-Type: application/json; charset=utf-8');

include_once("/home/moodle/public_html/moodle/config.php"); 
global $DB, $USER;
require_login();

try {
    // 테스트 데이터
    $testdata = new stdClass();
    $testdata->userid = $USER->id;
    $testdata->school = '테스트 학교';
    $testdata->grade = '2';
    $testdata->exam_type = '1mid';
    $testdata->timecreated = time();
    $testdata->timemodified = time();
    
    // 기존 레코드 확인
    $existing = $DB->get_record('alt42t_exam_user_info', array('userid' => $USER->id));
    
    if ($existing) {
        // 업데이트
        $testdata->id = $existing->id;
        $DB->update_record('alt42t_exam_user_info', $testdata);
        $result = [
            'success' => true,
            'message' => '테스트 데이터 업데이트 성공',
            'action' => 'update',
            'id' => $existing->id,
            'data' => $testdata
        ];
    } else {
        // 삽입
        $id = $DB->insert_record('alt42t_exam_user_info', $testdata);
        $result = [
            'success' => true,
            'message' => '테스트 데이터 저장 성공',
            'action' => 'insert',
            'id' => $id,
            'data' => $testdata
        ];
    }
    
    // 저장된 데이터 확인
    $saved = $DB->get_record('alt42t_exam_user_info', array('userid' => $USER->id));
    $result['saved'] = $saved;
    
} catch (Exception $e) {
    $result = [
        'success' => false,
        'message' => '오류 발생: ' . $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ];
}

echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>