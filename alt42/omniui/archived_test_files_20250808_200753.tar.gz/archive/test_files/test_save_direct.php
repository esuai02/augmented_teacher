<?php
// 직접 DB 저장 테스트
header('Content-Type: text/html; charset=utf-8');

include_once("/home/moodle/public_html/moodle/config.php"); 
global $DB, $USER;
require_login();

echo "<h1>DB 저장 테스트</h1>";
echo "<p>사용자 ID: {$USER->id}</p>";

// 1. 테이블 존재 확인
echo "<h2>1. 테이블 확인</h2>";
$tables = [
    'alt42t_users',
    'alt42t_exams', 
    'alt42t_exam_dates',
    'alt42t_exam_resources',
    'alt42t_exam_user_info',
    'alt42t_study_status',
    'alt42t_aggregated_resources'
];

$dbman = $DB->get_manager();
foreach ($tables as $tablename) {
    $table = new xmldb_table($tablename);
    if ($dbman->table_exists($table)) {
        echo "<p style='color:green'>✓ {$tablename} 테이블 존재</p>";
        
        // 테이블 구조 확인
        try {
            $columns = $DB->get_columns($tablename);
            echo "<details><summary>컬럼 정보 보기</summary><pre>";
            print_r(array_keys($columns));
            echo "</pre></details>";
        } catch (Exception $e) {
            echo "<p style='color:red'>컬럼 조회 실패: {$e->getMessage()}</p>";
        }
    } else {
        echo "<p style='color:red'>✗ {$tablename} 테이블 없음</p>";
    }
}

// 2. alt42t_exam_user_info 테이블에 저장 테스트
echo "<h2>2. alt42t_exam_user_info 저장 테스트</h2>";

try {
    // 기존 데이터 확인
    $existing = $DB->get_record('alt42t_exam_user_info', array('userid' => $USER->id));
    
    if ($existing) {
        echo "<p>기존 데이터 있음:</p>";
        echo "<pre>" . print_r($existing, true) . "</pre>";
        
        // UPDATE
        $data = clone $existing;
        $data->school = "테스트학교_" . date('His');
        $data->grade = "3";
        $data->exam_type = "1mid";
        $data->timemodified = time();
        
        $DB->update_record('alt42t_exam_user_info', $data);
        echo "<p style='color:green'>✓ UPDATE 성공</p>";
    } else {
        // INSERT
        $data = new stdClass();
        $data->userid = $USER->id;
        $data->school = "테스트학교_" . date('His');
        $data->grade = "3";
        $data->exam_type = "1mid";
        $data->timecreated = time();
        $data->timemodified = time();
        
        $id = $DB->insert_record('alt42t_exam_user_info', $data);
        echo "<p style='color:green'>✓ INSERT 성공 (ID: {$id})</p>";
    }
    
    // 저장 확인
    $saved = $DB->get_record('alt42t_exam_user_info', array('userid' => $USER->id));
    echo "<p>저장된 데이터:</p>";
    echo "<pre>" . print_r($saved, true) . "</pre>";
    
} catch (Exception $e) {
    echo "<p style='color:red'>오류: " . $e->getMessage() . "</p>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
}

// 3. AJAX 저장 테스트
?>

<h2>3. AJAX 저장 테스트</h2>
<div>
    <button onclick="testSaveClean()">save_clean.php 테스트</button>
    <button onclick="testSaveSimple()">save_simple_working.php 테스트</button>
</div>
<div id="result" style="margin-top: 20px; padding: 10px; border: 1px solid #ccc;"></div>

<script>
async function testSaveClean() {
    const data = {
        section: 0,
        school: 'AJAX테스트학교',
        grade: '2',
        examType: '1final'
    };
    
    try {
        const response = await fetch('save_clean.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(data)
        });
        
        const text = await response.text();
        console.log('Raw response:', text);
        
        try {
            const result = JSON.parse(text);
            document.getElementById('result').innerHTML = 
                '<h3>save_clean.php 결과:</h3>' +
                '<pre>' + JSON.stringify(result, null, 2) + '</pre>';
        } catch (e) {
            document.getElementById('result').innerHTML = 
                '<h3>save_clean.php 오류:</h3>' +
                '<p style="color:red">JSON 파싱 실패</p>' +
                '<pre>' + text + '</pre>';
        }
    } catch (error) {
        document.getElementById('result').innerHTML = 
            '<h3>오류:</h3><pre>' + error + '</pre>';
    }
}

async function testSaveSimple() {
    const data = {
        section: 0,
        school: 'SIMPLE테스트학교',
        grade: '1',
        examType: '2mid'
    };
    
    try {
        const response = await fetch('save_simple_working.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(data)
        });
        
        const text = await response.text();
        console.log('Raw response:', text);
        
        try {
            const result = JSON.parse(text);
            document.getElementById('result').innerHTML = 
                '<h3>save_simple_working.php 결과:</h3>' +
                '<pre>' + JSON.stringify(result, null, 2) + '</pre>';
        } catch (e) {
            document.getElementById('result').innerHTML = 
                '<h3>save_simple_working.php 오류:</h3>' +
                '<p style="color:red">JSON 파싱 실패</p>' +
                '<pre>' + text + '</pre>';
        }
    } catch (error) {
        document.getElementById('result').innerHTML = 
            '<h3>오류:</h3><pre>' + error + '</pre>';
    }
}
</script>