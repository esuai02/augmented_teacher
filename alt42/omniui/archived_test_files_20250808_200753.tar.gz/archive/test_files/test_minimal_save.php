<?php
// 절대 최소한의 테스트
header('Content-Type: application/json');
echo json_encode(['test' => 'ok']);
exit;
?>