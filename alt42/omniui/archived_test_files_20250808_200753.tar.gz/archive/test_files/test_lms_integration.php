<?php
require_once('/home/moodle/public_html/moodle/config.php');
require_once(__DIR__ . '/get_user_lms_data.php');
global $DB, $USER;
require_login();

header('Content-Type: text/html; charset=utf-8');

$userid = optional_param('userid', $USER->id, PARAM_INT);
$lmsData = getUserLMSData($userid);
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LMS Integration Test</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 40px auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #333;
            border-bottom: 2px solid #4CAF50;
            padding-bottom: 10px;
        }
        h2 {
            color: #666;
            margin-top: 30px;
        }
        .data-grid {
            display: grid;
            grid-template-columns: 200px 1fr;
            gap: 10px;
            margin: 20px 0;
        }
        .label {
            font-weight: bold;
            color: #555;
        }
        .value {
            color: #333;
            padding: 5px 10px;
            background: #f0f0f0;
            border-radius: 5px;
        }
        .empty {
            color: #999;
            font-style: italic;
        }
        .test-button {
            background: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 20px;
        }
        .test-button:hover {
            background: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>LMS 데이터 통합 테스트</h1>
        
        <h2>사용자 정보</h2>
        <div class="data-grid">
            <div class="label">사용자 ID:</div>
            <div class="value"><?php echo $userid; ?></div>
            
            <div class="label">이름:</div>
            <div class="value"><?php echo $USER->firstname . ' ' . $USER->lastname; ?></div>
        </div>
        
        <h2>LMS 데이터</h2>
        <div class="data-grid">
            <div class="label">학교:</div>
            <div class="value <?php echo empty($lmsData['institute']) ? 'empty' : ''; ?>">
                <?php echo $lmsData['institute'] ?: '(데이터 없음)'; ?>
            </div>
            
            <div class="label">출생년도:</div>
            <div class="value <?php echo empty($lmsData['birthdate']) ? 'empty' : ''; ?>">
                <?php echo $lmsData['birthdate'] ?: '(데이터 없음)'; ?>
            </div>
            
            <div class="label">계산된 학년:</div>
            <div class="value <?php echo empty($lmsData['grade']) ? 'empty' : ''; ?>">
                <?php echo $lmsData['grade'] ? $lmsData['grade'] . '학년' : '(계산 불가)'; ?>
            </div>
            
            <div class="label">학원명:</div>
            <div class="value <?php echo empty($lmsData['academy']) ? 'empty' : ''; ?>">
                <?php echo $lmsData['academy'] ?: '(데이터 없음)'; ?>
            </div>
            
            <div class="label">지역:</div>
            <div class="value <?php echo empty($lmsData['location']) ? 'empty' : ''; ?>">
                <?php echo $lmsData['location'] ?: '(데이터 없음)'; ?>
            </div>
        </div>
        
        <h2>AJAX 테스트</h2>
        <button class="test-button" onclick="testAjax()">AJAX로 데이터 가져오기</button>
        <div id="ajax-result" style="margin-top: 20px;"></div>
        
        <h2>전체 데이터 (디버깅용)</h2>
        <pre style="background: #f0f0f0; padding: 15px; border-radius: 5px; overflow-x: auto;">
<?php print_r($lmsData); ?>
        </pre>
    </div>
    
    <script>
        async function testAjax() {
            const resultDiv = document.getElementById('ajax-result');
            resultDiv.innerHTML = '<p>데이터를 가져오는 중...</p>';
            
            try {
                const response = await fetch('get_user_lms_data.php?action=get_lms_data&userid=<?php echo $userid; ?>');
                const data = await response.json();
                
                if (data.success) {
                    let html = '<h3>AJAX 응답 성공!</h3>';
                    html += '<div class="data-grid">';
                    html += '<div class="label">학교:</div>';
                    html += '<div class="value">' + (data.data.institute || '(없음)') + '</div>';
                    html += '<div class="label">학년:</div>';
                    html += '<div class="value">' + (data.data.grade ? data.data.grade + '학년' : '(없음)') + '</div>';
                    html += '</div>';
                    resultDiv.innerHTML = html;
                } else {
                    resultDiv.innerHTML = '<p style="color: red;">오류: ' + (data.error || '알 수 없는 오류') + '</p>';
                }
            } catch (error) {
                resultDiv.innerHTML = '<p style="color: red;">네트워크 오류: ' + error.message + '</p>';
            }
        }
    </script>
</body>
</html>