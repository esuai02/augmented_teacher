<?php
header('Content-Type: text/html; charset=utf-8');

include_once("/home/moodle/public_html/moodle/config.php"); 
global $DB, $USER;
require_login();

echo "<h1>직접 DB 저장 테스트</h1>";
echo "<p>현재 사용자: {$USER->firstname} {$USER->lastname} (ID: {$USER->id})</p>";

// 테스트할 데이터
$test_school = "테스트학교_" . date('His');
$test_grade = "3";
$test_exam = "1mid";

echo "<h2>1. 테이블 존재 확인</h2>";
$dbman = $DB->get_manager();
$table = new xmldb_table('alt42t_exam_user_info');

if (!$dbman->table_exists($table)) {
    echo "<p style='color:red'>❌ alt42t_exam_user_info 테이블이 존재하지 않습니다!</p>";
    echo "<p>create_exam_user_info_table.php를 실행해주세요.</p>";
    exit;
}

echo "<p style='color:green'>✅ 테이블이 존재합니다.</p>";

echo "<h2>2. 현재 데이터 확인</h2>";
$existing = $DB->get_record('alt42t_exam_user_info', array('userid' => $USER->id));

if ($existing) {
    echo "<p>기존 데이터가 있습니다:</p>";
    echo "<pre>";
    print_r($existing);
    echo "</pre>";
} else {
    echo "<p>현재 사용자의 데이터가 없습니다.</p>";
}

echo "<h2>3. 저장 테스트</h2>";

try {
    if ($existing) {
        // UPDATE
        echo "<p>UPDATE 시도...</p>";
        
        // 기존 데이터 복사
        $data = clone $existing;
        $data->school = $test_school;
        $data->grade = $test_grade;
        $data->exam_type = $test_exam;
        $data->timemodified = time();
        
        echo "<p>저장할 데이터:</p>";
        echo "<pre>";
        print_r($data);
        echo "</pre>";
        
        $DB->update_record('alt42t_exam_user_info', $data);
        echo "<p style='color:green'>✅ UPDATE 성공!</p>";
    } else {
        // INSERT
        echo "<p>INSERT 시도...</p>";
        
        $data = new stdClass();
        $data->userid = $USER->id;
        $data->school = $test_school;
        $data->grade = $test_grade;
        $data->exam_type = $test_exam;
        $data->timecreated = time();
        $data->timemodified = time();
        
        echo "<p>저장할 데이터:</p>";
        echo "<pre>";
        print_r($data);
        echo "</pre>";
        
        $id = $DB->insert_record('alt42t_exam_user_info', $data);
        echo "<p style='color:green'>✅ INSERT 성공! (새 ID: $id)</p>";
    }
    
    // 저장 후 확인
    echo "<h2>4. 저장 후 데이터 확인</h2>";
    $saved = $DB->get_record('alt42t_exam_user_info', array('userid' => $USER->id));
    
    if ($saved) {
        echo "<p style='color:green'>✅ 데이터가 정상적으로 저장되었습니다:</p>";
        echo "<pre>";
        print_r($saved);
        echo "</pre>";
        
        // 값 비교
        echo "<h3>저장된 값 확인:</h3>";
        echo "<ul>";
        echo "<li>School: <strong>{$saved->school}</strong> " . ($saved->school == $test_school ? "✅" : "❌") . "</li>";
        echo "<li>Grade: <strong>{$saved->grade}</strong> " . ($saved->grade == $test_grade ? "✅" : "❌") . "</li>";
        echo "<li>Exam Type: <strong>{$saved->exam_type}</strong> " . ($saved->exam_type == $test_exam ? "✅" : "❌") . "</li>";
        echo "</ul>";
    } else {
        echo "<p style='color:red'>❌ 데이터를 찾을 수 없습니다.</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color:red'>❌ 오류 발생: " . $e->getMessage() . "</p>";
    echo "<pre>";
    echo $e->getTraceAsString();
    echo "</pre>";
}

// AJAX 테스트
?>

<h2>5. AJAX 저장 테스트</h2>
<form id="testForm">
    <p>
        <label>학교: <input type="text" id="school" value="AJAX테스트학교"></label>
    </p>
    <p>
        <label>학년: 
            <select id="grade">
                <option value="1">1학년</option>
                <option value="2">2학년</option>
                <option value="3">3학년</option>
            </select>
        </label>
    </p>
    <p>
        <label>시험종류: 
            <select id="examType">
                <option value="1mid">1학기 중간고사</option>
                <option value="1final">1학기 기말고사</option>
                <option value="2mid">2학기 중간고사</option>
                <option value="2final">2학기 기말고사</option>
            </select>
        </label>
    </p>
    <button type="button" onclick="testAjaxSave()">AJAX 저장 테스트</button>
</form>

<div id="ajaxResult"></div>

<script>
async function testAjaxSave() {
    const data = {
        section: 0,
        userid: <?php echo $USER->id; ?>,
        school: document.getElementById('school').value,
        grade: document.getElementById('grade').value,
        examType: document.getElementById('examType').value
    };
    
    console.log('전송할 데이터:', data);
    
    try {
        const response = await fetch('save_clean.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        const responseText = await response.text();
        console.log('Raw response:', responseText);
        
        try {
            const result = JSON.parse(responseText);
            document.getElementById('ajaxResult').innerHTML = 
                '<h3>응답:</h3><pre>' + JSON.stringify(result, null, 2) + '</pre>';
                
            if (result.success) {
                // 페이지 새로고침하여 저장된 데이터 확인
                setTimeout(() => {
                    location.reload();
                }, 2000);
            }
        } catch (e) {
            document.getElementById('ajaxResult').innerHTML = 
                '<h3 style="color:red">JSON 파싱 오류:</h3><pre>' + responseText + '</pre>';
        }
    } catch (error) {
        document.getElementById('ajaxResult').innerHTML = 
            '<h3 style="color:red">오류:</h3><pre>' + error + '</pre>';
    }
}
</script>