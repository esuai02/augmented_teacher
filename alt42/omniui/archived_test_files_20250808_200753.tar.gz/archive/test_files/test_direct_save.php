<?php
header('Content-Type: text/plain; charset=utf-8');

include_once("/home/moodle/public_html/moodle/config.php"); 
global $DB, $USER;
require_login();

echo "=== 직접 저장 테스트 ===\n\n";

// 1. 테이블 존재 확인
$dbman = $DB->get_manager();
$table = new xmldb_table('alt42t_exam_user_info');

if (!$dbman->table_exists($table)) {
    echo "❌ 테이블이 존재하지 않습니다! 먼저 테이블을 생성하세요.\n";
    exit;
}

echo "✅ 테이블이 존재합니다.\n\n";

// 2. 현재 데이터 확인
$existing = $DB->get_record('alt42t_exam_user_info', array('userid' => $USER->id));
echo "현재 사용자 데이터: " . ($existing ? "있음 (ID: {$existing->id})" : "없음") . "\n\n";

// 3. 저장 테스트
$testdata = new stdClass();
$testdata->userid = $USER->id;
$testdata->school = '직접 테스트 학교 ' . date('Y-m-d H:i:s');
$testdata->grade = '2';
$testdata->exam_type = '1mid';

try {
    if ($existing) {
        // UPDATE
        $testdata->id = $existing->id;
        $testdata->timemodified = time();
        
        // 기존 데이터 복사
        foreach ($existing as $key => $value) {
            if (!isset($testdata->$key)) {
                $testdata->$key = $value;
            }
        }
        
        echo "UPDATE 시도...\n";
        echo "데이터: " . json_encode($testdata, JSON_UNESCAPED_UNICODE) . "\n";
        
        $DB->update_record('alt42t_exam_user_info', $testdata);
        echo "✅ UPDATE 성공!\n\n";
    } else {
        // INSERT
        $testdata->timecreated = time();
        $testdata->timemodified = time();
        
        echo "INSERT 시도...\n";
        echo "데이터: " . json_encode($testdata, JSON_UNESCAPED_UNICODE) . "\n";
        
        $id = $DB->insert_record('alt42t_exam_user_info', $testdata);
        echo "✅ INSERT 성공! (새 ID: $id)\n\n";
    }
    
    // 저장된 데이터 확인
    $saved = $DB->get_record('alt42t_exam_user_info', array('userid' => $USER->id));
    echo "저장된 데이터:\n";
    echo "- School: " . $saved->school . "\n";
    echo "- Grade: " . $saved->grade . "\n";
    echo "- Exam Type: " . $saved->exam_type . "\n";
    echo "- Time Modified: " . date('Y-m-d H:i:s', $saved->timemodified) . "\n";
    
} catch (Exception $e) {
    echo "❌ 오류 발생: " . $e->getMessage() . "\n";
    echo "상세:\n" . $e->getTraceAsString() . "\n";
}

echo "\n=== 테스트 완료 ===\n";
?>