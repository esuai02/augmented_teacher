<?php
// 모든 출력 버퍼링 끄기
ob_clean();

// 에러 표시 끄기
error_reporting(0);
ini_set('display_errors', 0);

// JSON 헤더
header('Content-Type: application/json; charset=utf-8');

try {
    include_once("/home/moodle/public_html/moodle/config.php"); 
    global $DB, $USER;
    require_login();
    
    // 간단한 테스트 응답
    echo json_encode([
        'success' => true,
        'message' => '테스트 성공',
        'user_id' => $USER->id,
        'timestamp' => time()
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => '오류: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}

exit;
?>