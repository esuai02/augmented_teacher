<?php
require_once('/home/moodle/public_html/moodle/config.php');
require_once(__DIR__ . '/get_user_lms_data.php');
require_once(__DIR__ . '/get_exam_data_alt42t.php');
global $DB, $USER;
require_login();

header('Content-Type: text/html; charset=utf-8');

$userid = optional_param('userid', $USER->id, PARAM_INT);
$user = $DB->get_record('user', array('id' => $userid));
$lmsData = getUserLMSData($userid);
$examInfo = getExamDataFromAlt42t($userid);
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LMS Dashboard Integration Test</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(to bottom right, #1e1b4b, #7c3aed, #1e1b4b);
            min-height: 100vh;
            color: white;
            padding: 20px;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        h1 {
            text-align: center;
            margin-bottom: 30px;
        }
        .dashboard-grid {
            display: grid;
            grid-template-columns: 300px 1fr 300px;
            gap: 20px;
        }
        .card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 16px;
            padding: 20px;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        .card h3 {
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .info-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            font-size: 14px;
        }
        .info-row .label {
            color: #c084fc;
        }
        .info-row .value {
            color: white;
            font-weight: 500;
        }
        .learning-style-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
            margin-top: 20px;
        }
        .style-card {
            background: rgba(59, 130, 246, 0.2);
            border: 1px solid rgba(59, 130, 246, 0.3);
            border-radius: 12px;
            padding: 15px;
            text-align: center;
        }
        .style-card .icon {
            font-size: 24px;
            margin-bottom: 8px;
        }
        .style-card .type {
            font-size: 12px;
            color: #93c5fd;
            margin-bottom: 4px;
        }
        .style-card .value {
            font-size: 14px;
            font-weight: bold;
            color: #60a5fa;
        }
        .test-info {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 8px;
            padding: 15px;
            margin-top: 20px;
        }
        .test-info h4 {
            margin-bottom: 10px;
            color: #fbbf24;
        }
        .test-info pre {
            font-size: 12px;
            overflow-x: auto;
            background: rgba(0, 0, 0, 0.2);
            padding: 10px;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🎓 LMS 대시보드 통합 테스트</h1>
        
        <div class="dashboard-grid">
            <!-- 왼쪽 컬럼 -->
            <div>
                <!-- 프로필 카드 -->
                <div class="card">
                    <h3><span>🎓</span>프로필</h3>
                    <div class="info-row">
                        <span class="label">이름</span>
                        <span class="value"><?php echo $user->firstname . ' ' . $user->lastname; ?></span>
                    </div>
                    <div class="info-row">
                        <span class="label">학교</span>
                        <span class="value"><?php echo $examInfo->school ?: '-'; ?></span>
                    </div>
                    <div class="info-row">
                        <span class="label">학년</span>
                        <span class="value"><?php echo $examInfo->grade ? $examInfo->grade . '학년' : '-'; ?></span>
                    </div>
                </div>
                
                <!-- LMS 정보 카드 -->
                <div class="card" style="margin-top: 20px;">
                    <h3><span>🎓</span>LMS 학습 정보</h3>
                    <div class="info-row">
                        <span class="label">학원</span>
                        <span class="value"><?php echo $lmsData['academy'] ?: '-'; ?></span>
                    </div>
                    <div class="info-row">
                        <span class="label">지역</span>
                        <span class="value"><?php echo $lmsData['location'] ?: '-'; ?></span>
                    </div>
                    <div class="info-row">
                        <span class="label">학습모드</span>
                        <span class="value">
                            <?php 
                            $lmodeMap = [
                                '신규' => '🌱 신규',
                                '자율' => '🎯 자율',
                                '지도' => '👨‍🏫 지도',
                                '도제' => '🎓 도제'
                            ];
                            echo isset($lmodeMap[$lmsData['lmode']]) ? $lmodeMap[$lmsData['lmode']] : ($lmsData['lmode'] ?: '-');
                            ?>
                        </span>
                    </div>
                    <div class="info-row">
                        <span class="label">수학레벨</span>
                        <span class="value"><?php echo $lmsData['mathlevel'] ?: '-'; ?></span>
                    </div>
                    <div class="info-row">
                        <span class="label">주간학습</span>
                        <span class="value"><?php echo $lmsData['termhours'] ? $lmsData['termhours'] . '시간' : '-'; ?></span>
                    </div>
                </div>
            </div>
            
            <!-- 중앙 컬럼 -->
            <div>
                <!-- 학습 스타일 분석 카드 -->
                <div class="card">
                    <h3><span>🧠</span>LMS 학습 스타일 분석</h3>
                    <div class="learning-style-grid">
                        <?php if ($lmsData['evaluate']): ?>
                        <div class="style-card">
                            <div class="icon"><?php echo $lmsData['evaluate'] === '완결형' ? '✅' : '🚀'; ?></div>
                            <div class="type">평가 스타일</div>
                            <div class="value"><?php echo $lmsData['evaluate']; ?></div>
                        </div>
                        <?php endif; ?>
                        
                        <?php if ($lmsData['curriculum']): ?>
                        <div class="style-card" style="background: rgba(34, 197, 94, 0.2); border-color: rgba(34, 197, 94, 0.3);">
                            <div class="icon">
                                <?php 
                                echo $lmsData['curriculum'] === '성장형' ? '📈' : 
                                     ($lmsData['curriculum'] === '표준형' ? '📊' : '📉');
                                ?>
                            </div>
                            <div class="type">커리큘럼</div>
                            <div class="value" style="color: #4ade80;"><?php echo $lmsData['curriculum']; ?></div>
                        </div>
                        <?php endif; ?>
                        
                        <?php if ($lmsData['goalstability']): ?>
                        <div class="style-card" style="background: rgba(168, 85, 247, 0.2); border-color: rgba(168, 85, 247, 0.3);">
                            <div class="icon"><?php echo $lmsData['goalstability'] === '안정' ? '🎯' : '🎲'; ?></div>
                            <div class="type">목표 안정도</div>
                            <div class="value" style="color: #c084fc;"><?php echo $lmsData['goalstability']; ?></div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- 추가 학습 정보 -->
                <div class="card" style="margin-top: 20px;">
                    <h3><span>📊</span>추가 학습 정보</h3>
                    <div class="info-row">
                        <span class="label">사용법 능숙도</span>
                        <span class="value"><?php echo $lmsData['fluency'] ?: '-'; ?></span>
                    </div>
                    <div class="info-row">
                        <span class="label">효과적 학습</span>
                        <span class="value"><?php echo $lmsData['effectivelearning'] ?: '-'; ?></span>
                    </div>
                    <div class="info-row">
                        <span class="label">부스터 활동</span>
                        <span class="value"><?php echo $lmsData['nboosters'] ? $lmsData['nboosters'] . '회' : '-'; ?></span>
                    </div>
                    <div class="info-row">
                        <span class="label">점검 주기</span>
                        <span class="value"><?php echo $lmsData['inspecttime'] ?: '-'; ?></span>
                    </div>
                    <div class="info-row">
                        <span class="label">방학 학습시간</span>
                        <span class="value"><?php echo $lmsData['vachours'] ? $lmsData['vachours'] . '시간' : '-'; ?></span>
                    </div>
                </div>
            </div>
            
            <!-- 오른쪽 컬럼 -->
            <div>
                <!-- PRESET 정보 -->
                <div class="card">
                    <h3><span>🎮</span>PRESET 설정</h3>
                    <div class="info-row">
                        <span class="label">개념미션</span>
                        <span class="value"><?php echo $lmsData['preset_concept'] ?: '-'; ?></span>
                    </div>
                    <div class="info-row">
                        <span class="label">심화미션</span>
                        <span class="value"><?php echo $lmsData['preset_advanced'] ?: '-'; ?></span>
                    </div>
                    <div class="info-row">
                        <span class="label">내신미션</span>
                        <span class="value"><?php echo $lmsData['preset_school'] ?: '-'; ?></span>
                    </div>
                    <div class="info-row">
                        <span class="label">수능미션</span>
                        <span class="value"><?php echo $lmsData['preset_csat'] ?: '-'; ?></span>
                    </div>
                </div>
                
                <!-- 학습 환경 -->
                <div class="card" style="margin-top: 20px;">
                    <h3><span>🏠</span>학습 환경</h3>
                    <div class="info-row">
                        <span class="label">형제관계</span>
                        <span class="value"><?php echo $lmsData['brotherhood'] ?: '-'; ?></span>
                    </div>
                    <div class="info-row">
                        <span class="label">사용자 유형</span>
                        <span class="value"><?php echo $lmsData['roleinfo'] ?: '-'; ?></span>
                    </div>
                    <div class="info-row">
                        <span class="label">코스 추천</span>
                        <span class="value"><?php echo $lmsData['addcourse'] ?: '-'; ?></span>
                    </div>
                    <div class="info-row">
                        <span class="label">진도</span>
                        <span class="value"><?php echo $lmsData['progresstype'] ?: '-'; ?></span>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- 테스트 정보 -->
        <div class="test-info">
            <h4>📋 전체 LMS 데이터 (디버깅용)</h4>
            <pre><?php print_r($lmsData); ?></pre>
        </div>
        
        <div class="test-info">
            <h4>🔗 테스트 링크</h4>
            <p>
                <a href="index.php?section=dashboard" style="color: #60a5fa;">대시보드로 이동</a> | 
                <a href="test_lms_integration.php" style="color: #60a5fa;">LMS 통합 테스트</a> | 
                <a href="index.php" style="color: #60a5fa;">메인 인터페이스</a>
            </p>
        </div>
    </div>
</body>
</html>