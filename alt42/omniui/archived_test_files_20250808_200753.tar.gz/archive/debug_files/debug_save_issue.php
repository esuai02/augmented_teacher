<?php
header('Content-Type: text/plain; charset=utf-8');

include_once("/home/moodle/public_html/moodle/config.php"); 
global $DB, $USER;
require_login();

echo "=== MDL_ALT42T 저장 문제 디버깅 ===\n\n";

// 1. 테이블 존재 확인
$dbman = $DB->get_manager();
$table = new xmldb_table('alt42t_exam_user_info');

if ($dbman->table_exists($table)) {
    echo "✓ alt42t_exam_user_info 테이블이 존재합니다.\n\n";
    
    // 테이블 구조 확인
    try {
        $columns = $DB->get_columns('alt42t_exam_user_info');
        echo "테이블 컬럼 구조:\n";
        foreach ($columns as $column_name => $column_info) {
            echo "  - $column_name: " . $column_info->type . " (" . ($column_info->not_null ? 'NOT NULL' : 'NULL') . ")\n";
        }
        echo "\n";
    } catch (Exception $e) {
        echo "✗ 테이블 구조 확인 실패: " . $e->getMessage() . "\n\n";
    }
    
    // 현재 사용자의 데이터 확인
    try {
        $userid = $USER->id;
        echo "현재 사용자 ID: $userid\n";
        
        $existing = $DB->get_record('alt42t_exam_user_info', array('userid' => $userid));
        if ($existing) {
            echo "✓ 기존 데이터가 있습니다:\n";
            echo "  - ID: " . $existing->id . "\n";
            echo "  - School: " . ($existing->school ?? 'NULL') . "\n";
            echo "  - Grade: " . ($existing->grade ?? 'NULL') . "\n";
            echo "  - Exam Type: " . ($existing->exam_type ?? 'NULL') . "\n";
            echo "  - Time Created: " . date('Y-m-d H:i:s', $existing->timecreated) . "\n";
            echo "  - Time Modified: " . date('Y-m-d H:i:s', $existing->timemodified) . "\n";
        } else {
            echo "○ 현재 사용자의 데이터가 없습니다.\n";
        }
        echo "\n";
        
        // 전체 레코드 수 확인
        $count = $DB->count_records('alt42t_exam_user_info');
        echo "전체 레코드 수: $count\n\n";
        
    } catch (Exception $e) {
        echo "✗ 데이터 조회 실패: " . $e->getMessage() . "\n\n";
    }
    
} else {
    echo "✗ alt42t_exam_user_info 테이블이 존재하지 않습니다!\n";
    echo "  create_exam_user_info_table.php를 실행하여 테이블을 생성하세요.\n\n";
}

// 2. 테스트 저장
echo "=== 테스트 저장 시도 ===\n";
try {
    $testdata = new stdClass();
    $testdata->userid = $USER->id;
    $testdata->school = '테스트 학교';
    $testdata->grade = '2';
    $testdata->exam_type = '1mid';
    $testdata->timecreated = time();
    $testdata->timemodified = time();
    
    // 기존 레코드 확인
    $existing = $DB->get_record('alt42t_exam_user_info', array('userid' => $USER->id));
    
    if ($existing) {
        // 업데이트
        $testdata->id = $existing->id;
        $DB->update_record('alt42t_exam_user_info', $testdata);
        echo "✓ 테스트 데이터 업데이트 성공!\n";
    } else {
        // 삽입
        $id = $DB->insert_record('alt42t_exam_user_info', $testdata);
        echo "✓ 테스트 데이터 저장 성공! (ID: $id)\n";
    }
    
    // 저장된 데이터 확인
    $saved = $DB->get_record('alt42t_exam_user_info', array('userid' => $USER->id));
    echo "\n저장된 데이터:\n";
    echo "  - School: " . $saved->school . "\n";
    echo "  - Grade: " . $saved->grade . "\n";
    echo "  - Exam Type: " . $saved->exam_type . "\n";
    
} catch (Exception $e) {
    echo "✗ 테스트 저장 실패: " . $e->getMessage() . "\n";
    echo "상세 오류: " . $e->getTraceAsString() . "\n";
}

echo "\n=== 디버깅 완료 ===\n";
?>