<?php
// 디버깅을 위한 파일
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>Save Response 디버깅</h1>";

// 1. Moodle 설정 파일 확인
echo "<h2>1. Moodle 설정 파일 확인</h2>";
$config_file = "/home/moodle/public_html/moodle/config.php";
if (file_exists($config_file)) {
    echo "<p style='color:green'>✓ config.php 파일이 존재합니다.</p>";
} else {
    echo "<p style='color:red'>✗ config.php 파일을 찾을 수 없습니다.</p>";
}

// 2. Moodle 포함 시도
echo "<h2>2. Moodle 포함 시도</h2>";
try {
    include_once($config_file);
    echo "<p style='color:green'>✓ Moodle config 포함 성공</p>";
} catch (Exception $e) {
    echo "<p style='color:red'>✗ Moodle config 포함 실패: " . $e->getMessage() . "</p>";
}

// 3. 로그인 상태 확인
echo "<h2>3. 로그인 상태 확인</h2>";
try {
    global $DB, $USER;
    require_login();
    echo "<p style='color:green'>✓ 로그인 확인 완료 (User ID: {$USER->id})</p>";
} catch (Exception $e) {
    echo "<p style='color:red'>✗ 로그인 확인 실패: " . $e->getMessage() . "</p>";
}

// 4. 테이블 확인
echo "<h2>4. 테이블 확인</h2>";
try {
    $dbman = $DB->get_manager();
    $tables = ['alt42t_users', 'alt42t_exams', 'alt42t_exam_dates', 'alt42t_exam_user_info', 'alt42t_study_status'];
    
    foreach ($tables as $tablename) {
        $table = new xmldb_table($tablename);
        if ($dbman->table_exists($table)) {
            echo "<p style='color:green'>✓ {$tablename} 테이블 존재</p>";
        } else {
            echo "<p style='color:red'>✗ {$tablename} 테이블 없음</p>";
        }
    }
} catch (Exception $e) {
    echo "<p style='color:red'>✗ 테이블 확인 실패: " . $e->getMessage() . "</p>";
}

// 5. JSON 응답 테스트
echo "<h2>5. JSON 응답 테스트</h2>";
echo "<button onclick='testJson()'>JSON 테스트</button>";
echo "<div id='result'></div>";

?>

<script>
function testJson() {
    fetch('test_minimal_save.php')
        .then(response => {
            console.log('Response headers:', response.headers.get('content-type'));
            return response.text();
        })
        .then(text => {
            console.log('Raw response:', text);
            document.getElementById('result').innerHTML = '<pre>' + text + '</pre>';
            
            try {
                const json = JSON.parse(text);
                console.log('Parsed JSON:', json);
            } catch (e) {
                console.error('JSON parse error:', e);
            }
        })
        .catch(error => {
            console.error('Fetch error:', error);
            document.getElementById('result').innerHTML = '<p style="color:red">Error: ' + error + '</p>';
        });
}
</script>