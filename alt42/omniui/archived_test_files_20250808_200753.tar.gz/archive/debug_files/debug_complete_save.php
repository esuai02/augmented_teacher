<?php
header('Content-Type: text/html; charset=utf-8');

include_once("/home/moodle/public_html/moodle/config.php"); 
global $DB, $USER;
require_login();

?>
<!DOCTYPE html>
<html>
<head>
    <title>DB 저장 디버깅</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .section { margin: 20px 0; padding: 20px; border: 1px solid #ddd; }
        .success { color: green; }
        .error { color: red; }
        .info { color: blue; }
        pre { background: #f5f5f5; padding: 10px; overflow-x: auto; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
    </style>
</head>
<body>
    <h1>DB 저장 문제 완전 디버깅</h1>
    
    <div class="section">
        <h2>1. 테이블 존재 확인</h2>
        <?php
        $dbman = $DB->get_manager();
        $table = new xmldb_table('alt42t_exam_user_info');
        
        if ($dbman->table_exists($table)) {
            echo "<p class='success'>✓ alt42t_exam_user_info 테이블이 존재합니다.</p>";
            
            // 테이블 구조 확인
            $columns = $DB->get_columns('alt42t_exam_user_info');
            echo "<h3>테이블 구조:</h3>";
            echo "<table>";
            echo "<tr><th>컬럼명</th><th>타입</th><th>NULL 허용</th><th>기본값</th></tr>";
            
            foreach ($columns as $name => $info) {
                echo "<tr>";
                echo "<td>$name</td>";
                echo "<td>{$info->type}</td>";
                echo "<td>" . ($info->not_null ? 'NO' : 'YES') . "</td>";
                echo "<td>" . ($info->has_default ? $info->default_value : 'NULL') . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p class='error'>✗ alt42t_exam_user_info 테이블이 존재하지 않습니다!</p>";
            echo "<p>create_exam_user_info_table.php를 실행하여 테이블을 생성하세요.</p>";
        }
        ?>
    </div>
    
    <div class="section">
        <h2>2. 현재 사용자 데이터 확인</h2>
        <?php
        echo "<p>현재 사용자: {$USER->firstname} {$USER->lastname} (ID: {$USER->id})</p>";
        
        $existing = $DB->get_record('alt42t_exam_user_info', array('userid' => $USER->id));
        if ($existing) {
            echo "<p class='info'>기존 데이터가 있습니다:</p>";
            echo "<pre>" . print_r($existing, true) . "</pre>";
        } else {
            echo "<p class='info'>현재 사용자의 데이터가 없습니다.</p>";
        }
        ?>
    </div>
    
    <div class="section">
        <h2>3. 저장 테스트</h2>
        <h3>3-1. INSERT 테스트</h3>
        <?php
        if (!$existing) {
            try {
                $testdata = new stdClass();
                $testdata->userid = $USER->id;
                $testdata->school = '테스트 학교';
                $testdata->grade = '2';
                $testdata->exam_type = '1mid';
                $testdata->timecreated = time();
                $testdata->timemodified = time();
                
                echo "<p>삽입할 데이터:</p>";
                echo "<pre>" . print_r($testdata, true) . "</pre>";
                
                $id = $DB->insert_record('alt42t_exam_user_info', $testdata);
                echo "<p class='success'>✓ INSERT 성공! (ID: $id)</p>";
                
                // 저장된 데이터 확인
                $saved = $DB->get_record('alt42t_exam_user_info', array('id' => $id));
                echo "<p>저장된 데이터:</p>";
                echo "<pre>" . print_r($saved, true) . "</pre>";
                
            } catch (Exception $e) {
                echo "<p class='error'>✗ INSERT 실패: " . $e->getMessage() . "</p>";
                echo "<pre>상세 오류:\n" . $e->getTraceAsString() . "</pre>";
            }
        } else {
            echo "<p class='info'>이미 데이터가 존재하여 INSERT 테스트를 건너뜁니다.</p>";
        }
        ?>
        
        <h3>3-2. UPDATE 테스트</h3>
        <?php
        $existing = $DB->get_record('alt42t_exam_user_info', array('userid' => $USER->id));
        if ($existing) {
            try {
                $updatedata = clone $existing;
                $updatedata->school = '업데이트 테스트 ' . date('Y-m-d H:i:s');
                $updatedata->timemodified = time();
                
                echo "<p>업데이트할 데이터:</p>";
                echo "<pre>" . print_r($updatedata, true) . "</pre>";
                
                $DB->update_record('alt42t_exam_user_info', $updatedata);
                echo "<p class='success'>✓ UPDATE 성공!</p>";
                
                // 업데이트된 데이터 확인
                $updated = $DB->get_record('alt42t_exam_user_info', array('id' => $existing->id));
                echo "<p>업데이트된 데이터:</p>";
                echo "<pre>" . print_r($updated, true) . "</pre>";
                
            } catch (Exception $e) {
                echo "<p class='error'>✗ UPDATE 실패: " . $e->getMessage() . "</p>";
                echo "<pre>상세 오류:\n" . $e->getTraceAsString() . "</pre>";
            }
        } else {
            echo "<p class='info'>데이터가 없어 UPDATE 테스트를 할 수 없습니다.</p>";
        }
        ?>
    </div>
    
    <div class="section">
        <h2>4. AJAX 저장 테스트</h2>
        <button onclick="testSaveSection0()">Section 0 저장 테스트</button>
        <button onclick="testSaveSection1()">Section 1 저장 테스트</button>
        <button onclick="testSaveSection3()">Section 3 저장 테스트</button>
        <div id="ajax-result"></div>
        
        <script>
        async function testSaveSection0() {
            const data = {
                section: 0,
                userid: <?php echo $USER->id; ?>,
                school: 'AJAX 테스트 학교',
                grade: '3',
                examType: '2mid'
            };
            
            try {
                const response = await fetch('save_exam_data_simple.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                const result = await response.json();
                document.getElementById('ajax-result').innerHTML = 
                    '<pre>Section 0 결과:\n' + JSON.stringify(result, null, 2) + '</pre>';
            } catch (error) {
                document.getElementById('ajax-result').innerHTML = 
                    '<pre class="error">오류: ' + error.message + '</pre>';
            }
        }
        
        async function testSaveSection1() {
            const data = {
                section: 1,
                userid: <?php echo $USER->id; ?>,
                startDate: '2024-03-01',
                endDate: '2024-03-05',
                mathDate: '2024-03-03',
                status: '확정',
                examScope: '1단원~3단원'
            };
            
            try {
                const response = await fetch('save_exam_data_simple.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                const result = await response.json();
                document.getElementById('ajax-result').innerHTML = 
                    '<pre>Section 1 결과:\n' + JSON.stringify(result, null, 2) + '</pre>';
            } catch (error) {
                document.getElementById('ajax-result').innerHTML = 
                    '<pre class="error">오류: ' + error.message + '</pre>';
            }
        }
        
        async function testSaveSection3() {
            const data = {
                section: 3,
                userid: <?php echo $USER->id; ?>,
                studyStatus: '개념공부'
            };
            
            try {
                const response = await fetch('save_exam_data_simple.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                const result = await response.json();
                document.getElementById('ajax-result').innerHTML = 
                    '<pre>Section 3 결과:\n' + JSON.stringify(result, null, 2) + '</pre>';
            } catch (error) {
                document.getElementById('ajax-result').innerHTML = 
                    '<pre class="error">오류: ' + error.message + '</pre>';
            }
        }
        </script>
    </div>
    
    <div class="section">
        <h2>5. 전체 데이터 확인</h2>
        <?php
        $all_records = $DB->get_records('alt42t_exam_user_info', null, 'id DESC', '*', 0, 10);
        echo "<p>최근 10개 레코드:</p>";
        echo "<table>";
        echo "<tr><th>ID</th><th>UserID</th><th>School</th><th>Grade</th><th>Exam Type</th><th>Created</th><th>Modified</th></tr>";
        
        foreach ($all_records as $record) {
            echo "<tr>";
            echo "<td>{$record->id}</td>";
            echo "<td>{$record->userid}</td>";
            echo "<td>{$record->school}</td>";
            echo "<td>{$record->grade}</td>";
            echo "<td>{$record->exam_type}</td>";
            echo "<td>" . date('Y-m-d H:i:s', $record->timecreated) . "</td>";
            echo "<td>" . date('Y-m-d H:i:s', $record->timemodified) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        $total = $DB->count_records('alt42t_exam_user_info');
        echo "<p>전체 레코드 수: $total</p>";
        ?>
    </div>
    
    <div class="section">
        <h2>6. 권한 확인</h2>
        <?php
        echo "<p>현재 사용자 권한:</p>";
        echo "<ul>";
        echo "<li>로그인 상태: " . (isloggedin() ? "예" : "아니오") . "</li>";
        echo "<li>게스트 사용자: " . (isguestuser() ? "예" : "아니오") . "</li>";
        echo "<li>사이트 관리자: " . (is_siteadmin() ? "예" : "아니오") . "</li>";
        echo "</ul>";
        
        // 데이터베이스 권한 테스트
        try {
            $test = new stdClass();
            $test->name = 'permission_test_' . time();
            
            // 임시 테이블에 쓰기 테스트
            $DB->execute("CREATE TEMPORARY TABLE test_permission (id INT)");
            echo "<p class='success'>✓ 데이터베이스 쓰기 권한이 있습니다.</p>";
            $DB->execute("DROP TEMPORARY TABLE IF EXISTS test_permission");
        } catch (Exception $e) {
            echo "<p class='error'>✗ 데이터베이스 쓰기 권한 문제: " . $e->getMessage() . "</p>";
        }
        ?>
    </div>
</body>
</html>