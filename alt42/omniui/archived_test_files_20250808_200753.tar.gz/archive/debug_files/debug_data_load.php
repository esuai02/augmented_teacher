<?php
header('Content-Type: application/json; charset=utf-8');

require_once('/home/moodle/public_html/moodle/config.php');
require_once(__DIR__ . '/get_exam_data_alt42t.php');
global $DB, $USER;
require_login();

$debug_info = [
    'current_user_id' => $USER->id,
    'tables_check' => [],
    'user_data' => null,
    'exam_data' => null,
    'date_data' => null,
    'combined_data' => null
];

// 1. 테이블 존재 확인
$dbman = $DB->get_manager();
$tables = ['alt42t_users', 'alt42t_exams', 'alt42t_exam_dates', 'alt42t_study_status', 'alt42t_exam_resources'];

foreach ($tables as $table) {
    $table_obj = new xmldb_table($table);
    $exists = $dbman->table_exists($table_obj);
    $debug_info['tables_check'][$table] = $exists ? 'exists' : 'missing';
}

// 2. alt42t_users 데이터 확인
try {
    $user_record = $DB->get_record('alt42t_users', array('userid' => $USER->id));
    $debug_info['user_data'] = $user_record ?: 'No user record found';
} catch (Exception $e) {
    $debug_info['user_data'] = 'Error: ' . $e->getMessage();
}

// 3. alt42t_exams 데이터 확인
if ($user_record) {
    try {
        $exam_records = $DB->get_records('alt42t_exams', array(
            'school_name' => $user_record->school_name,
            'grade' => $user_record->grade
        ));
        $debug_info['exam_data'] = $exam_records ?: 'No exam records found';
        
        // 4. 각 시험에 대한 날짜 정보 확인
        if ($exam_records) {
            foreach ($exam_records as $exam) {
                $date_record = $DB->get_record('alt42t_exam_dates', array(
                    'exam_id' => $exam->exam_id,
                    'user_id' => $user_record->id
                ));
                $debug_info['date_data'][$exam->exam_id] = $date_record ?: 'No date record';
            }
        }
    } catch (Exception $e) {
        $debug_info['exam_data'] = 'Error: ' . $e->getMessage();
    }
}

// 5. getExamDataFromAlt42t 함수 테스트
try {
    $combined_data = getExamDataFromAlt42t($USER->id);
    $debug_info['combined_data'] = $combined_data ?: 'No combined data';
} catch (Exception $e) {
    $debug_info['combined_data'] = 'Error: ' . $e->getMessage();
}

echo json_encode($debug_info, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>