<?php
header('Content-Type: text/plain; charset=utf-8');

require_once('/home/moodle/public_html/moodle/config.php');
global $DB, $USER;
require_login();

echo "=== 데이터베이스 저장 문제 디버깅 ===\n\n";

// 1. 현재 사용자 정보
echo "1. 현재 사용자 ID: " . $USER->id . "\n\n";

// 2. alt42t_users 확인
echo "2. alt42t_users 테이블 확인:\n";
$user_records = $DB->get_records('alt42t_users', array('userid' => $USER->id));
foreach ($user_records as $record) {
    echo "   - ID: {$record->id}, School: {$record->school_name}, Grade: {$record->grade}\n";
}
echo "\n";

// 3. alt42t_exam_dates 전체 레코드 확인
echo "3. alt42t_exam_dates 테이블 전체 레코드:\n";
$all_dates = $DB->get_records('alt42t_exam_dates');
if (empty($all_dates)) {
    echo "   테이블이 비어있습니다!\n";
} else {
    foreach ($all_dates as $date) {
        echo "   - exam_date_id: {$date->exam_date_id}, exam_id: {$date->exam_id}, user_id: {$date->user_id}, ";
        echo "start: {$date->start_date}, end: {$date->end_date}, math: {$date->math_date}\n";
    }
}
echo "\n";

// 4. 가장 최근 exam_id 22에 대한 직접 쿼리
echo "4. exam_id = 22에 대한 직접 확인:\n";
$exam_22_dates = $DB->get_records('alt42t_exam_dates', array('exam_id' => 22));
if ($exam_22_dates) {
    foreach ($exam_22_dates as $date) {
        echo "   발견! ";
        print_r($date);
    }
} else {
    echo "   exam_id 22에 대한 날짜 레코드가 없습니다.\n";
}
echo "\n";

// 5. user_id 17에 대한 직접 쿼리
echo "5. user_id = 17에 대한 직접 확인:\n";
$user_17_dates = $DB->get_records('alt42t_exam_dates', array('user_id' => 17));
if ($user_17_dates) {
    foreach ($user_17_dates as $date) {
        echo "   발견! ";
        print_r($date);
    }
} else {
    echo "   user_id 17에 대한 날짜 레코드가 없습니다.\n";
}
echo "\n";

// 6. SQL로 직접 조회
echo "6. SQL 직접 조회 (최근 10개):\n";
try {
    $sql = "SELECT * FROM {alt42t_exam_dates} ORDER BY exam_date_id DESC LIMIT 10";
    $records = $DB->get_records_sql($sql);
    foreach ($records as $record) {
        echo "   - exam_date_id: {$record->exam_date_id}, exam_id: {$record->exam_id}, user_id: {$record->user_id}\n";
    }
} catch (Exception $e) {
    echo "   SQL 오류: " . $e->getMessage() . "\n";
}
echo "\n";

// 7. alt42t_exam_resources 확인 (시험 범위)
echo "7. alt42t_exam_resources 테이블 확인:\n";
$resources = $DB->get_records('alt42t_exam_resources');
if (empty($resources)) {
    echo "   테이블이 비어있습니다!\n";
} else {
    foreach ($resources as $resource) {
        echo "   - resource_id: {$resource->resource_id}, exam_id: {$resource->exam_id}, ";
        echo "user_id: {$resource->user_id}, tip: " . substr($resource->tip_text, 0, 50) . "...\n";
    }
}

echo "\n=== 결론 ===\n";
echo "combined_data에 날짜가 있다는 것은 다른 방식으로 저장되었을 가능성이 있습니다.\n";
echo "위 정보를 확인하여 실제로 어디에 데이터가 저장되었는지 파악해보세요.\n";
?>