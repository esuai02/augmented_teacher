<?php
// 출력 버퍼 초기화
ob_start();

try {
    // Moodle 설정
    require_once('/home/moodle/public_html/moodle/config.php');
    global $DB, $USER;
    
    // 세션 체크 (리다이렉트 방지)
    if (!isloggedin() || isguestuser()) {
        ob_clean();
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array(
            'success' => false,
            'message' => '로그인이 필요합니다'
        ), JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    // POST 데이터
    $input = json_decode(file_get_contents("php://input"), true);
    
    if (!$input) {
        ob_clean();
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array(
            'success' => false,
            'message' => '입력 데이터가 없습니다'
        ), JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    // 테이블 이름 (Moodle은 자동으로 prefix 처리)
    $table_name = 'alt42t_exam_user_info';
    
    $section = isset($input['section']) ? intval($input['section']) : 0;
    
    // 섹션별 처리
    if ($section == 0) {
        $record = $DB->get_record($table_name, array('userid' => $USER->id));
        
        if ($record) {
            // UPDATE
            $record->school = $input['school'] ?? $record->school;
            $record->grade = $input['grade'] ?? $record->grade;
            $record->exam_type = $input['examType'] ?? $record->exam_type;
            $record->timemodified = time();
            
            $DB->update_record($table_name, $record);
            
            $response = array(
                'success' => true,
                'message' => '정보가 업데이트되었습니다'
            );
        } else {
            // INSERT
            $record = new stdClass();
            $record->userid = $USER->id;
            $record->school = $input['school'] ?? '';
            $record->grade = $input['grade'] ?? '';
            $record->exam_type = $input['examType'] ?? '';
            $record->timecreated = time();
            $record->timemodified = time();
            
            $DB->insert_record($table_name, $record);
            
            $response = array(
                'success' => true,
                'message' => '정보가 저장되었습니다'
            );
        }
    } else if ($section == 1) {
        // 섹션 1: 시험 일정
        $record = $DB->get_record($table_name, array('userid' => $USER->id));
        
        if (!$record) {
            $response = array(
                'success' => false,
                'message' => '기본 정보를 먼저 저장해주세요'
            );
        } else {
            if (isset($input['startDate'])) $record->exam_start_date = $input['startDate'];
            if (isset($input['endDate'])) $record->exam_end_date = $input['endDate'];
            if (isset($input['mathDate'])) $record->math_exam_date = $input['mathDate'];
            if (isset($input['status'])) $record->exam_status = $input['status'];
            if (isset($input['examScope'])) $record->exam_scope = $input['examScope'];
            $record->timemodified = time();
            
            $DB->update_record($table_name, $record);
            
            $response = array(
                'success' => true,
                'message' => '시험 일정이 저장되었습니다'
            );
        }
    } else if ($section == 3) {
        // 섹션 3: 학습 상태
        $record = $DB->get_record($table_name, array('userid' => $USER->id));
        
        if (!$record) {
            $response = array(
                'success' => false,
                'message' => '기본 정보를 먼저 저장해주세요'
            );
        } else {
            $record->study_status = $input['studyStatus'] ?? '';
            $record->timemodified = time();
            
            $DB->update_record($table_name, $record);
            
            $response = array(
                'success' => true,
                'message' => '학습 상태가 저장되었습니다'
            );
        }
    } else {
        $response = array(
            'success' => false,
            'message' => '잘못된 섹션입니다: ' . $section
        );
    }
    
} catch (Exception $e) {
    $response = array(
        'success' => false,
        'message' => '오류: ' . $e->getMessage()
    );
}

// 출력
ob_clean();
header('Content-Type: application/json; charset=utf-8');
echo json_encode($response, JSON_UNESCAPED_UNICODE);
exit;
?>