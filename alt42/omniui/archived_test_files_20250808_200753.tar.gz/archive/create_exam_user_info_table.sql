-- alt42t_exam_user_info 테이블 생성
-- 사용자의 시험 정보를 저장하는 테이블

CREATE TABLE IF NOT EXISTS `mdl_alt42t_exam_user_info` (
    `id` bigint(10) NOT NULL AUTO_INCREMENT,
    `userid` bigint(10) NOT NULL,
    `school` varchar(255) DEFAULT NULL COMMENT '학교명',
    `grade` int(2) DEFAULT NULL COMMENT '학년 (1-3)',
    `exam_type` varchar(50) DEFAULT NULL COMMENT '시험 종류 (1mid, 1final, 2mid, 2final)',
    `exam_start_date` date DEFAULT NULL COMMENT '시험 시작일',
    `exam_end_date` date DEFAULT NULL COMMENT '시험 종료일',
    `math_exam_date` date DEFAULT NULL COMMENT '수학 시험일',
    `exam_scope` text DEFAULT NULL COMMENT '시험 범위',
    `exam_status` varchar(20) DEFAULT NULL COMMENT '시험 상태 (확정/예상)',
    `study_status` varchar(50) DEFAULT NULL COMMENT '학습 상태 (개념공부/개념복습/유형공부)',
    `created_at` bigint(10) NOT NULL COMMENT '생성 시간',
    `updated_at` bigint(10) DEFAULT NULL COMMENT '수정 시간',
    PRIMARY KEY (`id`),
    KEY `userid_idx` (`userid`),
    KEY `school_grade_idx` (`school`, `grade`),
    KEY `exam_type_idx` (`exam_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='사용자 시험 정보 테이블';

-- 외래키 제약조건 추가 (선택사항)
-- ALTER TABLE `mdl_alt42t_exam_user_info` 
-- ADD CONSTRAINT `fk_exam_user_info_userid` 
-- FOREIGN KEY (`userid`) REFERENCES `mdl_user` (`id`) ON DELETE CASCADE;