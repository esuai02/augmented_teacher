<?php
header('Content-Type: application/json; charset=utf-8');

include_once("/home/moodle/public_html/moodle/config.php");
global $DB, $USER;
require_login();

$school = optional_param('school', '', PARAM_TEXT);
$grade = optional_param('grade', '', PARAM_INT);
$examType = optional_param('examType', '', PARAM_TEXT);

$response = array('success' => false);

try {
    if (empty($school) || empty($grade) || empty($examType)) {
        throw new Exception('필수 정보가 부족합니다');
    }
    
    // 같은 학교, 학년의 과거 시험 데이터 조회
    $sql = "SELECT 
            AVG(UNIX_TIMESTAMP(exam_start_date)) as avg_start_ts,
            AVG(UNIX_TIMESTAMP(exam_end_date)) as avg_end_ts,
            AVG(UNIX_TIMESTAMP(math_exam_date)) as avg_math_ts,
            GROUP_CONCAT(DISTINCT exam_scope SEPARATOR ', ') as scopes,
            COUNT(DISTINCT userid) as sample_count
        FROM {alt42t_exam_user_info} 
        WHERE school = ? 
        AND grade = ? 
        AND exam_type = ?
        AND exam_status = 'confirmed'
        AND exam_start_date IS NOT NULL
        AND YEAR(exam_start_date) >= YEAR(CURDATE()) - 2";
    
    $params = array($school, $grade, $examType);
    $historicalData = $DB->get_record_sql($sql, $params);
    
    if ($historicalData && $historicalData->sample_count > 0) {
        // 평균 날짜 계산
        $avgStartDate = date('Y-m-d', $historicalData->avg_start_ts);
        $avgEndDate = date('Y-m-d', $historicalData->avg_end_ts);
        $avgMathDate = date('Y-m-d', $historicalData->avg_math_ts);
        
        // 현재 연도로 날짜 조정
        $currentYear = date('Y');
        $avgStartDate = adjustDateToCurrentYear($avgStartDate, $examType);
        $avgEndDate = adjustDateToCurrentYear($avgEndDate, $examType);
        $avgMathDate = adjustDateToCurrentYear($avgMathDate, $examType);
        
        // 시험 범위 분석 (가장 많이 나타나는 패턴 찾기)
        $commonScope = analyzeExamScopes($historicalData->scopes);
        
        $response['success'] = true;
        $response['data'] = array(
            'avg_start_date' => $avgStartDate,
            'avg_end_date' => $avgEndDate,
            'avg_math_date' => $avgMathDate,
            'common_scope' => $commonScope,
            'sample_count' => $historicalData->sample_count,
            'confidence' => calculateConfidence($historicalData->sample_count)
        );
    } else {
        // 과거 데이터가 없는 경우 일반적인 시험 일정 제공
        $response['success'] = true;
        $response['data'] = getDefaultExamDates($examType);
        $response['data']['is_default'] = true;
    }
    
} catch (Exception $e) {
    $response['error'] = $e->getMessage();
}

echo json_encode($response, JSON_UNESCAPED_UNICODE);

// 날짜를 현재 연도로 조정하는 함수
function adjustDateToCurrentYear($date, $examType) {
    $currentYear = date('Y');
    $dateObj = new DateTime($date);
    
    // 시험 종류에 따라 적절한 연도 설정
    if (strpos($examType, '1') === 0) {
        // 1학기 시험 (3-7월)
        $dateObj->setDate($currentYear, $dateObj->format('m'), $dateObj->format('d'));
    } else {
        // 2학기 시험 (9-12월)
        $dateObj->setDate($currentYear, $dateObj->format('m'), $dateObj->format('d'));
    }
    
    return $dateObj->format('Y-m-d');
}

// 시험 범위 분석 함수
function analyzeExamScopes($scopesStr) {
    if (empty($scopesStr)) return '';
    
    $scopes = explode(', ', $scopesStr);
    $patterns = array();
    
    // 패턴 분석 (단원 숫자 추출)
    foreach ($scopes as $scope) {
        preg_match_all('/(\d+)단원/', $scope, $matches);
        if (!empty($matches[1])) {
            $units = $matches[1];
            sort($units);
            $pattern = implode('-', $units);
            $patterns[$pattern] = ($patterns[$pattern] ?? 0) + 1;
        }
    }
    
    // 가장 빈번한 패턴 찾기
    if (!empty($patterns)) {
        arsort($patterns);
        $mostCommon = array_key_first($patterns);
        $units = explode('-', $mostCommon);
        
        if (count($units) >= 2) {
            return $units[0] . '단원 ~ ' . $units[count($units) - 1] . '단원';
        }
    }
    
    return '1단원 ~ 3단원 (예상)';
}

// 신뢰도 계산 함수
function calculateConfidence($sampleCount) {
    if ($sampleCount >= 10) return 'high';
    if ($sampleCount >= 5) return 'medium';
    return 'low';
}

// 기본 시험 날짜 제공 함수
function getDefaultExamDates($examType) {
    $currentYear = date('Y');
    
    $defaults = array(
        '1mid' => array(
            'avg_start_date' => $currentYear . '-04-22',
            'avg_end_date' => $currentYear . '-04-26',
            'avg_math_date' => $currentYear . '-04-24',
            'common_scope' => '1단원 ~ 3단원'
        ),
        '1final' => array(
            'avg_start_date' => $currentYear . '-07-01',
            'avg_end_date' => $currentYear . '-07-05',
            'avg_math_date' => $currentYear . '-07-03',
            'common_scope' => '1단원 ~ 5단원'
        ),
        '2mid' => array(
            'avg_start_date' => $currentYear . '-10-14',
            'avg_end_date' => $currentYear . '-10-18',
            'avg_math_date' => $currentYear . '-10-16',
            'common_scope' => '1단원 ~ 3단원'
        ),
        '2final' => array(
            'avg_start_date' => $currentYear . '-12-09',
            'avg_end_date' => $currentYear . '-12-13',
            'avg_math_date' => $currentYear . '-12-11',
            'common_scope' => '1단원 ~ 5단원'
        )
    );
    
    return $defaults[$examType] ?? $defaults['1mid'];
}
?>