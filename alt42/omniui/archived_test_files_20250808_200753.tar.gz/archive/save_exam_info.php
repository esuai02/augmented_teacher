<?php
/**
 * Alt42 시험 정보 저장 API
 * 실제 서버 환경용 - 모든 Alt42 테이블 활용
 */

header("Content-Type: application/json; charset=UTF-8");

// 디버깅용 에러 로그
error_reporting(E_ALL);
ini_set('display_errors', 1);

// 실제 서버 DB 접속 정보 (Moodle 방식)
$CFG = new stdClass();
$CFG->dbhost = '58.180.27.46';
$CFG->dbname = 'mathking';
$CFG->dbuser = 'moodle';
$CFG->dbpass = '@MCtrigd7128';
$CFG->prefix = 'mdl_';

$db_config = [ 
    'host' => $CFG->dbhost,
    'dbname' => $CFG->dbname,
    'username' => $CFG->dbuser,
    'password' => $CFG->dbpass,
    'charset' => 'utf8mb4'
];

try {
    // PDO 연결
    $dsn = "mysql:host={$db_config['host']};dbname={$db_config['dbname']};charset={$db_config['charset']}";
    $pdo = new PDO($dsn, $db_config['username'], $db_config['password'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);

    // JSON 입력 데이터 받기
    $raw_input = file_get_contents("php://input");
    $input = json_decode($raw_input, true);
    
    // 디버깅: 받은 데이터 로그
    error_log("Received data: " . $raw_input);
    error_log("Parsed data: " . print_r($input, true));
    
    if (!$input) {
        throw new Exception("잘못된 JSON 데이터: " . $raw_input);
    }

    // 섹션 정보 확인
    $section = intval($input['section'] ?? -1);
    
    error_log("Section: " . $section);
    
    if ($section < 0 || $section > 3) {
        throw new Exception("잘못된 섹션 번호: " . $section);
    }

    $current_time = time();
    $current_datetime = date('Y-m-d H:i:s');

    // 트랜잭션 시작
    $pdo->beginTransaction();

    // examType 매핑 (ID to 한글명)
    $examTypeMap = [
        '1mid' => '1학기 중간고사',
        '1final' => '1학기 기말고사',
        '2mid' => '2학기 중간고사',
        '2final' => '2학기 기말고사'
    ];

    // 섹션별 처리
    if ($section == 0) {
        // ===== Section 0: 기본 정보 저장 (학교명, 학년, 시험종류) =====
        
        $school = trim($input['school'] ?? '');
        $grade = intval($input['grade'] ?? 0);
        $examType = trim($input['examType'] ?? '');
        
        if (empty($school) || $grade < 1 || $grade > 3 || empty($examType)) {
            throw new Exception("필수 데이터가 누락되었거나 잘못되었습니다");
        }

        $examTypeName = $examTypeMap[$examType] ?? $examType;
        $user_name = '익명 사용자'; // 기본값

        // exam_id 생성 규칙: "{school_name}_{grade}_{exam_type}"
        $exam_id = $school . '_' . $grade . '_' . $examType;

        // 1. 사용자 정보 저장/확인 (mdl_alt42t_users)
        $stmt = $pdo->prepare("SELECT user_id FROM mdl_alt42t_users WHERE school_name = ? AND grade = ?");
        $stmt->execute([$school, $grade]);
        $existing_user = $stmt->fetch();

        if ($existing_user) {
            $user_id = $existing_user['user_id'];
            $stmt = $pdo->prepare("UPDATE mdl_alt42t_users SET timemodified = ? WHERE user_id = ?");
            $stmt->execute([$current_time, $user_id]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO mdl_alt42t_users (name, school_name, grade, created_at, userid, timecreated, timemodified) VALUES (?, ?, ?, ?, 0, ?, ?)");
            $stmt->execute([$user_name, $school, $grade, $current_datetime, $current_time, $current_time]);
            $user_id = $pdo->lastInsertId();
        }

        // 2. 시험 정보 저장/확인 (mdl_alt42t_exams) - 중복 방지
        // 기존 데이터를 school_name, grade, exam_type 조합으로 확인
        $stmt = $pdo->prepare("SELECT exam_id FROM mdl_alt42t_exams WHERE school_name = ? AND grade = ? AND exam_type = ?");
        $stmt->execute([$school, $grade, $examTypeName]);
        $existing_exam = $stmt->fetch();

        error_log("Section 0 - school: $school, grade: $grade, examType: $examType, examTypeName: $examTypeName");
        
        if ($existing_exam) {
            // 기존 시험 정보가 있으면 해당 exam_id 사용
            $exam_id = $existing_exam['exam_id'];
            error_log("Section 0 - 기존 exam_id 사용: " . $exam_id);
        } else {
            // 새 시험 정보 생성 - AUTO_INCREMENT 사용
            try {
                error_log("Section 0 - 새 시험 정보 생성 시도");
                $stmt = $pdo->prepare("INSERT INTO mdl_alt42t_exams (school_name, grade, exam_type, userid, timecreated, timemodified) VALUES (?, ?, ?, 0, ?, ?)");
                $stmt->execute([$school, $grade, $examTypeName, $current_time, $current_time]);
                $exam_id = $pdo->lastInsertId();
                error_log("Section 0 - 새 exam_id 생성: " . $exam_id);
            } catch (PDOException $e) {
                error_log("Section 0 - INSERT 실패: " . $e->getMessage());
                // 중복 삽입 시도 시 기존 데이터 조회
                if ($e->getCode() == 23000) { // Integrity constraint violation
                    $stmt = $pdo->prepare("SELECT exam_id FROM mdl_alt42t_exams WHERE school_name = ? AND grade = ? AND exam_type = ?");
                    $stmt->execute([$school, $grade, $examTypeName]);
                    $existing_exam = $stmt->fetch();
                    if ($existing_exam) {
                        $exam_id = $existing_exam['exam_id'];
                        error_log("Section 0 - 중복 오류 후 기존 exam_id 사용: " . $exam_id);
                    } else {
                        throw $e;
                    }
                } else {
                    throw $e;
                }
            }
        }

        $response_data = [
            "user_id" => $user_id,
            "exam_id" => $exam_id,
            "school" => $school,
            "grade" => $grade,
            "exam_type" => $examTypeName
        ];

    } elseif ($section == 1) {
        // ===== Section 1: 시험 일정 저장 =====
        
        $school = trim($input['school'] ?? '');
        $grade = intval($input['grade'] ?? 0);
        $examType = trim($input['examType'] ?? '');
        $startDate = trim($input['startDate'] ?? '');
        $endDate = trim($input['endDate'] ?? '');
        $mathDate = trim($input['mathDate'] ?? '');
        $status = trim($input['status'] ?? '예상');
        $examScope = trim($input['examScope'] ?? ''); // 시험 범위 추가

        if (empty($school) || $grade < 1 || $grade > 3 || empty($examType) || 
            empty($startDate) || empty($endDate) || empty($mathDate)) {
            throw new Exception("필수 데이터가 누락되었습니다");
        }

        $examTypeName = $examTypeMap[$examType] ?? $examType;

        // 기존 시험 정보 조회 (school_name, grade, exam_type 조합으로)
        $stmt = $pdo->prepare("SELECT exam_id FROM mdl_alt42t_exams WHERE school_name = ? AND grade = ? AND exam_type = ?");
        $stmt->execute([$school, $grade, $examTypeName]);
        $exam_info = $stmt->fetch();

        if (!$exam_info) {
            throw new Exception("기본 정보가 먼저 입력되어야 합니다");
        }

        $exam_id = $exam_info['exam_id'];
        
        // exam_date_id 생성 규칙: "{exam_id}_{start_date}_{end_date}_{math_date}_{status}"
        $exam_date_id = $exam_id . '_' . $startDate . '_' . $endDate . '_' . $mathDate . '_' . $status;

        // 사용자 정보 조회
        $stmt = $pdo->prepare("SELECT user_id FROM mdl_alt42t_users WHERE school_name = ? AND grade = ?");
        $stmt->execute([$school, $grade]);
        $user_info = $stmt->fetch();

        if (!$user_info) {
            throw new Exception("기본 정보가 먼저 입력되어야 합니다");
        }

        $user_id = $user_info['user_id'];

        // 시험 일정 저장/업데이트 (mdl_alt42t_exam_dates) - 중복 방지
        error_log("Section 1 - exam_id: " . $exam_id . ", user_id: " . $user_id . ", exam_date_id: " . $exam_date_id);
        
        // 기존 데이터 확인 (같은 exam_id, user_id 조합으로)
        $stmt = $pdo->prepare("SELECT exam_date_id FROM mdl_alt42t_exam_dates WHERE exam_id = ? AND user_id = ?");
        $stmt->execute([$exam_id, $user_id]);
        $existing_date = $stmt->fetch();

        if ($existing_date) {
            // 기존 시험 일정 업데이트
            error_log("Section 1 - 기존 데이터 업데이트: " . $existing_date['exam_date_id']);
            // exam_scope 컬럼이 있는지 확인하고 업데이트
            try {
                $stmt = $pdo->prepare("UPDATE mdl_alt42t_exam_dates SET start_date = ?, end_date = ?, math_date = ?, status = ?, exam_scope = ?, timemodified = ? WHERE exam_date_id = ?");
                $stmt->execute([$startDate, $endDate, $mathDate, $status, $examScope, $current_time, $existing_date['exam_date_id']]);
            } catch (PDOException $e) {
                // exam_scope 컬럼이 없으면 기본 업데이트
                error_log("Section 1 - exam_scope 컬럼 없음, 기본 업데이트 수행");
                $stmt = $pdo->prepare("UPDATE mdl_alt42t_exam_dates SET start_date = ?, end_date = ?, math_date = ?, status = ?, timemodified = ? WHERE exam_date_id = ?");
                $stmt->execute([$startDate, $endDate, $mathDate, $status, $current_time, $existing_date['exam_date_id']]);
            }
            $final_exam_date_id = $existing_date['exam_date_id'];
        } else {
            // 새 시험 일정 생성 - AUTO_INCREMENT 사용
            try {
                error_log("Section 1 - 새 데이터 생성 시도");
                // exam_scope 컬럼 포함하여 INSERT 시도
                $stmt = $pdo->prepare("INSERT INTO mdl_alt42t_exam_dates (exam_id, user_id, start_date, end_date, math_date, status, exam_scope, created_at, userid, timecreated, timemodified) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)");
                $stmt->execute([$exam_id, $user_id, $startDate, $endDate, $mathDate, $status, $examScope, $current_datetime, $current_time, $current_time]);
                $final_exam_date_id = $pdo->lastInsertId();
                error_log("Section 1 - 새 exam_date_id 생성: " . $final_exam_date_id);
            } catch (PDOException $e) {
                error_log("Section 1 - INSERT 실패: " . $e->getMessage());
                
                // exam_scope 컬럼이 없는 경우 기본 INSERT 시도
                if (strpos($e->getMessage(), 'exam_scope') !== false) {
                    error_log("Section 1 - exam_scope 컬럼 없음, 기본 INSERT 수행");
                    try {
                        $stmt = $pdo->prepare("INSERT INTO mdl_alt42t_exam_dates (exam_id, user_id, start_date, end_date, math_date, status, created_at, userid, timecreated, timemodified) VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, ?)");
                        $stmt->execute([$exam_id, $user_id, $startDate, $endDate, $mathDate, $status, $current_datetime, $current_time, $current_time]);
                        $final_exam_date_id = $pdo->lastInsertId();
                        error_log("Section 1 - 기본 INSERT로 새 exam_date_id 생성: " . $final_exam_date_id);
                    } catch (PDOException $e2) {
                        if ($e2->getCode() == 23000) {
                            // 중복 처리
                            $stmt = $pdo->prepare("SELECT exam_date_id FROM mdl_alt42t_exam_dates WHERE exam_id = ? AND user_id = ?");
                            $stmt->execute([$exam_id, $user_id]);
                            $retry_existing = $stmt->fetch();
                            if ($retry_existing) {
                                $final_exam_date_id = $retry_existing['exam_date_id'];
                                error_log("Section 1 - 재시도로 기존 데이터 사용: " . $final_exam_date_id);
                            } else {
                                throw $e2;
                            }
                        } else {
                            throw $e2;
                        }
                    }
                } else if ($e->getCode() == 23000) {
                    // 일반적인 중복 처리
                    $stmt = $pdo->prepare("SELECT exam_date_id FROM mdl_alt42t_exam_dates WHERE exam_id = ? AND user_id = ?");
                    $stmt->execute([$exam_id, $user_id]);
                    $retry_existing = $stmt->fetch();
                    if ($retry_existing) {
                        $final_exam_date_id = $retry_existing['exam_date_id'];
                        error_log("Section 1 - 재시도로 기존 데이터 사용: " . $final_exam_date_id);
                    } else {
                        throw $e;
                    }
                } else {
                    throw $e;
                }
            }
        }

        $response_data = [
            "user_id" => $user_id,
            "exam_id" => $exam_id,
            "exam_date_id" => $final_exam_date_id,
            "start_date" => $startDate,
            "end_date" => $endDate,
            "math_date" => $mathDate,
            "status" => $status,
            "exam_scope" => $examScope
        ];

    } elseif ($section == 3) {
        // ===== Section 3: 학습 상태 저장 =====
        
        $school = trim($input['school'] ?? '');
        $grade = intval($input['grade'] ?? 0);
        $examType = trim($input['examType'] ?? '');
        $studyStatus = trim($input['studyStatus'] ?? '');

        if (empty($school) || $grade < 1 || $grade > 3 || empty($examType) || empty($studyStatus)) {
            throw new Exception("필수 데이터가 누락되었습니다");
        }

        $examTypeName = $examTypeMap[$examType] ?? $examType;

        // 기존 시험 정보 조회 (school_name, grade, exam_type 조합으로)
        $stmt = $pdo->prepare("SELECT exam_id FROM mdl_alt42t_exams WHERE school_name = ? AND grade = ? AND exam_type = ?");
        $stmt->execute([$school, $grade, $examTypeName]);
        $exam_info = $stmt->fetch();

        if (!$exam_info) {
            throw new Exception("기본 정보가 먼저 입력되어야 합니다");
        }

        $exam_id = $exam_info['exam_id'];

        // 사용자 정보 조회
        $stmt = $pdo->prepare("SELECT user_id FROM mdl_alt42t_users WHERE school_name = ? AND grade = ?");
        $stmt->execute([$school, $grade]);
        $user_info = $stmt->fetch();

        if (!$user_info) {
            throw new Exception("기본 정보가 먼저 입력되어야 합니다");
        }

        $user_id = $user_info['user_id'];

        // status_id 생성 규칙: "{exam_id}_{user_id}_{timestamp}"
        $status_id = $exam_id . '_' . $user_id . '_' . $current_time;

        // 학습 상태 저장/업데이트 (mdl_alt42t_study_status) - 중복 방지
        error_log("Section 3 - exam_id: " . $exam_id . ", user_id: " . $user_id . ", studyStatus: " . $studyStatus);
        
        $stmt = $pdo->prepare("SELECT status_id FROM mdl_alt42t_study_status WHERE exam_id = ? AND user_id = ?");
        $stmt->execute([$exam_id, $user_id]);
        $existing_status = $stmt->fetch();

        if ($existing_status) {
            // 기존 상태 업데이트
            error_log("Section 3 - 기존 데이터 업데이트: " . $existing_status['status_id']);
            $stmt = $pdo->prepare("UPDATE mdl_alt42t_study_status SET status = ?, timemodified = ? WHERE status_id = ?");
            $stmt->execute([$studyStatus, $current_time, $existing_status['status_id']]);
            $final_status_id = $existing_status['status_id'];
        } else {
            // 새 학습 상태 생성 - AUTO_INCREMENT 사용
            try {
                error_log("Section 3 - 새 데이터 생성 시도");
                $stmt = $pdo->prepare("INSERT INTO mdl_alt42t_study_status (user_id, exam_id, status, created_at, userid, timecreated, timemodified) VALUES (?, ?, ?, ?, 0, ?, ?)");
                $stmt->execute([$user_id, $exam_id, $studyStatus, $current_datetime, $current_time, $current_time]);
                $final_status_id = $pdo->lastInsertId();
                error_log("Section 3 - 새 status_id 생성: " . $final_status_id);
            } catch (PDOException $e) {
                error_log("Section 3 - INSERT 실패: " . $e->getMessage());
                // 중복 삽입 시도 시 기존 데이터 조회
                if ($e->getCode() == 23000) {
                    $stmt = $pdo->prepare("SELECT status_id FROM mdl_alt42t_study_status WHERE exam_id = ? AND user_id = ?");
                    $stmt->execute([$exam_id, $user_id]);
                    $retry_existing = $stmt->fetch();
                    if ($retry_existing) {
                        $final_status_id = $retry_existing['status_id'];
                        error_log("Section 3 - 재시도로 기존 데이터 사용: " . $final_status_id);
                    } else {
                        throw $e;
                    }
                } else {
                    throw $e;
                }
            }
        }

        $response_data = [
            "user_id" => $user_id,
            "exam_id" => $exam_id,
            "status_id" => $final_status_id,
            "study_status" => $studyStatus
        ];
    }

    // 커밋
    $pdo->commit();
    
    // 성공 응답
    echo json_encode([
        "success" => true, 
        "message" => "데이터가 성공적으로 저장되었습니다!",
        "section" => $section,
        "data" => $response_data
    ]);

} catch (Exception $e) {
    // 롤백
    if (isset($pdo)) {
        $pdo->rollBack();
    }
    
    // 에러 응답
    http_response_code(500);
    echo json_encode([
        "success" => false, 
        "message" => "저장 실패: " . $e->getMessage()
    ]);
}
?>
