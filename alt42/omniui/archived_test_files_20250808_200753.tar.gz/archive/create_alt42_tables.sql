-- Alt42 테이블 생성 SQL 스크립트
-- phpMyAdmin에서 직접 실행 가능
-- 실행 전에 mathking 데이터베이스를 선택하세요

-- 외래키 제약조건 임시 비활성화
SET FOREIGN_KEY_CHECKS = 0;

-- 1. Users 테이블
CREATE TABLE IF NOT EXISTS mdl_alt42t_users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NULL COMMENT '사용자명',
    school_name VARCHAR(100) NOT NULL COMMENT '학교명',
    grade TINYINT(1) NOT NULL COMMENT '학년 (1,2,3)',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '생성일시',
    userid INT NOT NULL DEFAULT 0 COMMENT 'Moodle 사용자 ID',
    timecreated INT(10) NOT NULL DEFAULT 0 COMMENT '생성시간 (unixtime)',
    timemodified INT(10) NOT NULL DEFAULT 0 COMMENT '수정시간 (unixtime)',
    INDEX idx_school_grade (school_name, grade),
    INDEX idx_userid (userid),
    INDEX idx_timecreated (timecreated)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='사용자 정보';

-- 2. Exams 테이블
CREATE TABLE IF NOT EXISTS mdl_alt42t_exams (
    exam_id INT AUTO_INCREMENT PRIMARY KEY,
    school_name VARCHAR(100) NOT NULL COMMENT '학교명',
    grade TINYINT(1) NOT NULL COMMENT '학년 (1,2,3)',
    exam_type ENUM('1학기 중간고사','1학기 기말고사','2학기 중간고사','2학기 기말고사') NOT NULL COMMENT '시험 유형',
    userid INT NOT NULL DEFAULT 0 COMMENT 'Moodle 사용자 ID',
    timecreated INT(10) NOT NULL DEFAULT 0 COMMENT '생성시간 (unixtime)',
    timemodified INT(10) NOT NULL DEFAULT 0 COMMENT '수정시간 (unixtime)',
    UNIQUE KEY unique_exam (school_name, grade, exam_type),
    INDEX idx_school_grade (school_name, grade),
    INDEX idx_userid (userid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='시험 정보';

-- 3. ExamDates 테이블
CREATE TABLE IF NOT EXISTS mdl_alt42t_exam_dates (
    exam_date_id INT AUTO_INCREMENT PRIMARY KEY,
    exam_id INT NOT NULL COMMENT '시험 ID',
    user_id INT NOT NULL COMMENT '사용자 ID',
    start_date DATE NOT NULL COMMENT '시험 시작일',
    end_date DATE NOT NULL COMMENT '시험 종료일', 
    math_date DATE NOT NULL COMMENT '수학 시험일',
    status ENUM('예상','확정') NOT NULL DEFAULT '예상' COMMENT '상태',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '생성일시',
    userid INT NOT NULL DEFAULT 0 COMMENT 'Moodle 사용자 ID',
    timecreated INT(10) NOT NULL DEFAULT 0 COMMENT '생성시간 (unixtime)',
    timemodified INT(10) NOT NULL DEFAULT 0 COMMENT '수정시간 (unixtime)',
    INDEX idx_exam_user (exam_id, user_id),
    INDEX idx_math_date (math_date),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='시험 일정';

-- 4. StudyStatus 테이블
CREATE TABLE IF NOT EXISTS mdl_alt42t_study_status (
    status_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL COMMENT '사용자 ID',
    exam_id INT NOT NULL COMMENT '시험 ID',
    status ENUM('개념공부','개념복습','유형공부') NOT NULL COMMENT '학습 상태',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '생성일시',
    userid INT NOT NULL DEFAULT 0 COMMENT 'Moodle 사용자 ID',
    timecreated INT(10) NOT NULL DEFAULT 0 COMMENT '생성시간 (unixtime)',
    timemodified INT(10) NOT NULL DEFAULT 0 COMMENT '수정시간 (unixtime)',
    INDEX idx_user_exam (user_id, exam_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='학습 상태';

-- 5. ExamResources 테이블
CREATE TABLE IF NOT EXISTS mdl_alt42t_exam_resources (
    resource_id INT AUTO_INCREMENT PRIMARY KEY,
    exam_id INT NOT NULL COMMENT '시험 ID',
    user_id INT NOT NULL COMMENT '사용자 ID',
    file_url VARCHAR(255) NULL COMMENT '파일 URL',
    tip_text TEXT NULL COMMENT '팁 내용',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '생성일시',
    userid INT NOT NULL DEFAULT 0 COMMENT 'Moodle 사용자 ID',
    timecreated INT(10) NOT NULL DEFAULT 0 COMMENT '생성시간 (unixtime)',
    timemodified INT(10) NOT NULL DEFAULT 0 COMMENT '수정시간 (unixtime)',
    INDEX idx_exam_user (exam_id, user_id),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='시험 자료';

-- 6. AggregatedResources 테이블
CREATE TABLE IF NOT EXISTS mdl_alt42t_aggregated_resources (
    aggregated_id INT AUTO_INCREMENT PRIMARY KEY,
    exam_id INT NOT NULL COMMENT '시험 ID',
    compiled_file_urls JSON NULL COMMENT '집계된 파일 URL들',
    compiled_tips TEXT NULL COMMENT '집계된 팁들',
    last_updated DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '최종 업데이트',
    userid INT NOT NULL DEFAULT 0 COMMENT 'Moodle 사용자 ID',
    timecreated INT(10) NOT NULL DEFAULT 0 COMMENT '생성시간 (unixtime)',
    timemodified INT(10) NOT NULL DEFAULT 0 COMMENT '수정시간 (unixtime)',
    UNIQUE KEY unique_exam_aggregated (exam_id),
    INDEX idx_last_updated (last_updated)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='집계된 자료';

-- 외래키 제약조건 추가
ALTER TABLE mdl_alt42t_exam_dates 
ADD CONSTRAINT fk_exam_dates_exam_id 
FOREIGN KEY (exam_id) REFERENCES mdl_alt42t_exams(exam_id) ON DELETE CASCADE;

ALTER TABLE mdl_alt42t_exam_dates 
ADD CONSTRAINT fk_exam_dates_user_id 
FOREIGN KEY (user_id) REFERENCES mdl_alt42t_users(user_id) ON DELETE CASCADE;

ALTER TABLE mdl_alt42t_study_status 
ADD CONSTRAINT fk_study_status_user_id 
FOREIGN KEY (user_id) REFERENCES mdl_alt42t_users(user_id) ON DELETE CASCADE;

ALTER TABLE mdl_alt42t_study_status 
ADD CONSTRAINT fk_study_status_exam_id 
FOREIGN KEY (exam_id) REFERENCES mdl_alt42t_exams(exam_id) ON DELETE CASCADE;

ALTER TABLE mdl_alt42t_exam_resources 
ADD CONSTRAINT fk_exam_resources_exam_id 
FOREIGN KEY (exam_id) REFERENCES mdl_alt42t_exams(exam_id) ON DELETE CASCADE;

ALTER TABLE mdl_alt42t_exam_resources 
ADD CONSTRAINT fk_exam_resources_user_id 
FOREIGN KEY (user_id) REFERENCES mdl_alt42t_users(user_id) ON DELETE CASCADE;

ALTER TABLE mdl_alt42t_aggregated_resources 
ADD CONSTRAINT fk_aggregated_resources_exam_id 
FOREIGN KEY (exam_id) REFERENCES mdl_alt42t_exams(exam_id) ON DELETE CASCADE;

-- 외래키 제약조건 재활성화
SET FOREIGN_KEY_CHECKS = 1;

-- 생성된 테이블 확인
SHOW TABLES LIKE 'mdl_alt42t_%';