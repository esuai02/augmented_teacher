<?php
header('Content-Type: text/plain; charset=utf-8');

require_once('/home/moodle/public_html/moodle/config.php');
global $DB;

echo "=== 빠른 테이블 확인 ===\n\n";

// mdl_alt42t_exam_user_info 테이블 확인
$sql = "SHOW TABLES LIKE '%alt42t_exam_user_info%'";
$tables = $DB->get_records_sql($sql);

echo "alt42t_exam_user_info 관련 테이블:\n";
foreach ($tables as $table) {
    $table_array = (array)$table;
    $table_name = reset($table_array);
    echo "- " . $table_name . "\n";
}

echo "\n";

// 정확한 테이블명으로 데이터 개수 확인
try {
    $count = $DB->count_records('alt42t_exam_user_info');
    echo "alt42t_exam_user_info 테이블의 레코드 수: " . $count . "\n";
} catch (Exception $e) {
    echo "alt42t_exam_user_info 테이블 접근 오류: " . $e->getMessage() . "\n";
}

// mdl_ prefix로도 시도
try {
    $count = $DB->count_records('mdl_alt42t_exam_user_info');
    echo "mdl_alt42t_exam_user_info 테이블의 레코드 수: " . $count . "\n";
} catch (Exception $e) {
    echo "mdl_alt42t_exam_user_info 테이블 접근 오류: " . $e->getMessage() . "\n";
}

// 모든 alt42t 테이블 목록
echo "\n모든 alt42t 테이블:\n";
$sql = "SHOW TABLES LIKE '%alt42t%'";
$all_tables = $DB->get_records_sql($sql);
foreach ($all_tables as $table) {
    $table_array = (array)$table;
    $table_name = reset($table_array);
    echo "- " . $table_name . "\n";
}
?>