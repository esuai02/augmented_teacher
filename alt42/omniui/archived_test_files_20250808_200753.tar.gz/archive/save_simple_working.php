<?php
// 출력 버퍼 정리
while (ob_get_level()) {
    ob_end_clean();
}

// 에러 숨기기
error_reporting(0);
ini_set('display_errors', 0);

// JSON 헤더
header('Content-Type: application/json; charset=utf-8');

// 기본 응답
$response = array(
    'success' => false,
    'message' => '처리 중 오류'
);

try {
    // Moodle 설정
    include_once("/home/moodle/public_html/moodle/config.php");
    global $DB, $USER;
    
    // 로그인 확인
    if (!isloggedin() || isguestuser()) {
        $response['message'] = '로그인이 필요합니다';
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    // 입력 데이터
    $input = json_decode(file_get_contents("php://input"), true);
    
    if (!$input) {
        $response['message'] = '입력 데이터가 없습니다';
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    $userid = $USER->id;
    $section = intval($input['section'] ?? 0);
    
    // 섹션별 처리
    if ($section === 0) {
        // 기본 정보 저장
        $existing = $DB->get_record('alt42t_exam_user_info', array('userid' => $userid));
        
        if ($existing) {
            // 업데이트
            $data = clone $existing;
            $data->school = trim($input['school'] ?? '');
            $data->grade = strval($input['grade'] ?? '');
            $data->exam_type = trim($input['examType'] ?? '');
            $data->timemodified = time();
            
            $DB->update_record('alt42t_exam_user_info', $data);
            $response = array(
                'success' => true,
                'message' => '기본 정보가 업데이트되었습니다',
                'action' => 'update',
                'data' => array(
                    'school' => $data->school,
                    'grade' => $data->grade,
                    'exam_type' => $data->exam_type
                )
            );
        } else {
            // 신규 생성
            $data = new stdClass();
            $data->userid = $userid;
            $data->school = trim($input['school'] ?? '');
            $data->grade = strval($input['grade'] ?? '');
            $data->exam_type = trim($input['examType'] ?? '');
            $data->timecreated = time();
            $data->timemodified = time();
            
            $id = $DB->insert_record('alt42t_exam_user_info', $data);
            $response = array(
                'success' => true,
                'message' => '기본 정보가 저장되었습니다',
                'action' => 'insert',
                'id' => $id,
                'data' => array(
                    'school' => $data->school,
                    'grade' => $data->grade,
                    'exam_type' => $data->exam_type
                )
            );
        }
        
    } else if ($section === 1) {
        // 시험 일정 저장
        $existing = $DB->get_record('alt42t_exam_user_info', array('userid' => $userid));
        
        if (!$existing) {
            $response['message'] = '기본 정보를 먼저 저장해주세요';
        } else {
            $data = clone $existing;
            
            if (isset($input['startDate'])) $data->exam_start_date = $input['startDate'];
            if (isset($input['endDate'])) $data->exam_end_date = $input['endDate'];
            if (isset($input['mathDate'])) $data->math_exam_date = $input['mathDate'];
            if (isset($input['status'])) $data->exam_status = $input['status'];
            if (isset($input['examScope'])) $data->exam_scope = $input['examScope'];
            
            $data->timemodified = time();
            
            $DB->update_record('alt42t_exam_user_info', $data);
            $response = array(
                'success' => true,
                'message' => '시험 일정이 저장되었습니다',
                'action' => 'update'
            );
        }
        
    } else if ($section === 3) {
        // 학습 상태 저장
        $existing = $DB->get_record('alt42t_exam_user_info', array('userid' => $userid));
        
        if (!$existing) {
            $response['message'] = '기본 정보를 먼저 저장해주세요';
        } else {
            $data = clone $existing;
            $data->study_status = $input['studyStatus'] ?? '';
            $data->timemodified = time();
            
            $DB->update_record('alt42t_exam_user_info', $data);
            $response = array(
                'success' => true,
                'message' => '학습 상태가 저장되었습니다',
                'action' => 'update'
            );
        }
    }
    
} catch (Exception $e) {
    $response = array(
        'success' => false,
        'message' => '오류: ' . $e->getMessage(),
        'error' => true
    );
}

// JSON 출력
echo json_encode($response, JSON_UNESCAPED_UNICODE);
exit;
?>