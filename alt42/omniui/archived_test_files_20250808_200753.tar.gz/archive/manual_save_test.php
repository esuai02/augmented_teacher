<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>수동 데이터 저장 테스트</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f5f5f5;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input, select, textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        button {
            background: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin: 5px;
        }
        button:hover {
            background: #45a049;
        }
        .result {
            margin-top: 20px;
            padding: 10px;
            border-radius: 4px;
            background: #f0f0f0;
            white-space: pre-wrap;
            font-family: monospace;
        }
        .success {
            background: #d4edda;
            color: #155724;
        }
        .error {
            background: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>수동 데이터 저장 테스트</h1>
        
        <form id="test-form">
            <h2>기본 정보 (Section 0)</h2>
            <div class="form-group">
                <label>학교:</label>
                <input type="text" id="school" value="서울고등학교">
            </div>
            <div class="form-group">
                <label>학년:</label>
                <select id="grade">
                    <option value="1">1학년</option>
                    <option value="2">2학년</option>
                    <option value="3">3학년</option>
                </select>
            </div>
            <div class="form-group">
                <label>시험 종류:</label>
                <select id="examType">
                    <option value="1mid">1학기 중간고사</option>
                    <option value="1final">1학기 기말고사</option>
                    <option value="2mid">2학기 중간고사</option>
                    <option value="2final">2학기 기말고사</option>
                </select>
            </div>
            <button type="button" onclick="saveSection0()">기본 정보 저장</button>
            
            <hr>
            
            <h2>시험 일정 (Section 1)</h2>
            <div class="form-group">
                <label>시험 시작일:</label>
                <input type="date" id="startDate" value="2024-04-15">
            </div>
            <div class="form-group">
                <label>시험 종료일:</label>
                <input type="date" id="endDate" value="2024-04-19">
            </div>
            <div class="form-group">
                <label>수학 시험일:</label>
                <input type="date" id="mathDate" value="2024-04-17">
            </div>
            <div class="form-group">
                <label>시험 범위:</label>
                <textarea id="examScope" rows="3">1단원~3단원 (도형의 성질까지)</textarea>
            </div>
            <div class="form-group">
                <label>상태:</label>
                <select id="status">
                    <option value="expected">예상</option>
                    <option value="confirmed">확정</option>
                </select>
            </div>
            <button type="button" onclick="saveSection1()">시험 일정 저장</button>
            
            <hr>
            
            <h2>학습 상태 (Section 3)</h2>
            <div class="form-group">
                <label>학습 단계:</label>
                <select id="studyStatus">
                    <option value="개념공부">개념공부</option>
                    <option value="개념복습">개념복습</option>
                    <option value="유형공부">유형공부</option>
                </select>
            </div>
            <button type="button" onclick="saveSection3()">학습 상태 저장</button>
        </form>
        
        <div id="result" class="result"></div>
        
        <hr>
        <button onclick="checkSavedData()">저장된 데이터 확인</button>
        <button onclick="window.location.href='index.php'">메인으로 돌아가기</button>
    </div>

    <script>
        async function saveSection0() {
            const data = {
                section: 0,
                school: document.getElementById('school').value,
                grade: document.getElementById('grade').value,
                examType: document.getElementById('examType').value
            };
            
            await saveData(data);
        }
        
        async function saveSection1() {
            const data = {
                section: 1,
                startDate: document.getElementById('startDate').value,
                endDate: document.getElementById('endDate').value,
                mathDate: document.getElementById('mathDate').value,
                examScope: document.getElementById('examScope').value,
                status: document.getElementById('status').value
            };
            
            await saveData(data);
        }
        
        async function saveSection3() {
            const data = {
                section: 3,
                studyStatus: document.getElementById('studyStatus').value
            };
            
            await saveData(data);
        }
        
        async function saveData(data) {
            const resultDiv = document.getElementById('result');
            resultDiv.textContent = '저장 중...';
            resultDiv.className = 'result';
            
            try {
                const response = await fetch('save_exam_data_alt42t.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(data)
                });
                
                const result = await response.json();
                
                if (result.success) {
                    resultDiv.textContent = '성공: ' + result.message + '\n\n' + 
                        '저장된 데이터:\n' + JSON.stringify(result.saved_data, null, 2);
                    resultDiv.className = 'result success';
                } else {
                    resultDiv.textContent = '실패: ' + result.message + '\n\n' + 
                        '상세 정보:\n' + JSON.stringify(result, null, 2);
                    resultDiv.className = 'result error';
                }
            } catch (error) {
                resultDiv.textContent = '오류: ' + error.message;
                resultDiv.className = 'result error';
            }
        }
        
        async function checkSavedData() {
            const resultDiv = document.getElementById('result');
            resultDiv.textContent = '데이터 조회 중...';
            resultDiv.className = 'result';
            
            try {
                const response = await fetch('get_saved_exam_data.php');
                const result = await response.json();
                
                if (result.success) {
                    resultDiv.textContent = '저장된 데이터:\n' + JSON.stringify(result.data, null, 2);
                    resultDiv.className = 'result success';
                } else {
                    resultDiv.textContent = '조회 실패: ' + result.message;
                    resultDiv.className = 'result error';
                }
            } catch (error) {
                resultDiv.textContent = '오류: ' + error.message;
                resultDiv.className = 'result error';
            }
        }
    </script>
</body>
</html>