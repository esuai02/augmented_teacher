<?php
require_once('/home/moodle/public_html/moodle/config.php');
require_login();

global $DB, $USER;

// 관리자 권한 체크
$context = context_system::instance();
require_capability('moodle/site:config', $context);

$dbman = $DB->get_manager();

echo "<h2>데이터베이스 초기화 및 테스트 데이터 삽입</h2>";

// 1. alt42t_exam_user_info 테이블 생성
$table = new xmldb_table('alt42t_exam_user_info');
if (!$dbman->table_exists($table)) {
    $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
    $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('school', XMLDB_TYPE_CHAR, '255', null, null, null, null);
    $table->add_field('grade', XMLDB_TYPE_CHAR, '10', null, null, null, null);
    $table->add_field('exam_type', XMLDB_TYPE_CHAR, '50', null, null, null, null);
    $table->add_field('exam_start_date', XMLDB_TYPE_CHAR, '10', null, null, null, null);
    $table->add_field('exam_end_date', XMLDB_TYPE_CHAR, '10', null, null, null, null);
    $table->add_field('math_exam_date', XMLDB_TYPE_CHAR, '10', null, null, null, null);
    $table->add_field('exam_scope', XMLDB_TYPE_TEXT, null, null, null, null, null);
    $table->add_field('exam_status', XMLDB_TYPE_CHAR, '20', null, null, null, 'expected');
    $table->add_field('study_status', XMLDB_TYPE_CHAR, '50', null, null, null, null);
    $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
    
    $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
    $table->add_key('userid_fk', XMLDB_KEY_FOREIGN, array('userid'), 'user', array('id'));
    $table->add_index('userid_idx', XMLDB_INDEX_NOTUNIQUE, array('userid'));
    
    $dbman->create_table($table);
    echo "<p style='color:green;'>✓ alt42t_exam_user_info 테이블 생성 완료</p>";
} else {
    echo "<p>alt42t_exam_user_info 테이블은 이미 존재합니다.</p>";
}

// 2. 현재 사용자의 기존 데이터 확인
$existing = $DB->get_record('alt42t_exam_user_info', array('userid' => $USER->id));

if ($existing) {
    echo "<h3>기존 데이터 발견</h3>";
    echo "<pre>";
    print_r($existing);
    echo "</pre>";
    
    echo "<p>기존 데이터를 삭제하고 새로운 테스트 데이터를 삽입하시겠습니까?</p>";
    echo '<form method="post">';
    echo '<input type="hidden" name="action" value="replace">';
    echo '<button type="submit" style="background:red;color:white;padding:10px;">기존 데이터 삭제 후 테스트 데이터 삽입</button>';
    echo '</form>';
    
    if (optional_param('action', '', PARAM_TEXT) === 'replace') {
        $DB->delete_records('alt42t_exam_user_info', array('userid' => $USER->id));
        echo "<p style='color:orange;'>기존 데이터를 삭제했습니다.</p>";
        $existing = null;
    }
}

// 3. 테스트 데이터 삽입
if (!$existing) {
    $testdata = new stdClass();
    $testdata->userid = $USER->id;
    $testdata->school = '서울고등학교';
    $testdata->grade = '1';
    $testdata->exam_type = '1mid';
    $testdata->exam_start_date = '2024-04-15';
    $testdata->exam_end_date = '2024-04-19';
    $testdata->math_exam_date = '2024-04-17';
    $testdata->exam_scope = '1단원 다항식의 연산\n2단원 나머지정리와 인수분해\n3단원 복소수와 이차방정식';
    $testdata->exam_status = 'confirmed';
    $testdata->study_status = '개념공부';
    $testdata->timecreated = time();
    $testdata->timemodified = time();
    
    try {
        $newid = $DB->insert_record('alt42t_exam_user_info', $testdata);
        echo "<h3 style='color:green;'>✓ 테스트 데이터 삽입 성공!</h3>";
        echo "<p>새로운 레코드 ID: $newid</p>";
        
        // 삽입된 데이터 확인
        $inserted = $DB->get_record('alt42t_exam_user_info', array('id' => $newid));
        echo "<h4>삽입된 데이터:</h4>";
        echo "<pre style='background:#f0f0f0;padding:10px;'>";
        print_r($inserted);
        echo "</pre>";
        
    } catch (Exception $e) {
        echo "<p style='color:red;'>데이터 삽입 실패: " . $e->getMessage() . "</p>";
    }
}

// 4. 모든 사용자의 데이터 확인 (관리자용)
echo "<h3>전체 exam_user_info 데이터 (최근 5개)</h3>";
$alldata = $DB->get_records('alt42t_exam_user_info', null, 'timecreated DESC', '*', 0, 5);
if ($alldata) {
    echo "<table border='1' style='border-collapse:collapse;width:100%;'>";
    echo "<tr><th>ID</th><th>UserID</th><th>학교</th><th>학년</th><th>시험</th><th>기간</th><th>수학일</th><th>상태</th><th>생성일</th></tr>";
    foreach ($alldata as $record) {
        $created = date('Y-m-d H:i:s', $record->timecreated);
        echo "<tr>";
        echo "<td>{$record->id}</td>";
        echo "<td>{$record->userid}</td>";
        echo "<td>{$record->school}</td>";
        echo "<td>{$record->grade}</td>";
        echo "<td>{$record->exam_type}</td>";
        echo "<td>{$record->exam_start_date} ~ {$record->exam_end_date}</td>";
        echo "<td>{$record->math_exam_date}</td>";
        echo "<td>{$record->exam_status}</td>";
        echo "<td>{$created}</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>데이터가 없습니다.</p>";
}

// 5. 링크들
echo "<hr>";
echo '<p><a href="index.php" style="padding:10px;background:#4CAF50;color:white;text-decoration:none;border-radius:5px;">메인 페이지로 이동</a></p>';
echo '<p><a href="manual_save_test.php" style="padding:10px;background:#2196F3;color:white;text-decoration:none;border-radius:5px;">수동 저장 테스트</a></p>';
echo '<p><a href="test_db_save.html" style="padding:10px;background:#FF9800;color:white;text-decoration:none;border-radius:5px;">데이터베이스 저장 테스트 도구</a></p>';
?>