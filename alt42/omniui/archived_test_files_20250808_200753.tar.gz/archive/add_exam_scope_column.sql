-- mdl_alt42t_exam_dates 테이블에 exam_scope 컬럼 추가
-- 시험 범위 정보를 저장하기 위한 컬럼입니다.

ALTER TABLE mdl_alt42t_exam_dates 
ADD COLUMN exam_scope TEXT NULL AFTER status;

-- 기존 데이터에 기본값 설정 (선택사항)
UPDATE mdl_alt42t_exam_dates 
SET exam_scope = '범위 미입력' 
WHERE exam_scope IS NULL;

-- 컬럼 추가 확인
-- DESCRIBE mdl_alt42t_exam_dates;