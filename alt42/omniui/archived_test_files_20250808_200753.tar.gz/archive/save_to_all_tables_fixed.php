<?php
// 에러 표시 끄기 (HTML 출력 방지)
error_reporting(0);
ini_set('display_errors', 0);

// JSON 헤더 먼저 설정
header('Content-Type: application/json; charset=utf-8');

try {
    include_once("/home/moodle/public_html/moodle/config.php"); 
    global $DB, $USER;
    require_login();
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => '로그인이 필요합니다.',
        'error' => 'login_required'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// JSON 입력 데이터 받기
$input_raw = file_get_contents("php://input");
$input = json_decode($input_raw, true);

// JSON 디코딩 확인
if (json_last_error() !== JSON_ERROR_NONE) {
    echo json_encode([
        'success' => false,
        'message' => 'JSON 파싱 오류',
        'error' => json_last_error_msg()
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// 디버깅용 로그 (에러 로그에만)
error_log('save_to_all_tables_fixed.php - 받은 데이터: ' . $input_raw);

$userid = isset($input['userid']) ? intval($input['userid']) : $USER->id;
$section = isset($input['section']) ? intval($input['section']) : 0;

try {
    $now = time();
    $messages = [];
    
    // 테이블 존재 확인
    $dbman = $DB->get_manager();
    $required_tables = ['alt42t_users', 'alt42t_exams', 'alt42t_exam_dates', 'alt42t_exam_user_info', 'alt42t_study_status'];
    
    foreach ($required_tables as $tablename) {
        $table = new xmldb_table($tablename);
        if (!$dbman->table_exists($table)) {
            throw new Exception("필수 테이블 '$tablename'이(가) 존재하지 않습니다.");
        }
    }
    
    // 트랜잭션 시작
    $transaction = $DB->start_delegated_transaction();
    
    if ($section === 0) {
        // Section 0: 기본 정보 (학교, 학년, 시험종류)
        
        // 입력값 검증
        if (!isset($input['school']) || empty(trim($input['school']))) {
            throw new Exception('학교명을 입력해주세요.');
        }
        if (!isset($input['grade']) || empty($input['grade'])) {
            throw new Exception('학년을 선택해주세요.');
        }
        if (!isset($input['examType']) || empty($input['examType'])) {
            throw new Exception('시험 종류를 선택해주세요.');
        }
        
        // 1. alt42t_users 테이블에 저장
        $user_record = $DB->get_record('alt42t_users', array('userid' => $userid));
        
        if ($user_record) {
            // 업데이트
            $sql = "UPDATE {alt42t_users} 
                    SET name = ?, school_name = ?, grade = ?, timemodified = ? 
                    WHERE userid = ?";
            $params = [
                $USER->firstname . ' ' . $USER->lastname,
                trim($input['school']),
                intval($input['grade']),
                $now,
                $userid
            ];
            $DB->execute($sql, $params);
            $user_id = $user_record->id;
            $messages[] = "사용자 정보 업데이트 완료";
        } else {
            // 신규 삽입
            $user_data = new stdClass();
            $user_data->userid = $userid;
            $user_data->name = $USER->firstname . ' ' . $USER->lastname;
            $user_data->school_name = trim($input['school']);
            $user_data->grade = intval($input['grade']);
            $user_data->created_at = date('Y-m-d H:i:s');
            $user_data->timecreated = $now;
            $user_data->timemodified = $now;
            
            $user_id = $DB->insert_record('alt42t_users', $user_data);
            $messages[] = "사용자 정보 신규 생성";
        }
        
        // 2. alt42t_exams 테이블에 저장
        $exam_type_map = [
            '1mid' => '1학기 중간고사',
            '1final' => '1학기 기말고사',
            '2mid' => '2학기 중간고사',
            '2final' => '2학기 기말고사'
        ];
        
        $exam_type_korean = isset($exam_type_map[$input['examType']]) ? 
                            $exam_type_map[$input['examType']] : 
                            $input['examType'];
        
        $exam_record = $DB->get_record('alt42t_exams', array(
            'school_name' => trim($input['school']),
            'grade' => intval($input['grade']),
            'exam_type' => $exam_type_korean
        ));
        
        if (!$exam_record) {
            // 시험 정보가 없으면 생성
            $exam_data = new stdClass();
            $exam_data->school_name = trim($input['school']);
            $exam_data->grade = intval($input['grade']);
            $exam_data->exam_type = $exam_type_korean;
            $exam_data->userid = $userid;
            $exam_data->timecreated = $now;
            $exam_data->timemodified = $now;
            
            $exam_id = $DB->insert_record('alt42t_exams', $exam_data);
            $messages[] = "시험 정보 신규 생성";
        } else {
            $exam_id = $exam_record->id;
            // userid 업데이트
            $sql = "UPDATE {alt42t_exams} SET userid = ?, timemodified = ? WHERE id = ?";
            $DB->execute($sql, array($userid, $now, $exam_id));
            $messages[] = "시험 정보 업데이트 완료";
        }
        
        // 3. alt42t_exam_user_info 테이블에도 저장 (호환성)
        $exam_info = $DB->get_record('alt42t_exam_user_info', array('userid' => $userid));
        
        if ($exam_info) {
            $info_data = clone $exam_info;
            $info_data->school = trim($input['school']);
            $info_data->grade = strval($input['grade']);
            $info_data->exam_type = $input['examType'];
            $info_data->timemodified = $now;
            
            $DB->update_record('alt42t_exam_user_info', $info_data);
            $messages[] = "통합 정보 업데이트 완료";
        } else {
            $info_data = new stdClass();
            $info_data->userid = $userid;
            $info_data->school = trim($input['school']);
            $info_data->grade = strval($input['grade']);
            $info_data->exam_type = $input['examType'];
            $info_data->timecreated = $now;
            $info_data->timemodified = $now;
            
            $DB->insert_record('alt42t_exam_user_info', $info_data);
            $messages[] = "통합 정보 신규 생성";
        }
        
    } else if ($section === 1) {
        // Section 1: 시험 일정 저장
        
        // user_id와 exam_id 가져오기
        $user_record = $DB->get_record('alt42t_users', array('userid' => $userid));
        if (!$user_record) {
            throw new Exception('기본 정보를 먼저 저장해주세요.');
        }
        
        $exam_info = $DB->get_record('alt42t_exam_user_info', array('userid' => $userid));
        if (!$exam_info) {
            throw new Exception('시험 정보를 먼저 설정해주세요.');
        }
        
        $exam_type_map = [
            '1mid' => '1학기 중간고사',
            '1final' => '1학기 기말고사',
            '2mid' => '2학기 중간고사',
            '2final' => '2학기 기말고사'
        ];
        
        $exam_type_korean = isset($exam_type_map[$exam_info->exam_type]) ? 
                            $exam_type_map[$exam_info->exam_type] : 
                            $exam_info->exam_type;
        
        $exam_record = $DB->get_record('alt42t_exams', array(
            'school_name' => $exam_info->school,
            'grade' => intval($exam_info->grade),
            'exam_type' => $exam_type_korean
        ));
        
        if (!$exam_record) {
            throw new Exception('시험 정보를 찾을 수 없습니다.');
        }
        
        // alt42t_exam_dates 테이블에 저장
        $date_record = $DB->get_record('alt42t_exam_dates', array(
            'exam_id' => $exam_record->id,
            'user_id' => $user_record->id
        ));
        
        if ($date_record) {
            // 업데이트
            $update_fields = [];
            $params = [];
            
            if (isset($input['startDate']) && !empty($input['startDate'])) {
                $update_fields[] = "start_date = ?";
                $params[] = $input['startDate'];
            }
            if (isset($input['endDate']) && !empty($input['endDate'])) {
                $update_fields[] = "end_date = ?";
                $params[] = $input['endDate'];
            }
            if (isset($input['mathDate']) && !empty($input['mathDate'])) {
                $update_fields[] = "math_date = ?";
                $params[] = $input['mathDate'];
            }
            if (isset($input['status'])) {
                $update_fields[] = "status = ?";
                $params[] = $input['status'];
            }
            
            if (!empty($update_fields)) {
                $update_fields[] = "timemodified = ?";
                $params[] = $now;
                $params[] = $date_record->id;
                
                $sql = "UPDATE {alt42t_exam_dates} 
                        SET " . implode(", ", $update_fields) . " 
                        WHERE id = ?";
                $DB->execute($sql, $params);
                $messages[] = "시험 일정 업데이트 완료";
            }
        } else {
            // 신규 삽입
            $date_data = new stdClass();
            $date_data->exam_id = $exam_record->id;
            $date_data->user_id = $user_record->id;
            $date_data->start_date = isset($input['startDate']) ? $input['startDate'] : null;
            $date_data->end_date = isset($input['endDate']) ? $input['endDate'] : null;
            $date_data->math_date = isset($input['mathDate']) ? $input['mathDate'] : null;
            $date_data->status = isset($input['status']) ? $input['status'] : '예상';
            $date_data->created_at = date('Y-m-d H:i:s');
            $date_data->userid = $userid;
            $date_data->timecreated = $now;
            $date_data->timemodified = $now;
            
            $DB->insert_record('alt42t_exam_dates', $date_data);
            $messages[] = "시험 일정 신규 생성";
        }
        
        // alt42t_exam_user_info 테이블도 업데이트
        $info_update = clone $exam_info;
        if (isset($input['startDate'])) $info_update->exam_start_date = $input['startDate'];
        if (isset($input['endDate'])) $info_update->exam_end_date = $input['endDate'];
        if (isset($input['mathDate'])) $info_update->math_exam_date = $input['mathDate'];
        if (isset($input['status'])) $info_update->exam_status = $input['status'];
        if (isset($input['examScope'])) $info_update->exam_scope = $input['examScope'];
        $info_update->timemodified = $now;
        
        $DB->update_record('alt42t_exam_user_info', $info_update);
        $messages[] = "통합 정보 날짜 업데이트";
        
    } else if ($section === 3) {
        // Section 3: 학습 상태 저장
        
        // user_id와 exam_id 가져오기
        $user_record = $DB->get_record('alt42t_users', array('userid' => $userid));
        if (!$user_record) {
            throw new Exception('기본 정보를 먼저 저장해주세요.');
        }
        
        $exam_info = $DB->get_record('alt42t_exam_user_info', array('userid' => $userid));
        if (!$exam_info) {
            throw new Exception('시험 정보를 먼저 설정해주세요.');
        }
        
        $exam_type_map = [
            '1mid' => '1학기 중간고사',
            '1final' => '1학기 기말고사',
            '2mid' => '2학기 중간고사',
            '2final' => '2학기 기말고사'
        ];
        
        $exam_type_korean = isset($exam_type_map[$exam_info->exam_type]) ? 
                            $exam_type_map[$exam_info->exam_type] : 
                            $exam_info->exam_type;
        
        $exam_record = $DB->get_record('alt42t_exams', array(
            'school_name' => $exam_info->school,
            'grade' => intval($exam_info->grade),
            'exam_type' => $exam_type_korean
        ));
        
        if (!$exam_record) {
            throw new Exception('시험 정보를 찾을 수 없습니다.');
        }
        
        // alt42t_study_status 테이블에 저장
        $status_record = $DB->get_record('alt42t_study_status', array(
            'user_id' => $user_record->id,
            'exam_id' => $exam_record->id
        ));
        
        if ($status_record) {
            // 업데이트
            $sql = "UPDATE {alt42t_study_status} 
                    SET status = ?, timemodified = ? 
                    WHERE id = ?";
            $params = array($input['studyStatus'], $now, $status_record->id);
            $DB->execute($sql, $params);
            $messages[] = "학습 상태 업데이트 완료";
        } else {
            // 신규 삽입
            $status_data = new stdClass();
            $status_data->user_id = $user_record->id;
            $status_data->exam_id = $exam_record->id;
            $status_data->status = $input['studyStatus'];
            $status_data->created_at = date('Y-m-d H:i:s');
            $status_data->userid = $userid;
            $status_data->timecreated = $now;
            $status_data->timemodified = $now;
            
            $DB->insert_record('alt42t_study_status', $status_data);
            $messages[] = "학습 상태 신규 생성";
        }
        
        // alt42t_exam_user_info 테이블도 업데이트
        $info_update = clone $exam_info;
        $info_update->study_status = $input['studyStatus'];
        $info_update->timemodified = $now;
        
        $DB->update_record('alt42t_exam_user_info', $info_update);
        $messages[] = "통합 정보 학습 상태 업데이트";
    } else {
        throw new Exception("알 수 없는 섹션입니다: $section");
    }
    
    // 트랜잭션 커밋
    $transaction->allow_commit();
    
    // 성공 응답
    echo json_encode([
        'success' => true,
        'messages' => $messages,
        'message' => implode(', ', $messages)
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    if (isset($transaction)) {
        $transaction->rollback($e);
    }
    
    error_log('save_to_all_tables_fixed.php 오류: ' . $e->getMessage());
    
    // 오류 응답
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
        'error' => 'exception',
        'detail' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}

// 절대 여기 이후로는 아무것도 출력하지 않음
exit;
?>