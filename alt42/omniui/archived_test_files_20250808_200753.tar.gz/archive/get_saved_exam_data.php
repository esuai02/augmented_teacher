<?php
header('Content-Type: application/json; charset=utf-8');

require_once('/home/moodle/public_html/moodle/config.php');
require_once(__DIR__ . '/get_exam_data_alt42t.php');
global $DB, $USER;
require_login();

try {
    // alt42t_ 테이블들에서 데이터 조회
    $exam_info = getExamDataFromAlt42t($USER->id);
    
    if ($exam_info) {
        echo json_encode([
            'success' => true,
            'data' => $exam_info,
            'user_info' => [
                'id' => $USER->id,
                'username' => $USER->username,
                'firstname' => $USER->firstname,
                'lastname' => $USER->lastname
            ]
        ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    } else {
        echo json_encode([
            'success' => true,
            'data' => null,
            'message' => '저장된 데이터가 없습니다',
            'user_info' => [
                'id' => $USER->id,
                'username' => $USER->username
            ]
        ], JSON_UNESCAPED_UNICODE);
    }
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => '데이터 조회 중 오류: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>