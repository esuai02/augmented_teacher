<?php
// 모든 출력 버퍼 정리
while (ob_get_level()) {
    ob_end_clean();
}

// 새 출력 버퍼 시작
ob_start();

// 에러를 로그 파일로만
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// JSON 헤더
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, must-revalidate');

try {
    // Moodle 설정
    require_once('/home/moodle/public_html/moodle/config.php');
    require_once($CFG->dirroot.'/lib/setup.php');
    
    global $DB, $USER, $PAGE;
    
    // 세션 확인만 (리다이렉트 없이)
    if (!isloggedin() || isguestuser()) {
        throw new Exception('로그인이 필요합니다.');
    }
    
    // 입력 데이터
    $input_raw = file_get_contents("php://input");
    $input = json_decode($input_raw, true);
    
    if (!$input) {
        throw new Exception('입력 데이터가 없습니다.');
    }
    
    $userid = $USER->id;
    $section = isset($input['section']) ? intval($input['section']) : 0;
    
    // 간단한 저장 로직
    $message = "섹션 {$section} 처리 완료";
    
    if ($section === 0) {
        // 기본 정보만 alt42t_exam_user_info에 저장
        $data = new stdClass();
        $data->userid = $userid;
        $data->school = $input['school'] ?? '';
        $data->grade = $input['grade'] ?? '';
        $data->exam_type = $input['examType'] ?? '';
        
        $existing = $DB->get_record('alt42t_exam_user_info', array('userid' => $userid));
        
        if ($existing) {
            $data->id = $existing->id;
            $data->timemodified = time();
            $DB->update_record('alt42t_exam_user_info', $data);
            $message = "기본 정보 업데이트 완료";
        } else {
            $data->timecreated = time();
            $data->timemodified = time();
            $DB->insert_record('alt42t_exam_user_info', $data);
            $message = "기본 정보 저장 완료";
        }
    }
    
    // 성공 응답
    $response = array(
        'success' => true,
        'message' => $message,
        'section' => $section
    );
    
} catch (Exception $e) {
    // 오류 응답
    $response = array(
        'success' => false,
        'message' => $e->getMessage(),
        'error' => true
    );
}

// 버퍼 내용 지우고 JSON만 출력
ob_clean();
echo json_encode($response, JSON_UNESCAPED_UNICODE);
ob_end_flush();
exit;
?>