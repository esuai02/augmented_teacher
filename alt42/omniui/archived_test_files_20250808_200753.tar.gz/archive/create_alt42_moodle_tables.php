<?php
require_once('/home/moodle/public_html/moodle/config.php');
require_once($CFG->libdir.'/adminlib.php');

// 관리자 권한 확인
require_login();
require_capability('moodle/site:config', context_system::instance());

global $DB; 

echo "<h1>ALT42 테이블 생성 (Moodle XMLDB)</h1>";
echo "<pre>";

$dbman = $DB->get_manager();

// 1. alt42t_users 테이블
$table = new xmldb_table('alt42t_users');
if (!$dbman->table_exists($table)) {
    $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
    $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('name', XMLDB_TYPE_CHAR, '50', null, null, null, null);
    $table->add_field('school_name', XMLDB_TYPE_CHAR, '100', null, XMLDB_NOTNULL, null, null);
    $table->add_field('grade', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, null);
    $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    
    $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
    $table->add_key('userid_fk', XMLDB_KEY_FOREIGN, array('userid'), 'user', array('id'));
    
    $table->add_index('idx_school_grade', XMLDB_INDEX_NOTUNIQUE, array('school_name', 'grade'));
    $table->add_index('idx_userid', XMLDB_INDEX_NOTUNIQUE, array('userid'));
    
    $dbman->create_table($table);
    echo "✓ alt42t_users 테이블 생성 완료\n";
} else {
    echo "- alt42t_users 테이블이 이미 존재합니다\n";
}

// 2. alt42t_exams 테이블
$table = new xmldb_table('alt42t_exams');
if (!$dbman->table_exists($table)) {
    $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
    $table->add_field('school_name', XMLDB_TYPE_CHAR, '100', null, XMLDB_NOTNULL, null, null);
    $table->add_field('grade', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, null);
    $table->add_field('exam_type', XMLDB_TYPE_CHAR, '50', null, XMLDB_NOTNULL, null, null);
    $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    
    $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
    $table->add_index('idx_school_grade_type', XMLDB_INDEX_UNIQUE, array('school_name', 'grade', 'exam_type'));
    
    $dbman->create_table($table);
    echo "✓ alt42t_exams 테이블 생성 완료\n";
} else {
    echo "- alt42t_exams 테이블이 이미 존재합니다\n";
}

// 3. alt42t_exam_dates 테이블
$table = new xmldb_table('alt42t_exam_dates');
if (!$dbman->table_exists($table)) {
    $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
    $table->add_field('exam_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('user_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('start_date', XMLDB_TYPE_CHAR, '10', null, null, null, null);
    $table->add_field('end_date', XMLDB_TYPE_CHAR, '10', null, null, null, null);
    $table->add_field('math_date', XMLDB_TYPE_CHAR, '10', null, null, null, null);
    $table->add_field('status', XMLDB_TYPE_CHAR, '10', null, null, null, '예상');
    $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    
    $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
    $table->add_key('exam_fk', XMLDB_KEY_FOREIGN, array('exam_id'), 'alt42t_exams', array('id'));
    $table->add_key('user_fk', XMLDB_KEY_FOREIGN, array('user_id'), 'alt42t_users', array('id'));
    
    $table->add_index('idx_exam_user', XMLDB_INDEX_NOTUNIQUE, array('exam_id', 'user_id'));
    
    $dbman->create_table($table);
    echo "✓ alt42t_exam_dates 테이블 생성 완료\n";
} else {
    echo "- alt42t_exam_dates 테이블이 이미 존재합니다\n";
}

// 4. alt42t_study_status 테이블
$table = new xmldb_table('alt42t_study_status');
if (!$dbman->table_exists($table)) {
    $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
    $table->add_field('user_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('exam_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('status', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, null);
    $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    
    $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
    $table->add_key('user_fk', XMLDB_KEY_FOREIGN, array('user_id'), 'alt42t_users', array('id'));
    $table->add_key('exam_fk', XMLDB_KEY_FOREIGN, array('exam_id'), 'alt42t_exams', array('id'));
    
    $table->add_index('idx_user_exam', XMLDB_INDEX_NOTUNIQUE, array('user_id', 'exam_id'));
    
    $dbman->create_table($table);
    echo "✓ alt42t_study_status 테이블 생성 완료\n";
} else {
    echo "- alt42t_study_status 테이블이 이미 존재합니다\n";
}

// 5. alt42t_exam_resources 테이블
$table = new xmldb_table('alt42t_exam_resources');
if (!$dbman->table_exists($table)) {
    $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
    $table->add_field('exam_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('user_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('file_url', XMLDB_TYPE_CHAR, '255', null, null, null, null);
    $table->add_field('tip_text', XMLDB_TYPE_TEXT, null, null, null, null, null);
    $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    
    $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
    $table->add_key('exam_fk', XMLDB_KEY_FOREIGN, array('exam_id'), 'alt42t_exams', array('id'));
    $table->add_key('user_fk', XMLDB_KEY_FOREIGN, array('user_id'), 'alt42t_users', array('id'));
    
    $dbman->create_table($table);
    echo "✓ alt42t_exam_resources 테이블 생성 완료\n";
} else {
    echo "- alt42t_exam_resources 테이블이 이미 존재합니다\n";
}

// 6. alt42t_aggregated_resources 테이블
$table = new xmldb_table('alt42t_aggregated_resources');
if (!$dbman->table_exists($table)) {
    $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
    $table->add_field('exam_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('compiled_file_urls', XMLDB_TYPE_TEXT, null, null, null, null, null);
    $table->add_field('compiled_tips', XMLDB_TYPE_TEXT, null, null, null, null, null);
    $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    
    $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
    $table->add_key('exam_fk', XMLDB_KEY_FOREIGN, array('exam_id'), 'alt42t_exams', array('id'));
    
    $table->add_index('idx_exam', XMLDB_INDEX_UNIQUE, array('exam_id'));
    
    $dbman->create_table($table);
    echo "✓ alt42t_aggregated_resources 테이블 생성 완료\n";
} else {
    echo "- alt42t_aggregated_resources 테이블이 이미 존재합니다\n";
}

echo "\n=== 테이블 생성 완료 ===\n";
echo "</pre>";
?>