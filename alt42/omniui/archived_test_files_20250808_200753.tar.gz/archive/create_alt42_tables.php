<?php
/**
 * Alt42 Tables Creation Script
 * 새로운 DB 테이블들을 생성하는 스크립트 (기존 DB는 건드리지 않음)
 */

// DB 접속 정보
$dbhost = '58.180.27.46';
$dbname = 'mathking';
$dbuser = 'moodle';
$dbpass = '@MCtrigd7128';
$prefix = 'mdl_';

// 테이블 접두사
$table_prefix = 'mdl_alt42t_';

// 에러 표시 설정
error_reporting(E_ALL);
ini_set('display_errors', 1);

// HTML 헤더
echo "<!DOCTYPE html>";
echo "<html lang='ko'>";
echo "<head>";
echo "<meta charset='UTF-8'>";
echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
echo "<title>Alt42 Tables Creation</title>";
echo "<style>";
echo "body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }";
echo ".success { color: green; background: #e8f5e8; padding: 10px; border-radius: 5px; margin: 10px 0; }";
echo ".error { color: red; background: #ffeaea; padding: 10px; border-radius: 5px; margin: 10px 0; }";
echo ".info { color: blue; background: #e8f4fd; padding: 10px; border-radius: 5px; margin: 10px 0; }";
echo "</style>";
echo "</head>";
echo "<body>";

echo "<h1>Alt42 테이블 생성 스크립트</h1>";
echo "<p>실행 시간: " . date('Y-m-d H:i:s') . "</p>";

try {
    // MySQL 연결
    $dsn = "mysql:host=$dbhost;dbname=$dbname;charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
    ];
    
    $pdo = new PDO($dsn, $dbuser, $dbpass, $options);
    echo "<div class='success'>✓ 데이터베이스 연결 성공</div>";
    
    // 테이블 생성 쿼리들
    $tables = [];
    
    // 1. Users 테이블
    $tables['users'] = "
    CREATE TABLE IF NOT EXISTS {$table_prefix}users (
        user_id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(50) NULL,
        school_name VARCHAR(100) NOT NULL,
        grade TINYINT(1) NOT NULL COMMENT '1,2,3',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        userid INT NOT NULL DEFAULT 0,
        timecreated INT(10) NOT NULL DEFAULT 0,
        timemodified INT(10) NOT NULL DEFAULT 0,
        INDEX idx_school_grade (school_name, grade),
        INDEX idx_userid (userid),
        INDEX idx_timecreated (timecreated)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='사용자 정보'";
    
    // 2. Exams 테이블
    $tables['exams'] = "
    CREATE TABLE IF NOT EXISTS {$table_prefix}exams (
        exam_id INT AUTO_INCREMENT PRIMARY KEY,
        school_name VARCHAR(100) NOT NULL,
        grade TINYINT(1) NOT NULL COMMENT '1,2,3',
        exam_type ENUM('1학기 중간고사','1학기 기말고사','2학기 중간고사','2학기 기말고사') NOT NULL,
        userid INT NOT NULL DEFAULT 0,
        timecreated INT(10) NOT NULL DEFAULT 0,
        timemodified INT(10) NOT NULL DEFAULT 0,
        UNIQUE KEY unique_exam (school_name, grade, exam_type),
        INDEX idx_school_grade (school_name, grade),
        INDEX idx_userid (userid)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='시험 정보'";
    
    // 3. ExamDates 테이블
    $tables['exam_dates'] = "
    CREATE TABLE IF NOT EXISTS {$table_prefix}exam_dates (
        exam_date_id INT AUTO_INCREMENT PRIMARY KEY,
        exam_id INT NOT NULL,
        user_id INT NOT NULL,
        start_date DATE NOT NULL,
        end_date DATE NOT NULL,
        math_date DATE NOT NULL,
        status ENUM('예상','확정') NOT NULL DEFAULT '예상',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        userid INT NOT NULL DEFAULT 0,
        timecreated INT(10) NOT NULL DEFAULT 0,
        timemodified INT(10) NOT NULL DEFAULT 0,
        FOREIGN KEY (exam_id) REFERENCES {$table_prefix}exams(exam_id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES {$table_prefix}users(user_id) ON DELETE CASCADE,
        INDEX idx_exam_user (exam_id, user_id),
        INDEX idx_math_date (math_date),
        INDEX idx_status (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='시험 일정'";
    
    // 4. StudyStatus 테이블
    $tables['study_status'] = "
    CREATE TABLE IF NOT EXISTS {$table_prefix}study_status (
        status_id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        exam_id INT NOT NULL,
        status ENUM('개념공부','개념복습','유형공부') NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        userid INT NOT NULL DEFAULT 0,
        timecreated INT(10) NOT NULL DEFAULT 0,
        timemodified INT(10) NOT NULL DEFAULT 0,
        FOREIGN KEY (user_id) REFERENCES {$table_prefix}users(user_id) ON DELETE CASCADE,
        FOREIGN KEY (exam_id) REFERENCES {$table_prefix}exams(exam_id) ON DELETE CASCADE,
        INDEX idx_user_exam (user_id, exam_id),
        INDEX idx_status (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='학습 상태'";
    
    // 5. ExamResources 테이블
    $tables['exam_resources'] = "
    CREATE TABLE IF NOT EXISTS {$table_prefix}exam_resources (
        resource_id INT AUTO_INCREMENT PRIMARY KEY,
        exam_id INT NOT NULL,
        user_id INT NOT NULL,
        file_url VARCHAR(255) NULL,
        tip_text TEXT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        userid INT NOT NULL DEFAULT 0,
        timecreated INT(10) NOT NULL DEFAULT 0,
        timemodified INT(10) NOT NULL DEFAULT 0,
        FOREIGN KEY (exam_id) REFERENCES {$table_prefix}exams(exam_id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES {$table_prefix}users(user_id) ON DELETE CASCADE,
        INDEX idx_exam_user (exam_id, user_id),
        INDEX idx_created_at (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='시험 자료'";
    
    // 6. AggregatedResources 테이블
    $tables['aggregated_resources'] = "
    CREATE TABLE IF NOT EXISTS {$table_prefix}aggregated_resources (
        aggregated_id INT AUTO_INCREMENT PRIMARY KEY,
        exam_id INT NOT NULL,
        compiled_file_urls JSON NULL,
        compiled_tips TEXT NULL, 
        last_updated DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        userid INT NOT NULL DEFAULT 0,
        timecreated INT(10) NOT NULL DEFAULT 0,
        timemodified INT(10) NOT NULL DEFAULT 0,
        FOREIGN KEY (exam_id) REFERENCES {$table_prefix}exams(exam_id) ON DELETE CASCADE,
        UNIQUE KEY unique_exam_aggregated (exam_id),
        INDEX idx_last_updated (last_updated)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='집계된 자료'";
    
    // 외래키 제약조건 비활성화 (테이블 생성 순서 문제 해결)
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
    
    $success_count = 0;
    $total_count = count($tables);
    
    // 각 테이블 생성
    foreach ($tables as $table_name => $query) {
        try {
            $pdo->exec($query);
            echo "<div class='success'>✓ 테이블 생성 완료: {$table_prefix}{$table_name}</div>";
            $success_count++;
        } catch (PDOException $e) {
            echo "<div class='error'>✗ 테이블 생성 실패: {$table_prefix}{$table_name}<br>오류: " . $e->getMessage() . "</div>";
        }
    }
    
    // 외래키 제약조건 재활성화
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
    
    // 결과 요약
    echo "<div class='info'>";
    echo "<h3>생성 결과 요약</h3>";
    echo "<p>전체 테이블: {$total_count}개</p>";
    echo "<p>성공: {$success_count}개</p>";
    echo "<p>실패: " . ($total_count - $success_count) . "개</p>";
    echo "</div>";
    
    if ($success_count === $total_count) {
        echo "<div class='success'>";
        echo "<h3>🎉 모든 테이블이 성공적으로 생성되었습니다!</h3>";
        echo "<p>Alt42 시스템을 위한 데이터베이스 구조가 준비되었습니다.</p>";
        echo "</div>";
    } else {
        echo "<div class='error'>";
        echo "<h3>⚠️ 일부 테이블 생성에 실패했습니다.</h3>";
        echo "<p>위의 오류 메시지를 확인하고 문제를 해결해주세요.</p>";
        echo "</div>";
    }
    
    // 생성된 테이블 목록 확인
    $stmt = $pdo->query("SHOW TABLES LIKE '{$table_prefix}%'");
    $created_tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    if (!empty($created_tables)) {
        echo "<div class='info'>";
        echo "<h3>생성된 테이블 목록</h3>";
        echo "<ul>";
        foreach ($created_tables as $table) {
            echo "<li>{$table}</li>";
        }
        echo "</ul>";
        echo "</div>";
    }
    
} catch (PDOException $e) {
    echo "<div class='error'>";
    echo "<h3>✗ 데이터베이스 연결 실패</h3>";
    echo "<p>오류 메시지: " . $e->getMessage() . "</p>";
    echo "<p>연결 정보를 확인해주세요.</p>";
    echo "</div>";
} catch (Exception $e) {
    echo "<div class='error'>";
    echo "<h3>✗ 예상치 못한 오류 발생</h3>";
    echo "<p>오류 메시지: " . $e->getMessage() . "</p>";
    echo "</div>";
}

echo "<hr>";
echo "<p><small>스크립트 실행 완료: " . date('Y-m-d H:i:s') . "</small></p>";
echo "</body>";
echo "</html>";
?>