<?php
/**
 * mdl_alt42t_exam_dates 테이블에 exam_scope 컬럼을 추가하는 스크립트
 * 시험 범위 정보를 저장하기 위한 컬럼을 추가합니다.
 */

$CFG = new stdClass();
$CFG->dbhost = '58.180.27.46';
$CFG->dbname = 'mathking';
$CFG->dbuser = 'moodle';
$CFG->dbpass = '@MCtrigd7128';

try {
    $dsn = "mysql:host={$CFG->dbhost};dbname={$CFG->dbname};charset=utf8mb4";
    $pdo = new PDO($dsn, $CFG->dbuser, $CFG->dbpass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);

    echo "<h2>mdl_alt42t_exam_dates 테이블에 exam_scope 컬럼 추가</h2>";
    
    // 현재 테이블 구조 확인
    echo "<h3>1. 현재 테이블 구조 확인</h3>";
    $stmt = $pdo->query("DESCRIBE mdl_alt42t_exam_dates");
    $columns = $stmt->fetchAll();
    
    echo "<table border='1' style='border-collapse: collapse; margin: 10px 0;'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    
    $hasExamScope = false;
    foreach ($columns as $column) {
        echo "<tr>";
        foreach ($column as $value) {
            echo "<td>" . htmlspecialchars($value) . "</td>";
        }
        echo "</tr>";
        
        if ($column['Field'] === 'exam_scope') {
            $hasExamScope = true;
        }
    }
    echo "</table>";
    
    if ($hasExamScope) {
        echo "<p style='color: green; font-weight: bold;'>✅ exam_scope 컬럼이 이미 존재합니다!</p>";
    } else {
        echo "<h3>2. exam_scope 컬럼 추가</h3>";
        
        // 컬럼 추가
        $sql = "ALTER TABLE mdl_alt42t_exam_dates ADD COLUMN exam_scope TEXT NULL AFTER status";
        $pdo->exec($sql);
        
        echo "<p style='color: green; font-weight: bold;'>✅ exam_scope 컬럼이 성공적으로 추가되었습니다!</p>";
        
        // 기존 데이터에 기본값 설정
        echo "<h3>3. 기존 데이터에 기본값 설정</h3>";
        $updateSql = "UPDATE mdl_alt42t_exam_dates SET exam_scope = '범위 미입력' WHERE exam_scope IS NULL";
        $result = $pdo->exec($updateSql);
        
        echo "<p style='color: blue;'>📝 업데이트된 레코드 수: " . $result . "개</p>";
    }
    
    // 최종 테이블 구조 확인
    echo "<h3>4. 최종 테이블 구조 확인</h3>";
    $stmt = $pdo->query("DESCRIBE mdl_alt42t_exam_dates");
    $finalColumns = $stmt->fetchAll();
    
    echo "<table border='1' style='border-collapse: collapse; margin: 10px 0;'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    
    foreach ($finalColumns as $column) {
        $rowStyle = ($column['Field'] === 'exam_scope') ? 'style="background-color: #ffffcc;"' : '';
        echo "<tr $rowStyle>";
        foreach ($column as $value) {
            echo "<td>" . htmlspecialchars($value) . "</td>";
        }
        echo "</tr>";
    }
    echo "</table>";
    
    // 샘플 데이터 조회
    echo "<h3>5. 현재 데이터 상태 확인</h3>";
    $stmt = $pdo->query("SELECT exam_date_id, start_date, end_date, math_date, status, exam_scope FROM mdl_alt42t_exam_dates ORDER BY created_at DESC LIMIT 5");
    $sampleData = $stmt->fetchAll();
    
    if (count($sampleData) > 0) {
        echo "<table border='1' style='border-collapse: collapse; margin: 10px 0;'>";
        echo "<tr><th>exam_date_id</th><th>start_date</th><th>end_date</th><th>math_date</th><th>status</th><th>exam_scope</th></tr>";
        
        foreach ($sampleData as $row) {
            echo "<tr>";
            foreach ($row as $value) {
                echo "<td>" . htmlspecialchars($value) . "</td>";
            }
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>현재 데이터가 없습니다.</p>";
    }
    
    echo "<h3 style='color: green;'>🎉 컬럼 추가 작업이 완료되었습니다!</h3>";
    echo "<p><strong>이제 시험 범위 정보가 DB에 저장되고 친구들의 정보에서 확인할 수 있습니다.</strong></p>";
    
} catch (Exception $e) {
    echo "<h3 style='color: red;'>❌ 오류 발생</h3>";
    echo "<p style='color: red;'>오류 메시지: " . $e->getMessage() . "</p>";
}
?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
table { border-collapse: collapse; width: 100%; margin: 10px 0; }
th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
th { background-color: #f2f2f2; }
h2 { color: #333; border-bottom: 2px solid #4CAF50; padding-bottom: 10px; }
h3 { color: #666; margin-top: 20px; }
</style>