<?php
header('Content-Type: application/json; charset=utf-8');

include_once("/home/moodle/public_html/moodle/config.php"); 
global $DB, $USER;
require_login();

// JSON 입력 데이터 받기
$input_raw = file_get_contents("php://input");
$input = json_decode($input_raw, true);

// 디버깅용 로그
error_log('save_to_all_tables.php - 받은 데이터: ' . $input_raw);

$userid = isset($input['userid']) ? intval($input['userid']) : $USER->id;
$section = isset($input['section']) ? intval($input['section']) : 0;

try {
    $now = time();
    $messages = [];
    
    // 트랜잭션 시작
    $transaction = $DB->start_delegated_transaction();
    
    if ($section === 0) {
        // Section 0: 기본 정보 (학교, 학년, 시험종류)
        
        // 1. alt42t_users 테이블에 저장
        $user_record = $DB->get_record('alt42t_users', array('userid' => $userid));
        
        if ($user_record) {
            // 업데이트
            $sql = "UPDATE {alt42t_users} 
                    SET name = ?, school_name = ?, grade = ?, timemodified = ? 
                    WHERE userid = ?";
            $params = [
                $USER->firstname . ' ' . $USER->lastname,
                trim($input['school']),
                intval($input['grade']),
                $now,
                $userid
            ];
            $DB->execute($sql, $params);
            $user_id = $user_record->id;
            $messages[] = "alt42t_users 업데이트 완료";
        } else {
            // 신규 삽입
            $user_data = new stdClass();
            $user_data->userid = $userid;
            $user_data->name = $USER->firstname . ' ' . $USER->lastname;
            $user_data->school_name = trim($input['school']);
            $user_data->grade = intval($input['grade']);
            $user_data->created_at = date('Y-m-d H:i:s');
            $user_data->timecreated = $now;
            $user_data->timemodified = $now;
            
            $user_id = $DB->insert_record('alt42t_users', $user_data);
            $messages[] = "alt42t_users 신규 생성 (ID: $user_id)";
        }
        
        // 2. alt42t_exams 테이블에 저장
        if (isset($input['examType'])) {
            $exam_type_map = [
                '1mid' => '1학기 중간고사',
                '1final' => '1학기 기말고사',
                '2mid' => '2학기 중간고사',
                '2final' => '2학기 기말고사'
            ];
            
            $exam_type_korean = $exam_type_map[$input['examType']] ?? $input['examType'];
            
            $exam_record = $DB->get_record('alt42t_exams', array(
                'school_name' => trim($input['school']),
                'grade' => intval($input['grade']),
                'exam_type' => $exam_type_korean
            ));
            
            if (!$exam_record) {
                // 시험 정보가 없으면 생성
                $exam_data = new stdClass();
                $exam_data->school_name = trim($input['school']);
                $exam_data->grade = intval($input['grade']);
                $exam_data->exam_type = $exam_type_korean;
                $exam_data->userid = $userid;
                $exam_data->timecreated = $now;
                $exam_data->timemodified = $now;
                
                $exam_id = $DB->insert_record('alt42t_exams', $exam_data);
                $messages[] = "alt42t_exams 신규 생성 (ID: $exam_id)";
            } else {
                $exam_id = $exam_record->id;
                // userid 업데이트
                $sql = "UPDATE {alt42t_exams} SET userid = ?, timemodified = ? WHERE id = ?";
                $DB->execute($sql, array($userid, $now, $exam_id));
                $messages[] = "alt42t_exams 업데이트 완료";
            }
        }
        
        // 3. alt42t_exam_user_info 테이블에도 저장 (호환성)
        $exam_info = $DB->get_record('alt42t_exam_user_info', array('userid' => $userid));
        
        if ($exam_info) {
            $info_data = new stdClass();
            $info_data->id = $exam_info->id;
            $info_data->school = trim($input['school']);
            $info_data->grade = strval($input['grade']);
            $info_data->exam_type = $input['examType'];
            $info_data->timemodified = $now;
            
            $DB->update_record('alt42t_exam_user_info', $info_data);
            $messages[] = "alt42t_exam_user_info 업데이트 완료";
        } else {
            $info_data = new stdClass();
            $info_data->userid = $userid;
            $info_data->school = trim($input['school']);
            $info_data->grade = strval($input['grade']);
            $info_data->exam_type = $input['examType'];
            $info_data->timecreated = $now;
            $info_data->timemodified = $now;
            
            $DB->insert_record('alt42t_exam_user_info', $info_data);
            $messages[] = "alt42t_exam_user_info 신규 생성";
        }
        
    } else if ($section === 1) {
        // Section 1: 시험 일정 저장
        
        // user_id와 exam_id 가져오기
        $user_record = $DB->get_record('alt42t_users', array('userid' => $userid));
        if (!$user_record) {
            throw new Exception('사용자 정보를 먼저 저장해주세요.');
        }
        
        $exam_info = $DB->get_record('alt42t_exam_user_info', array('userid' => $userid));
        if (!$exam_info) {
            throw new Exception('시험 정보를 먼저 설정해주세요.');
        }
        
        $exam_type_map = [
            '1mid' => '1학기 중간고사',
            '1final' => '1학기 기말고사',
            '2mid' => '2학기 중간고사',
            '2final' => '2학기 기말고사'
        ];
        
        $exam_type_korean = $exam_type_map[$exam_info->exam_type] ?? $exam_info->exam_type;
        
        $exam_record = $DB->get_record('alt42t_exams', array(
            'school_name' => $exam_info->school,
            'grade' => intval($exam_info->grade),
            'exam_type' => $exam_type_korean
        ));
        
        if (!$exam_record) {
            throw new Exception('시험 정보를 찾을 수 없습니다.');
        }
        
        // alt42t_exam_dates 테이블에 저장
        $date_record = $DB->get_record('alt42t_exam_dates', array(
            'exam_id' => $exam_record->id,
            'user_id' => $user_record->id
        ));
        
        if ($date_record) {
            // 업데이트
            $update_fields = [];
            $params = [];
            
            if (isset($input['startDate']) && !empty($input['startDate'])) {
                $update_fields[] = "start_date = ?";
                $params[] = $input['startDate'];
            }
            if (isset($input['endDate']) && !empty($input['endDate'])) {
                $update_fields[] = "end_date = ?";
                $params[] = $input['endDate'];
            }
            if (isset($input['mathDate']) && !empty($input['mathDate'])) {
                $update_fields[] = "math_date = ?";
                $params[] = $input['mathDate'];
            }
            if (isset($input['status'])) {
                $update_fields[] = "status = ?";
                $params[] = $input['status'];
            }
            
            $update_fields[] = "timemodified = ?";
            $params[] = $now;
            $params[] = $date_record->id;
            
            $sql = "UPDATE {alt42t_exam_dates} 
                    SET " . implode(", ", $update_fields) . " 
                    WHERE id = ?";
            $DB->execute($sql, $params);
            $messages[] = "alt42t_exam_dates 업데이트 완료";
        } else {
            // 신규 삽입
            $date_data = new stdClass();
            $date_data->exam_id = $exam_record->id;
            $date_data->user_id = $user_record->id;
            $date_data->start_date = $input['startDate'] ?? null;
            $date_data->end_date = $input['endDate'] ?? null;
            $date_data->math_date = $input['mathDate'] ?? null;
            $date_data->status = $input['status'] ?? '예상';
            $date_data->created_at = date('Y-m-d H:i:s');
            $date_data->userid = $userid;
            $date_data->timecreated = $now;
            $date_data->timemodified = $now;
            
            $DB->insert_record('alt42t_exam_dates', $date_data);
            $messages[] = "alt42t_exam_dates 신규 생성";
        }
        
        // alt42t_exam_user_info 테이블도 업데이트
        $info_update = clone $exam_info;
        if (isset($input['startDate'])) $info_update->exam_start_date = $input['startDate'];
        if (isset($input['endDate'])) $info_update->exam_end_date = $input['endDate'];
        if (isset($input['mathDate'])) $info_update->math_exam_date = $input['mathDate'];
        if (isset($input['status'])) $info_update->exam_status = $input['status'];
        if (isset($input['examScope'])) $info_update->exam_scope = $input['examScope'];
        $info_update->timemodified = $now;
        
        $DB->update_record('alt42t_exam_user_info', $info_update);
        $messages[] = "alt42t_exam_user_info 날짜 정보 업데이트";
        
    } else if ($section === 3) {
        // Section 3: 학습 상태 저장
        
        // user_id와 exam_id 가져오기
        $user_record = $DB->get_record('alt42t_users', array('userid' => $userid));
        if (!$user_record) {
            throw new Exception('사용자 정보를 먼저 저장해주세요.');
        }
        
        $exam_info = $DB->get_record('alt42t_exam_user_info', array('userid' => $userid));
        if (!$exam_info) {
            throw new Exception('시험 정보를 먼저 설정해주세요.');
        }
        
        $exam_type_map = [
            '1mid' => '1학기 중간고사',
            '1final' => '1학기 기말고사',
            '2mid' => '2학기 중간고사',
            '2final' => '2학기 기말고사'
        ];
        
        $exam_type_korean = $exam_type_map[$exam_info->exam_type] ?? $exam_info->exam_type;
        
        $exam_record = $DB->get_record('alt42t_exams', array(
            'school_name' => $exam_info->school,
            'grade' => intval($exam_info->grade),
            'exam_type' => $exam_type_korean
        ));
        
        if (!$exam_record) {
            throw new Exception('시험 정보를 찾을 수 없습니다.');
        }
        
        // alt42t_study_status 테이블에 저장
        $status_record = $DB->get_record('alt42t_study_status', array(
            'user_id' => $user_record->id,
            'exam_id' => $exam_record->id
        ));
        
        if ($status_record) {
            // 업데이트
            $sql = "UPDATE {alt42t_study_status} 
                    SET status = ?, timemodified = ? 
                    WHERE id = ?";
            $params = array($input['studyStatus'], $now, $status_record->id);
            $DB->execute($sql, $params);
            $messages[] = "alt42t_study_status 업데이트 완료";
        } else {
            // 신규 삽입
            $status_data = new stdClass();
            $status_data->user_id = $user_record->id;
            $status_data->exam_id = $exam_record->id;
            $status_data->status = $input['studyStatus'];
            $status_data->created_at = date('Y-m-d H:i:s');
            $status_data->userid = $userid;
            $status_data->timecreated = $now;
            $status_data->timemodified = $now;
            
            $DB->insert_record('alt42t_study_status', $status_data);
            $messages[] = "alt42t_study_status 신규 생성";
        }
        
        // alt42t_exam_user_info 테이블도 업데이트
        $info_update = clone $exam_info;
        $info_update->study_status = $input['studyStatus'];
        $info_update->timemodified = $now;
        
        $DB->update_record('alt42t_exam_user_info', $info_update);
        $messages[] = "alt42t_exam_user_info 학습 상태 업데이트";
    }
    
    // 트랜잭션 커밋
    $transaction->allow_commit();
    
    echo json_encode([
        'success' => true,
        'messages' => $messages,
        'message' => implode(', ', $messages)
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    $transaction->rollback($e);
    
    error_log('save_to_all_tables.php 오류: ' . $e->getMessage());
    error_log('Stack trace: ' . $e->getTraceAsString());
    
    echo json_encode([
        'success' => false,
        'message' => '저장 중 오류 발생: ' . $e->getMessage(),
        'error' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>