<?php
header('Content-Type: application/json; charset=utf-8');
ob_start();

include_once("/home/moodle/public_html/moodle/config.php");
global $DB, $USER;
require_login();

$response = array('success' => false);

try {
    // JSON 데이터 파싱
    $input = json_decode(file_get_contents('php://input'), true);
    
    $userid = $input['userid'] ?? 0;
    $field = $input['field'] ?? '';
    $value = $input['value'] ?? '';
    
    // 권한 확인
    if ($userid != $USER->id) {
        throw new Exception('권한이 없습니다');
    }
    
    // 기존 레코드 확인
    $existing = $DB->get_record('alt42t_exam_user_info', array('userid' => $userid));
    
    $data = new stdClass();
    $data->userid = $userid;
    $data->timemodified = time();
    
    // 필드별 업데이트
    if ($existing) {
        $data->id = $existing->id;
        $data->school = $existing->school;
        $data->grade = $existing->grade;
        $data->exam_type = $existing->exam_type;
        
        // 특정 필드만 업데이트
        switch($field) {
            case 'school':
                $data->school = $value;
                break;
            case 'grade':
                $data->grade = $value;
                break;
            case 'examType':
                $data->exam_type = $value;
                break;
        }
        
        $DB->update_record('alt42t_exam_user_info', $data);
    } else {
        // 새 레코드 생성
        $data->school = ($field === 'school') ? $value : '';
        $data->grade = ($field === 'grade') ? $value : '';
        $data->exam_type = ($field === 'examType') ? $value : '';
        $data->timecreated = time();
        
        $DB->insert_record('alt42t_exam_user_info', $data);
    }
    
    $response['success'] = true;
    $response['message'] = '정보가 저장되었습니다';
    
} catch (Exception $e) {
    $response['error'] = $e->getMessage();
    error_log('Save header info error: ' . $e->getMessage());
}

ob_clean();
echo json_encode($response, JSON_UNESCAPED_UNICODE);
?>