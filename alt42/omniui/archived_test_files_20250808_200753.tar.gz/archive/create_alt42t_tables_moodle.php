<?php
require_once('/home/moodle/public_html/moodle/config.php');
require_login();

global $DB;

// 관리자 권한 체크
$context = context_system::instance();
require_capability('moodle/site:config', $context);

$dbman = $DB->get_manager();

echo "<h2>alt42t 테이블 생성 (Moodle XMLdb 방식)</h2>";

// 테이블이 이미 존재하는지 체크하고 생성
$tables_to_create = [];

// 1. alt42t_users 테이블
$table = new xmldb_table('alt42t_users');
if (!$dbman->table_exists($table)) {
    $table->add_field('user_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
    $table->add_field('name', XMLDB_TYPE_CHAR, '50', null, null, null, null);
    $table->add_field('school_name', XMLDB_TYPE_CHAR, '100', null, XMLDB_NOTNULL, null, null);
    $table->add_field('grade', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, null);
    $table->add_field('created_at', XMLDB_TYPE_DATETIME, null, null, XMLDB_NOTNULL, null, null);
    $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
    $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
    $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
    
    $table->add_key('primary', XMLDB_KEY_PRIMARY, array('user_id'));
    $table->add_index('idx_school_grade', XMLDB_INDEX_NOTUNIQUE, array('school_name', 'grade'));
    $table->add_index('idx_userid', XMLDB_INDEX_NOTUNIQUE, array('userid'));
    
    $tables_to_create['alt42t_users'] = $table;
}

// 2. alt42t_exams 테이블
$table = new xmldb_table('alt42t_exams');
if (!$dbman->table_exists($table)) {
    $table->add_field('exam_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
    $table->add_field('school_name', XMLDB_TYPE_CHAR, '100', null, XMLDB_NOTNULL, null, null);
    $table->add_field('grade', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, null);
    $table->add_field('exam_type', XMLDB_TYPE_CHAR, '50', null, XMLDB_NOTNULL, null, null);
    $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
    $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
    $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
    
    $table->add_key('primary', XMLDB_KEY_PRIMARY, array('exam_id'));
    $table->add_index('idx_school_grade', XMLDB_INDEX_NOTUNIQUE, array('school_name', 'grade'));
    $table->add_index('idx_userid', XMLDB_INDEX_NOTUNIQUE, array('userid'));
    
    $tables_to_create['alt42t_exams'] = $table;
}

// 3. alt42t_exam_dates 테이블
$table = new xmldb_table('alt42t_exam_dates');
if (!$dbman->table_exists($table)) {
    $table->add_field('exam_date_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
    $table->add_field('exam_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('user_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('start_date', XMLDB_TYPE_CHAR, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('end_date', XMLDB_TYPE_CHAR, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('math_date', XMLDB_TYPE_CHAR, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('status', XMLDB_TYPE_CHAR, '10', null, XMLDB_NOTNULL, null, '예상');
    $table->add_field('created_at', XMLDB_TYPE_DATETIME, null, null, XMLDB_NOTNULL, null, null);
    $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
    $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
    $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
    
    $table->add_key('primary', XMLDB_KEY_PRIMARY, array('exam_date_id'));
    $table->add_key('fk_exam_id', XMLDB_KEY_FOREIGN, array('exam_id'), 'alt42t_exams', array('exam_id'));
    $table->add_key('fk_user_id', XMLDB_KEY_FOREIGN, array('user_id'), 'alt42t_users', array('user_id'));
    
    $tables_to_create['alt42t_exam_dates'] = $table;
}

// 4. alt42t_study_status 테이블
$table = new xmldb_table('alt42t_study_status');
if (!$dbman->table_exists($table)) {
    $table->add_field('status_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
    $table->add_field('user_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('exam_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('status', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, null);
    $table->add_field('created_at', XMLDB_TYPE_DATETIME, null, null, XMLDB_NOTNULL, null, null);
    $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
    $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
    $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
    
    $table->add_key('primary', XMLDB_KEY_PRIMARY, array('status_id'));
    $table->add_key('fk_user_id', XMLDB_KEY_FOREIGN, array('user_id'), 'alt42t_users', array('user_id'));
    $table->add_key('fk_exam_id', XMLDB_KEY_FOREIGN, array('exam_id'), 'alt42t_exams', array('exam_id'));
    
    $tables_to_create['alt42t_study_status'] = $table;
}

// 5. alt42t_exam_resources 테이블
$table = new xmldb_table('alt42t_exam_resources');
if (!$dbman->table_exists($table)) {
    $table->add_field('resource_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
    $table->add_field('exam_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('user_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('file_url', XMLDB_TYPE_CHAR, '255', null, null, null, null);
    $table->add_field('tip_text', XMLDB_TYPE_TEXT, null, null, null, null, null);
    $table->add_field('created_at', XMLDB_TYPE_DATETIME, null, null, XMLDB_NOTNULL, null, null);
    $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
    $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
    $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
    
    $table->add_key('primary', XMLDB_KEY_PRIMARY, array('resource_id'));
    $table->add_key('fk_exam_id', XMLDB_KEY_FOREIGN, array('exam_id'), 'alt42t_exams', array('exam_id'));
    $table->add_key('fk_user_id', XMLDB_KEY_FOREIGN, array('user_id'), 'alt42t_users', array('user_id'));
    
    $tables_to_create['alt42t_exam_resources'] = $table;
}

// 6. alt42t_aggregated_resources 테이블
$table = new xmldb_table('alt42t_aggregated_resources');
if (!$dbman->table_exists($table)) {
    $table->add_field('aggregated_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
    $table->add_field('exam_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('compiled_file_urls', XMLDB_TYPE_TEXT, null, null, null, null, null);
    $table->add_field('compiled_tips', XMLDB_TYPE_TEXT, null, null, null, null, null);
    $table->add_field('last_updated', XMLDB_TYPE_DATETIME, null, null, XMLDB_NOTNULL, null, null);
    $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
    $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
    $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
    
    $table->add_key('primary', XMLDB_KEY_PRIMARY, array('aggregated_id'));
    $table->add_key('fk_exam_id', XMLDB_KEY_FOREIGN, array('exam_id'), 'alt42t_exams', array('exam_id'));
    
    $tables_to_create['alt42t_aggregated_resources'] = $table;
}

// 테이블 생성
if (count($tables_to_create) > 0) {
    echo "<h3>생성할 테이블:</h3>";
    echo "<ul>";
    foreach ($tables_to_create as $table_name => $table) {
        echo "<li>mdl_$table_name</li>";
    }
    echo "</ul>";
    
    if (optional_param('confirm', '', PARAM_TEXT) === 'yes') {
        echo "<h3>테이블 생성 중...</h3>";
        
        foreach ($tables_to_create as $table_name => $table) {
            try {
                $dbman->create_table($table);
                echo "<p style='color:green;'>✓ mdl_$table_name 테이블 생성 완료</p>";
            } catch (Exception $e) {
                echo "<p style='color:red;'>✗ mdl_$table_name 테이블 생성 실패: " . $e->getMessage() . "</p>";
            }
        }
        
        echo "<p>테이블 생성 작업이 완료되었습니다.</p>";
    } else {
        echo '<form method="post">';
        echo '<input type="hidden" name="confirm" value="yes">';
        echo '<button type="submit" style="background:#4CAF50;color:white;padding:10px;">테이블 생성 실행</button>';
        echo '</form>';
    }
} else {
    echo "<p style='color:green;'>모든 테이블이 이미 존재합니다.</p>";
}

// 현재 테이블 상태 확인
echo "<h3>현재 테이블 상태</h3>";
$tables = ['alt42t_users', 'alt42t_exams', 'alt42t_exam_dates', 'alt42t_study_status', 'alt42t_exam_resources', 'alt42t_aggregated_resources'];

echo "<table border='1' style='border-collapse:collapse;'>";
echo "<tr><th>테이블명</th><th>존재여부</th><th>레코드 수</th></tr>";
foreach ($tables as $table_name) {
    $table = new xmldb_table($table_name);
    $exists = $dbman->table_exists($table);
    $color = $exists ? 'green' : 'red';
    $status = $exists ? '✓ 존재' : '✗ 없음';
    
    echo "<tr>";
    echo "<td>mdl_$table_name</td>";
    echo "<td style='color:$color;'>$status</td>";
    
    if ($exists) {
        try {
            $count = $DB->count_records($table_name);
            echo "<td>$count</td>";
        } catch (Exception $e) {
            echo "<td style='color:red;'>오류</td>";
        }
    } else {
        echo "<td>-</td>";
    }
    echo "</tr>";
}
echo "</table>";

echo "<hr>";
echo '<p><a href="test_alt42t_tables.php" style="padding:10px;background:#2196F3;color:white;text-decoration:none;border-radius:5px;">테이블 데이터 확인</a></p>';
echo '<p><a href="index.php" style="padding:10px;background:#FF9800;color:white;text-decoration:none;border-radius:5px;">메인 페이지로</a></p>';
?>