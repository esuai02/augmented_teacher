<?php
header('Content-Type: application/json; charset=utf-8');

include_once("/home/moodle/public_html/moodle/config.php"); 
global $DB, $USER;
require_login();

// JSON 입력 데이터 받기
$input = json_decode(file_get_contents("php://input"), true);

// 디버깅용 로그
error_log('save_user_exam_info.php - 받은 데이터: ' . json_encode($input));

// userid 확인
$userid = isset($input['userid']) ? intval($input['userid']) : $USER->id;

try {
    // 기존 레코드 확인
    $existing = $DB->get_record('alt42t_exam_user_info', array('userid' => $userid));
    
    $now = time();
    
    // 데이터 준비
    $data = new stdClass();
    $data->userid = $userid;
    
    // 기본 정보만 저장 (학교, 학년, 시험유형)
    if (isset($input['school'])) {
        $data->school = trim($input['school']);
    }
    if (isset($input['grade'])) {
        // grade를 문자열로 저장 (테이블 구조상 CHAR(50))
        $data->grade = strval($input['grade']);
    }
    if (isset($input['examType'])) {
        $data->exam_type = trim($input['examType']);
    }
    
    if ($existing) {
        // 업데이트
        $data->id = $existing->id;
        $data->timemodified = $now;
        
        // 기존 데이터 유지 (새 데이터로만 덮어쓰기)
        foreach ($existing as $key => $value) {
            if (!isset($data->$key) && $key != 'id' && $key != 'timemodified') {
                $data->$key = $value;
            }
        }
        
        error_log('업데이트할 데이터: ' . json_encode($data));
        $DB->update_record('alt42t_exam_user_info', $data);
        $message = "정보가 업데이트되었습니다.";
    } else {
        // 신규 생성
        $data->timecreated = $now;
        $data->timemodified = $now;
        
        error_log('삽입할 데이터: ' . json_encode($data));
        $id = $DB->insert_record('alt42t_exam_user_info', $data);
        $message = "정보가 저장되었습니다. (ID: $id)";
    }
    
    echo json_encode([
        'success' => true,
        'message' => $message,
        'data' => [
            'userid' => $userid,
            'school' => $data->school ?? '',
            'grade' => $data->grade ?? '',
            'examType' => $data->exam_type ?? ''
        ]
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => '저장 중 오류 발생: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>