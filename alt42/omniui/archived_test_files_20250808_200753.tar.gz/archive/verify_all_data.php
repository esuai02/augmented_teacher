<?php
header('Content-Type: text/html; charset=utf-8');

include_once("/home/moodle/public_html/moodle/config.php"); 
global $DB, $USER;
require_login();
?>
<!DOCTYPE html>
<html>
<head>
    <title>전체 데이터 확인</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .table-section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; background: #f9f9f9; }
        .success { color: green; }
        .error { color: red; }
        .data { background: white; padding: 10px; margin: 10px 0; border-radius: 5px; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background: #e0e0e0; }
    </style>
</head>
<body>
    <h1>ALT42 전체 데이터 확인</h1>
    <p>현재 사용자: <?php echo $USER->firstname . ' ' . $USER->lastname . ' (ID: ' . $USER->id . ')'; ?></p>
    
    <?php
    // 1. alt42t_users 확인
    echo "<div class='table-section'>";
    echo "<h2>1. alt42t_users (사용자 정보)</h2>";
    $user_data = $DB->get_record('alt42t_users', array('userid' => $USER->id));
    if ($user_data) {
        echo "<div class='data success'>";
        echo "✓ 데이터 있음<br>";
        echo "- ID: {$user_data->id}<br>";
        echo "- 이름: {$user_data->name}<br>";
        echo "- 학교: <strong>{$user_data->school_name}</strong><br>";
        echo "- 학년: <strong>{$user_data->grade}</strong><br>";
        echo "</div>";
    } else {
        echo "<div class='data error'>✗ 데이터 없음</div>";
    }
    echo "</div>";
    
    // 2. alt42t_exam_user_info 확인
    echo "<div class='table-section'>";
    echo "<h2>2. alt42t_exam_user_info (통합 정보)</h2>";
    $exam_info = $DB->get_record('alt42t_exam_user_info', array('userid' => $USER->id));
    if ($exam_info) {
        echo "<div class='data success'>";
        echo "✓ 데이터 있음<br>";
        echo "- 학교: <strong>{$exam_info->school}</strong><br>";
        echo "- 학년: <strong>{$exam_info->grade}</strong><br>";
        echo "- 시험종류: <strong>{$exam_info->exam_type}</strong><br>";
        echo "- 시험시작일: <strong>" . ($exam_info->exam_start_date ?? '미설정') . "</strong><br>";
        echo "- 시험종료일: <strong>" . ($exam_info->exam_end_date ?? '미설정') . "</strong><br>";
        echo "- 수학시험일: <strong>" . ($exam_info->math_exam_date ?? '미설정') . "</strong><br>";
        echo "- 시험범위: <strong>" . ($exam_info->exam_scope ?? '미설정') . "</strong><br>";
        echo "- 시험상태: <strong>" . ($exam_info->exam_status ?? '미설정') . "</strong><br>";
        echo "- 학습상태: <strong>" . ($exam_info->study_status ?? '미설정') . "</strong><br>";
        echo "</div>";
    } else {
        echo "<div class='data error'>✗ 데이터 없음</div>";
    }
    echo "</div>";
    
    // 3. alt42t_exams 확인
    if ($exam_info) {
        echo "<div class='table-section'>";
        echo "<h2>3. alt42t_exams (시험 정의)</h2>";
        
        $exam_type_map = [
            '1mid' => '1학기 중간고사',
            '1final' => '1학기 기말고사',
            '2mid' => '2학기 중간고사',
            '2final' => '2학기 기말고사'
        ];
        
        $exam_type_korean = $exam_type_map[$exam_info->exam_type] ?? $exam_info->exam_type;
        
        $exam = $DB->get_record('alt42t_exams', array(
            'school_name' => $exam_info->school,
            'grade' => intval($exam_info->grade),
            'exam_type' => $exam_type_korean
        ));
        
        if ($exam) {
            echo "<div class='data success'>";
            echo "✓ 시험 정의 있음<br>";
            echo "- Exam ID: {$exam->id}<br>";
            echo "- 학교: {$exam->school_name}<br>";
            echo "- 학년: {$exam->grade}<br>";
            echo "- 시험종류: <strong>{$exam->exam_type}</strong><br>";
            echo "</div>";
        } else {
            echo "<div class='data error'>✗ 시험 정의 없음</div>";
        }
        echo "</div>";
        
        // 4. alt42t_exam_dates 확인
        if ($user_data && $exam) {
            echo "<div class='table-section'>";
            echo "<h2>4. alt42t_exam_dates (시험 일정)</h2>";
            
            $exam_date = $DB->get_record('alt42t_exam_dates', array(
                'exam_id' => $exam->id,
                'user_id' => $user_data->id
            ));
            
            if ($exam_date) {
                echo "<div class='data success'>";
                echo "✓ 시험 일정 있음<br>";
                echo "- 시작일: <strong>{$exam_date->start_date}</strong><br>";
                echo "- 종료일: <strong>{$exam_date->end_date}</strong><br>";
                echo "- 수학시험일: <strong>{$exam_date->math_date}</strong><br>";
                echo "- 상태: <strong>{$exam_date->status}</strong><br>";
                echo "</div>";
            } else {
                echo "<div class='data error'>✗ 시험 일정 없음</div>";
            }
            echo "</div>";
            
            // 5. alt42t_study_status 확인
            echo "<div class='table-section'>";
            echo "<h2>5. alt42t_study_status (학습 상태)</h2>";
            
            $study_status = $DB->get_record('alt42t_study_status', array(
                'user_id' => $user_data->id,
                'exam_id' => $exam->id
            ));
            
            if ($study_status) {
                echo "<div class='data success'>";
                echo "✓ 학습 상태 있음<br>";
                echo "- 상태: <strong>{$study_status->status}</strong><br>";
                echo "</div>";
            } else {
                echo "<div class='data error'>✗ 학습 상태 없음</div>";
            }
            echo "</div>";
        }
    }
    
    // 전체 데이터 요약
    echo "<div class='table-section' style='background: #e6f3ff;'>";
    echo "<h2>데이터 요약</h2>";
    
    $tables = [
        'alt42t_users',
        'alt42t_exams', 
        'alt42t_exam_dates',
        'alt42t_exam_user_info',
        'alt42t_study_status',
        'alt42t_exam_resources',
        'alt42t_aggregated_resources'
    ];
    
    echo "<table>";
    echo "<tr><th>테이블</th><th>전체 레코드</th><th>현재 사용자 관련</th></tr>";
    
    foreach ($tables as $table) {
        $total = $DB->count_records($table);
        $user_count = 0;
        
        if (in_array($table, ['alt42t_users', 'alt42t_exam_user_info'])) {
            $user_count = $DB->count_records($table, array('userid' => $USER->id));
        }
        
        echo "<tr>";
        echo "<td>$table</td>";
        echo "<td>$total</td>";
        echo "<td>" . ($user_count > 0 ? "<span class='success'>$user_count</span>" : "-") . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    echo "</div>";
    ?>
    
    <div style="margin-top: 30px; padding: 20px; background: #f0f0f0;">
        <h3>디버깅 정보</h3>
        <p>서버 시간: <?php echo date('Y-m-d H:i:s'); ?></p>
        <p>타임존: <?php echo date_default_timezone_get(); ?></p>
        <p>로그 파일을 확인하여 save_to_all_tables.php의 실행 로그를 확인하세요.</p>
    </div>
</body>
</html>