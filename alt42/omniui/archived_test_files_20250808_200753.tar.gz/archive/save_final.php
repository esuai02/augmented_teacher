<?php
// 모든 출력 버퍼 정리
while (ob_get_level()) {
    ob_end_clean();
}

// 에러 로그만 활성화
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// JSON 헤더 설정
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, must-revalidate');

// 응답 초기화
$response = array('success' => false, 'message' => '처리 실패');

try {
    // Moodle 설정 로드
    require_once('/home/moodle/public_html/moodle/config.php');
    global $DB, $USER;
    
    // 로그인 확인
    if (!isloggedin() || isguestuser()) {
        $response['message'] = '로그인이 필요합니다';
        die(json_encode($response, JSON_UNESCAPED_UNICODE));
    }
    
    // POST 데이터 받기
    $input = json_decode(file_get_contents("php://input"), true);
    if (!$input) {
        $response['message'] = '입력 데이터가 없습니다';
        die(json_encode($response, JSON_UNESCAPED_UNICODE));
    }
    
    $userid = $USER->id;
    $section = isset($input['section']) ? intval($input['section']) : 0;
    
    // 섹션별 처리
    switch ($section) {
        case 0: // 기본 정보
            // alt42t_exam_user_info에 저장
            $existing = $DB->get_record('alt42t_exam_user_info', array('userid' => $userid));
            
            if ($existing) {
                // 업데이트
                $existing->school = $input['school'] ?? $existing->school;
                $existing->grade = $input['grade'] ?? $existing->grade;
                $existing->exam_type = $input['examType'] ?? $existing->exam_type;
                $existing->timemodified = time();
                
                $DB->update_record('alt42t_exam_user_info', $existing);
                $response = array(
                    'success' => true,
                    'message' => '기본 정보가 업데이트되었습니다',
                    'action' => 'update'
                );
            } else {
                // 신규 생성
                $data = new stdClass();
                $data->userid = $userid;
                $data->school = $input['school'] ?? '';
                $data->grade = $input['grade'] ?? '';
                $data->exam_type = $input['examType'] ?? '';
                $data->timecreated = time();
                $data->timemodified = time();
                
                $newid = $DB->insert_record('alt42t_exam_user_info', $data);
                $response = array(
                    'success' => true,
                    'message' => '기본 정보가 저장되었습니다',
                    'action' => 'insert',
                    'id' => $newid
                );
            }
            
            // alt42t_users 테이블에도 저장
            if ($DB->get_manager()->table_exists(new xmldb_table('alt42t_users'))) {
                $alt_user = $DB->get_record('alt42t_users', array('userid' => $userid));
                
                if ($alt_user) {
                    $alt_user->username = $USER->username;
                    $alt_user->email = $USER->email;
                    $alt_user->school = $input['school'] ?? '';
                    $alt_user->grade = $input['grade'] ?? '';
                    $alt_user->updated_at = date('Y-m-d H:i:s');
                    
                    $DB->update_record('alt42t_users', $alt_user);
                } else {
                    $alt_user = new stdClass();
                    $alt_user->userid = $userid;
                    $alt_user->username = $USER->username;
                    $alt_user->email = $USER->email;
                    $alt_user->school = $input['school'] ?? '';
                    $alt_user->grade = $input['grade'] ?? '';
                    $alt_user->created_at = date('Y-m-d H:i:s');
                    $alt_user->updated_at = date('Y-m-d H:i:s');
                    
                    $DB->insert_record('alt42t_users', $alt_user);
                }
            }
            break;
            
        case 1: // 시험 일정
            $existing = $DB->get_record('alt42t_exam_user_info', array('userid' => $userid));
            
            if (!$existing) {
                $response['message'] = '기본 정보를 먼저 저장해주세요';
            } else {
                // exam_user_info 업데이트
                if (isset($input['startDate'])) $existing->exam_start_date = $input['startDate'];
                if (isset($input['endDate'])) $existing->exam_end_date = $input['endDate'];
                if (isset($input['mathDate'])) $existing->math_exam_date = $input['mathDate'];
                if (isset($input['status'])) $existing->exam_status = $input['status'];
                if (isset($input['examScope'])) $existing->exam_scope = $input['examScope'];
                $existing->timemodified = time();
                
                $DB->update_record('alt42t_exam_user_info', $existing);
                
                // alt42t_exams 테이블에도 저장
                if ($DB->get_manager()->table_exists(new xmldb_table('alt42t_exams'))) {
                    $exam_name = $existing->exam_type ?? '정기고사';
                    $exam = $DB->get_record('alt42t_exams', array(
                        'userid' => $userid,
                        'exam_name' => $exam_name
                    ));
                    
                    if ($exam) {
                        $exam->start_date = $input['startDate'] ?? null;
                        $exam->end_date = $input['endDate'] ?? null;
                        $exam->status = $input['status'] ?? 'scheduled';
                        $exam->updated_at = date('Y-m-d H:i:s');
                        
                        $DB->update_record('alt42t_exams', $exam);
                    } else {
                        $exam = new stdClass();
                        $exam->userid = $userid;
                        $exam->exam_name = $exam_name;
                        $exam->start_date = $input['startDate'] ?? null;
                        $exam->end_date = $input['endDate'] ?? null;
                        $exam->status = $input['status'] ?? 'scheduled';
                        $exam->created_at = date('Y-m-d H:i:s');
                        $exam->updated_at = date('Y-m-d H:i:s');
                        
                        $DB->insert_record('alt42t_exams', $exam);
                    }
                }
                
                $response = array(
                    'success' => true,
                    'message' => '시험 일정이 저장되었습니다'
                );
            }
            break;
            
        case 3: // 학습 상태
            $existing = $DB->get_record('alt42t_exam_user_info', array('userid' => $userid));
            
            if (!$existing) {
                $response['message'] = '기본 정보를 먼저 저장해주세요';
            } else {
                $existing->study_status = $input['studyStatus'] ?? '';
                $existing->timemodified = time();
                
                $DB->update_record('alt42t_exam_user_info', $existing);
                
                // alt42t_study_status 테이블에도 저장
                if ($DB->get_manager()->table_exists(new xmldb_table('alt42t_study_status'))) {
                    $study = $DB->get_record('alt42t_study_status', array('userid' => $userid));
                    
                    if ($study) {
                        $study->status = $input['studyStatus'] ?? 'active';
                        $study->updated_at = date('Y-m-d H:i:s');
                        
                        $DB->update_record('alt42t_study_status', $study);
                    } else {
                        $study = new stdClass();
                        $study->userid = $userid;
                        $study->status = $input['studyStatus'] ?? 'active';
                        $study->created_at = date('Y-m-d H:i:s');
                        $study->updated_at = date('Y-m-d H:i:s');
                        
                        $DB->insert_record('alt42t_study_status', $study);
                    }
                }
                
                $response = array(
                    'success' => true,
                    'message' => '학습 상태가 저장되었습니다'
                );
            }
            break;
            
        default:
            $response['message'] = '잘못된 섹션 번호입니다';
    }
    
} catch (Exception $e) {
    error_log('save_final.php 오류: ' . $e->getMessage());
    error_log('save_final.php 스택: ' . $e->getTraceAsString());
    $response = array(
        'success' => false,
        'message' => '저장 중 오류가 발생했습니다: ' . $e->getMessage(),
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    );
}

// JSON 출력
echo json_encode($response, JSON_UNESCAPED_UNICODE);
exit;