<?php
require_once('/home/moodle/public_html/moodle/config.php');
require_login();

global $DB;

// 관리자 권한 체크
$context = context_system::instance();
require_capability('moodle/site:config', $context);

$dbman = $DB->get_manager();

echo "<h2>alt42t 테이블 생성 스크립트</h2>";

// 1. alt42t_exam_user_info 테이블 (메인 테이블)
$table1 = new xmldb_table('alt42t_exam_user_info');
if (!$dbman->table_exists($table1)) {
    $table1->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
    $table1->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table1->add_field('school', XMLDB_TYPE_CHAR, '255', null, null, null, null);
    $table1->add_field('grade', XMLDB_TYPE_CHAR, '10', null, null, null, null);
    $table1->add_field('exam_type', XMLDB_TYPE_CHAR, '50', null, null, null, null);
    $table1->add_field('exam_start_date', XMLDB_TYPE_CHAR, '10', null, null, null, null);
    $table1->add_field('exam_end_date', XMLDB_TYPE_CHAR, '10', null, null, null, null);
    $table1->add_field('math_exam_date', XMLDB_TYPE_CHAR, '10', null, null, null, null);
    $table1->add_field('exam_scope', XMLDB_TYPE_TEXT, null, null, null, null, null);
    $table1->add_field('exam_status', XMLDB_TYPE_CHAR, '20', null, null, null, 'expected');
    $table1->add_field('study_status', XMLDB_TYPE_CHAR, '50', null, null, null, null);
    $table1->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table1->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
    
    $table1->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
    $table1->add_key('userid_fk', XMLDB_KEY_FOREIGN, array('userid'), 'user', array('id'));
    $table1->add_index('userid_idx', XMLDB_INDEX_NOTUNIQUE, array('userid'));
    
    $dbman->create_table($table1);
    echo "<p style='color:green;'>✓ alt42t_exam_user_info 테이블 생성 완료</p>";
} else {
    echo "<p>alt42t_exam_user_info 테이블은 이미 존재합니다.</p>";
}

// 2. alt42t_users 테이블
$table2 = new xmldb_table('alt42t_users');
if (!$dbman->table_exists($table2)) {
    $table2->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
    $table2->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table2->add_field('name', XMLDB_TYPE_CHAR, '255', null, null, null, null);
    $table2->add_field('school_name', XMLDB_TYPE_CHAR, '255', null, null, null, null);
    $table2->add_field('grade', XMLDB_TYPE_INTEGER, '2', null, null, null, null);
    $table2->add_field('created_at', XMLDB_TYPE_DATETIME, null, null, null, null, null);
    $table2->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
    $table2->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
    
    $table2->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
    $table2->add_key('userid_fk', XMLDB_KEY_FOREIGN, array('userid'), 'user', array('id'));
    $table2->add_index('userid_idx', XMLDB_INDEX_NOTUNIQUE, array('userid'));
    
    $dbman->create_table($table2);
    echo "<p style='color:green;'>✓ alt42t_users 테이블 생성 완료</p>";
} else {
    echo "<p>alt42t_users 테이블은 이미 존재합니다.</p>";
}

// 3. alt42t_exams 테이블
$table3 = new xmldb_table('alt42t_exams');
if (!$dbman->table_exists($table3)) {
    $table3->add_field('exam_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
    $table3->add_field('school_name', XMLDB_TYPE_CHAR, '255', null, null, null, null);
    $table3->add_field('grade', XMLDB_TYPE_INTEGER, '2', null, null, null, null);
    $table3->add_field('exam_type', XMLDB_TYPE_CHAR, '50', null, null, null, null);
    $table3->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
    $table3->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
    $table3->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
    
    $table3->add_key('primary', XMLDB_KEY_PRIMARY, array('exam_id'));
    $table3->add_index('school_grade_idx', XMLDB_INDEX_NOTUNIQUE, array('school_name', 'grade'));
    
    $dbman->create_table($table3);
    echo "<p style='color:green;'>✓ alt42t_exams 테이블 생성 완료</p>";
} else {
    echo "<p>alt42t_exams 테이블은 이미 존재합니다.</p>";
}

// 4. alt42t_exam_dates 테이블
$table4 = new xmldb_table('alt42t_exam_dates');
if (!$dbman->table_exists($table4)) {
    $table4->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
    $table4->add_field('exam_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table4->add_field('user_id', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
    $table4->add_field('exam_scope', XMLDB_TYPE_TEXT, null, null, null, null, null);
    $table4->add_field('start_date', XMLDB_TYPE_CHAR, '10', null, null, null, null);
    $table4->add_field('end_date', XMLDB_TYPE_CHAR, '10', null, null, null, null);
    $table4->add_field('math_date', XMLDB_TYPE_CHAR, '10', null, null, null, null);
    $table4->add_field('status', XMLDB_TYPE_CHAR, '20', null, null, null, null);
    $table4->add_field('created_at', XMLDB_TYPE_DATETIME, null, null, null, null, null);
    $table4->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
    $table4->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
    $table4->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
    
    $table4->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
    $table4->add_key('exam_fk', XMLDB_KEY_FOREIGN, array('exam_id'), 'alt42t_exams', array('exam_id'));
    
    $dbman->create_table($table4);
    echo "<p style='color:green;'>✓ alt42t_exam_dates 테이블 생성 완료</p>";
} else {
    echo "<p>alt42t_exam_dates 테이블은 이미 존재합니다.</p>";
}

// 5. alt42t_study_status 테이블
$table5 = new xmldb_table('alt42t_study_status');
if (!$dbman->table_exists($table5)) {
    $table5->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
    $table5->add_field('user_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table5->add_field('exam_id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table5->add_field('status', XMLDB_TYPE_CHAR, '50', null, null, null, null);
    $table5->add_field('created_at', XMLDB_TYPE_DATETIME, null, null, null, null, null);
    $table5->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
    $table5->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
    $table5->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
    
    $table5->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
    $table5->add_key('exam_fk', XMLDB_KEY_FOREIGN, array('exam_id'), 'alt42t_exams', array('exam_id'));
    
    $dbman->create_table($table5);
    echo "<p style='color:green;'>✓ alt42t_study_status 테이블 생성 완료</p>";
} else {
    echo "<p>alt42t_study_status 테이블은 이미 존재합니다.</p>";
}

// 6. alt42t_exam_resources 테이블
$table6 = new xmldb_table('alt42t_exam_resources');
if (!$dbman->table_exists($table6)) {
    $table6->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
    $table6->add_field('school', XMLDB_TYPE_CHAR, '255', null, null, null, null);
    $table6->add_field('grade', XMLDB_TYPE_INTEGER, '2', null, null, null, null);
    $table6->add_field('exam_type', XMLDB_TYPE_CHAR, '50', null, null, null, null);
    $table6->add_field('resource_type', XMLDB_TYPE_CHAR, '20', null, null, null, null);
    $table6->add_field('content', XMLDB_TYPE_TEXT, null, null, null, null, null);
    $table6->add_field('file_url', XMLDB_TYPE_CHAR, '500', null, null, null, null);
    $table6->add_field('uploaded_by', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
    $table6->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
    
    $table6->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
    $table6->add_index('school_grade_exam_idx', XMLDB_INDEX_NOTUNIQUE, array('school', 'grade', 'exam_type'));
    
    $dbman->create_table($table6);
    echo "<p style='color:green;'>✓ alt42t_exam_resources 테이블 생성 완료</p>";
} else {
    echo "<p>alt42t_exam_resources 테이블은 이미 존재합니다.</p>";
}

// 7. alt42t_aggregated_resources 테이블
$table7 = new xmldb_table('alt42t_aggregated_resources');
if (!$dbman->table_exists($table7)) {
    $table7->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
    $table7->add_field('school', XMLDB_TYPE_CHAR, '255', null, null, null, null);
    $table7->add_field('grade', XMLDB_TYPE_INTEGER, '2', null, null, null, null);
    $table7->add_field('exam_type', XMLDB_TYPE_CHAR, '50', null, null, null, null);
    $table7->add_field('aggregated_data', XMLDB_TYPE_TEXT, null, null, null, null, null);
    $table7->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
    $table7->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
    
    $table7->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
    $table7->add_index('school_grade_exam_idx', XMLDB_INDEX_NOTUNIQUE, array('school', 'grade', 'exam_type'));
    
    $dbman->create_table($table7);
    echo "<p style='color:green;'>✓ alt42t_aggregated_resources 테이블 생성 완료</p>";
} else {
    echo "<p>alt42t_aggregated_resources 테이블은 이미 존재합니다.</p>";
}

echo "<hr>";
echo "<h3>테이블 생성 완료!</h3>";
echo "<p>모든 필요한 테이블이 확인/생성되었습니다.</p>";
echo '<p><a href="check_db_structure.php">테이블 구조 확인하기</a></p>';
echo '<p><a href="index.php">메인 페이지로 돌아가기</a></p>';
?>