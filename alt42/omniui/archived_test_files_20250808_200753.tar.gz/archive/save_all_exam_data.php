<?php
header('Content-Type: application/json; charset=utf-8');

include_once("/home/moodle/public_html/moodle/config.php"); 
global $DB, $USER;
require_login();

// JSON 입력 데이터 받기
$input = json_decode(file_get_contents("php://input"), true);

// 디버깅용 로그
error_log('save_all_exam_data.php - 받은 데이터: ' . json_encode($input));

// userid 확인
$userid = isset($input['userid']) ? intval($input['userid']) : $USER->id;
$section = isset($input['section']) ? intval($input['section']) : 0;

try {
    $DB->execute("START TRANSACTION");
    
    $now = time();
    $response_data = array();
    
    // Section 0: 기본 정보 저장 (mdl_alt42t_users 테이블)
    if ($section === 0 || isset($input['school']) || isset($input['grade'])) {
        // 1. mdl_alt42t_users에 사용자 정보 저장/업데이트
        $user_record = $DB->get_record('alt42t_users', array('userid' => $userid));
        
        $user_data = new stdClass();
        $user_data->userid = $userid;
        $user_data->name = $USER->firstname . ' ' . $USER->lastname;
        $user_data->school_name = isset($input['school']) ? trim($input['school']) : '';
        $user_data->grade = isset($input['grade']) ? intval($input['grade']) : 0;
        
        if ($user_record) {
            // 업데이트 - Moodle은 'id' 필드를 기대하지만 우리 테이블은 'user_id'를 사용
            // 직접 SQL 사용
            $sql = "UPDATE {alt42t_users} 
                    SET name = ?, school_name = ?, grade = ?, timemodified = ? 
                    WHERE user_id = ?";
            $params = array($user_data->name, $user_data->school_name, $user_data->grade, $now, $user_record->user_id);
            $DB->execute($sql, $params);
            $user_id = $user_record->user_id;
        } else {
            // 신규 생성
            $user_data->created_at = date('Y-m-d H:i:s');
            $user_data->timecreated = $now;
            $user_data->timemodified = $now;
            $user_id = $DB->insert_record('alt42t_users', $user_data);
        }
        
        $response_data['user_id'] = $user_id;
        
        // 2. mdl_alt42t_exams에 시험 정보 저장/업데이트
        if (isset($input['examType']) && !empty($input['school']) && !empty($input['grade'])) {
            $exam_type_map = array(
                '1mid' => '1학기 중간고사',
                '1final' => '1학기 기말고사',
                '2mid' => '2학기 중간고사',
                '2final' => '2학기 기말고사'
            );
            
            $exam_type_korean = isset($exam_type_map[$input['examType']]) ? 
                                $exam_type_map[$input['examType']] : 
                                $input['examType'];
            
            // 시험 정보 확인
            $exam_record = $DB->get_record('alt42t_exams', array(
                'school_name' => trim($input['school']),
                'grade' => intval($input['grade']),
                'exam_type' => $exam_type_korean
            ));
            
            $exam_data = new stdClass();
            $exam_data->school_name = trim($input['school']);
            $exam_data->grade = intval($input['grade']);
            $exam_data->exam_type = $exam_type_korean;
            $exam_data->userid = $userid;
            
            if ($exam_record) {
                // 업데이트 - 직접 SQL 사용
                $sql = "UPDATE {alt42t_exams} 
                        SET timemodified = ?, userid = ? 
                        WHERE exam_id = ?";
                $params = array($now, $userid, $exam_record->exam_id);
                $DB->execute($sql, $params);
                $exam_id = $exam_record->exam_id;
            } else {
                // 신규 생성
                $exam_data->timecreated = $now;
                $exam_data->timemodified = $now;
                $exam_id = $DB->insert_record('alt42t_exams', $exam_data);
            }
            
            $response_data['exam_id'] = $exam_id;
        }
        
        // 3. mdl_alt42t_exam_user_info에도 저장 (기존 호환성 유지)
        $exam_info = $DB->get_record('alt42t_exam_user_info', array('userid' => $userid));
        
        $info_data = new stdClass();
        $info_data->userid = $userid;
        $info_data->school = isset($input['school']) ? trim($input['school']) : '';
        $info_data->grade = isset($input['grade']) ? strval($input['grade']) : '';
        $info_data->exam_type = isset($input['examType']) ? trim($input['examType']) : '';
        
        if ($exam_info) {
            $info_data->id = $exam_info->id;
            $info_data->timemodified = $now;
            $DB->update_record('alt42t_exam_user_info', $info_data);
        } else {
            $info_data->timecreated = $now;
            $info_data->timemodified = $now;
            $DB->insert_record('alt42t_exam_user_info', $info_data);
        }
    }
    
    // Section 1: 시험 일정 저장 (mdl_alt42t_exam_dates 테이블)
    if ($section === 1 && (isset($input['startDate']) || isset($input['endDate']) || isset($input['mathDate']))) {
        // user_id와 exam_id 가져오기
        $user_record = $DB->get_record('alt42t_users', array('userid' => $userid));
        if (!$user_record) {
            throw new Exception('사용자 정보를 먼저 저장해주세요.');
        }
        $user_id = $user_record->user_id;
        
        // 현재 설정된 시험 정보 가져오기
        $exam_info = $DB->get_record('alt42t_exam_user_info', array('userid' => $userid));
        if (!$exam_info || empty($exam_info->school) || empty($exam_info->grade) || empty($exam_info->exam_type)) {
            throw new Exception('시험 정보를 먼저 설정해주세요.');
        }
        
        $exam_type_map = array(
            '1mid' => '1학기 중간고사',
            '1final' => '1학기 기말고사',
            '2mid' => '2학기 중간고사',
            '2final' => '2학기 기말고사'
        );
        
        $exam_type_korean = isset($exam_type_map[$exam_info->exam_type]) ? 
                            $exam_type_map[$exam_info->exam_type] : 
                            $exam_info->exam_type;
        
        $exam_record = $DB->get_record('alt42t_exams', array(
            'school_name' => $exam_info->school,
            'grade' => intval($exam_info->grade),
            'exam_type' => $exam_type_korean
        ));
        
        if (!$exam_record) {
            throw new Exception('시험 정보를 찾을 수 없습니다.');
        }
        $exam_id = $exam_record->exam_id;
        
        // 시험 일정 저장/업데이트
        $date_record = $DB->get_record('alt42t_exam_dates', array(
            'exam_id' => $exam_id,
            'user_id' => $user_id
        ));
        
        $date_data = new stdClass();
        $date_data->exam_id = $exam_id;
        $date_data->user_id = $user_id;
        $date_data->userid = $userid;
        
        if (isset($input['startDate'])) {
            $date_data->start_date = $input['startDate'];
        }
        if (isset($input['endDate'])) {
            $date_data->end_date = $input['endDate'];
        }
        if (isset($input['mathDate'])) {
            $date_data->math_date = $input['mathDate'];
        }
        if (isset($input['status'])) {
            $date_data->status = $input['status'];
        }
        
        if ($date_record) {
            // 업데이트 - 직접 SQL 사용
            $update_fields = array();
            $params = array();
            
            if (isset($date_data->start_date)) {
                $update_fields[] = "start_date = ?";
                $params[] = $date_data->start_date;
            }
            if (isset($date_data->end_date)) {
                $update_fields[] = "end_date = ?";
                $params[] = $date_data->end_date;
            }
            if (isset($date_data->math_date)) {
                $update_fields[] = "math_date = ?";
                $params[] = $date_data->math_date;
            }
            if (isset($date_data->status)) {
                $update_fields[] = "status = ?";
                $params[] = $date_data->status;
            }
            
            $update_fields[] = "timemodified = ?";
            $params[] = $now;
            $params[] = $date_record->exam_date_id;
            
            if (!empty($update_fields)) {
                $sql = "UPDATE {alt42t_exam_dates} 
                        SET " . implode(", ", $update_fields) . " 
                        WHERE exam_date_id = ?";
                $DB->execute($sql, $params);
            }
        } else {
            $date_data->created_at = date('Y-m-d H:i:s');
            $date_data->timecreated = $now;
            $date_data->timemodified = $now;
            $DB->insert_record('alt42t_exam_dates', $date_data);
        }
        
        // exam_user_info 테이블도 업데이트
        if (isset($input['examScope'])) {
            $info_update = new stdClass();
            $info_update->id = $exam_info->id;
            $info_update->exam_scope = $input['examScope'];
            $info_update->exam_start_date = isset($input['startDate']) ? $input['startDate'] : null;
            $info_update->exam_end_date = isset($input['endDate']) ? $input['endDate'] : null;
            $info_update->math_exam_date = isset($input['mathDate']) ? $input['mathDate'] : null;
            $info_update->exam_status = isset($input['status']) ? $input['status'] : null;
            $info_update->timemodified = $now;
            $DB->update_record('alt42t_exam_user_info', $info_update);
        }
    }
    
    // Section 3: 학습 상태 저장 (mdl_alt42t_study_status 테이블)
    if ($section === 3 && isset($input['studyStatus'])) {
        // user_id와 exam_id 가져오기
        $user_record = $DB->get_record('alt42t_users', array('userid' => $userid));
        if (!$user_record) {
            throw new Exception('사용자 정보를 먼저 저장해주세요.');
        }
        $user_id = $user_record->user_id;
        
        $exam_info = $DB->get_record('alt42t_exam_user_info', array('userid' => $userid));
        if (!$exam_info || empty($exam_info->school) || empty($exam_info->grade) || empty($exam_info->exam_type)) {
            throw new Exception('시험 정보를 먼저 설정해주세요.');
        }
        
        $exam_type_map = array(
            '1mid' => '1학기 중간고사',
            '1final' => '1학기 기말고사',
            '2mid' => '2학기 중간고사',
            '2final' => '2학기 기말고사'
        );
        
        $exam_type_korean = isset($exam_type_map[$exam_info->exam_type]) ? 
                            $exam_type_map[$exam_info->exam_type] : 
                            $exam_info->exam_type;
        
        $exam_record = $DB->get_record('alt42t_exams', array(
            'school_name' => $exam_info->school,
            'grade' => intval($exam_info->grade),
            'exam_type' => $exam_type_korean
        ));
        
        if (!$exam_record) {
            throw new Exception('시험 정보를 찾을 수 없습니다.');
        }
        $exam_id = $exam_record->exam_id;
        
        // 학습 상태 저장/업데이트
        $status_record = $DB->get_record('alt42t_study_status', array(
            'user_id' => $user_id,
            'exam_id' => $exam_id
        ));
        
        $status_data = new stdClass();
        $status_data->user_id = $user_id;
        $status_data->exam_id = $exam_id;
        $status_data->status = $input['studyStatus'];
        $status_data->userid = $userid;
        
        if ($status_record) {
            // 업데이트 - 직접 SQL 사용
            $sql = "UPDATE {alt42t_study_status} 
                    SET status = ?, timemodified = ? 
                    WHERE status_id = ?";
            $params = array($status_data->status, $now, $status_record->status_id);
            $DB->execute($sql, $params);
        } else {
            $status_data->created_at = date('Y-m-d H:i:s');
            $status_data->timecreated = $now;
            $status_data->timemodified = $now;
            $DB->insert_record('alt42t_study_status', $status_data);
        }
        
        // exam_user_info 테이블도 업데이트
        $info_update = new stdClass();
        $info_update->id = $exam_info->id;
        $info_update->study_status = $input['studyStatus'];
        $info_update->timemodified = $now;
        $DB->update_record('alt42t_exam_user_info', $info_update);
    }
    
    $DB->execute("COMMIT");
    
    echo json_encode([
        'success' => true,
        'message' => '정보가 저장되었습니다.',
        'data' => $response_data
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    $DB->execute("ROLLBACK");
    
    error_log('save_all_exam_data.php 오류: ' . $e->getMessage());
    
    echo json_encode([
        'success' => false,
        'message' => '저장 중 오류 발생: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>