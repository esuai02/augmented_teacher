<?php
require_once('/home/moodle/public_html/moodle/config.php');
require_login();

global $DB;

// 관리자 권한 체크
$context = context_system::instance();
require_capability('moodle/site:config', $context);

$dbman = $DB->get_manager();

// 테이블 정의
$table = new xmldb_table('alt42t_exam_user_info');

// 필드 추가
$table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
$table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
$table->add_field('school', XMLDB_TYPE_CHAR, '255', null, null, null, null);
$table->add_field('grade', XMLDB_TYPE_INTEGER, '2', null, null, null, null);
$table->add_field('exam_type', XMLDB_TYPE_CHAR, '50', null, null, null, null);
$table->add_field('exam_start_date', XMLDB_TYPE_CHAR, '10', null, null, null, null);
$table->add_field('exam_end_date', XMLDB_TYPE_CHAR, '10', null, null, null, null);
$table->add_field('math_exam_date', XMLDB_TYPE_CHAR, '10', null, null, null, null);
$table->add_field('exam_scope', XMLDB_TYPE_TEXT, null, null, null, null, null);
$table->add_field('exam_status', XMLDB_TYPE_CHAR, '20', null, null, null, 'expected');
$table->add_field('study_status', XMLDB_TYPE_CHAR, '50', null, null, null, null);
$table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
$table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, null, null, null);

// 키 추가
$table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
$table->add_key('userid_fk', XMLDB_KEY_FOREIGN, array('userid'), 'user', array('id'));

// 인덱스 추가
$table->add_index('userid_idx', XMLDB_INDEX_NOTUNIQUE, array('userid'));
$table->add_index('school_grade_idx', XMLDB_INDEX_NOTUNIQUE, array('school', 'grade'));
$table->add_index('exam_type_idx', XMLDB_INDEX_NOTUNIQUE, array('exam_type'));

// 테이블 생성
if (!$dbman->table_exists($table)) {
    $dbman->create_table($table);
    echo "테이블 'alt42t_exam_user_info'가 성공적으로 생성되었습니다.<br>";
} else {
    echo "테이블 'alt42t_exam_user_info'가 이미 존재합니다.<br>";
}

// 테이블 구조 확인
$columns = $DB->get_columns('alt42t_exam_user_info');
echo "<h3>테이블 구조:</h3>";
echo "<table border='1'>";
echo "<tr><th>컬럼명</th><th>타입</th><th>Null 허용</th></tr>";
foreach ($columns as $column) {
    echo "<tr>";
    echo "<td>{$column->name}</td>";
    echo "<td>{$column->type}</td>";
    echo "<td>" . ($column->not_null ? 'NO' : 'YES') . "</td>";
    echo "</tr>";
}
echo "</table>";
?>