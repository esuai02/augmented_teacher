<?php
// 모든 출력 지우기
while (ob_get_level()) {
    ob_end_clean();
}

// 에러 로그 활성화
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// JSON 헤더
header('Content-Type: application/json; charset=utf-8');

// 디버깅용 로그
error_log('save_debug.php 시작');

// 기본 응답
$response = array(
    'success' => false,
    'message' => '처리 실패',
    'debug' => array()
);

try {
    // 1. Moodle 포함
    error_log('Moodle config 포함 시도');
    require_once('/home/moodle/public_html/moodle/config.php');
    global $DB, $USER;
    
    $response['debug']['moodle_loaded'] = true;
    
    // 2. 로그인 확인
    error_log('로그인 확인');
    if (!isloggedin()) {
        $response['message'] = '로그인이 필요합니다';
        $response['debug']['logged_in'] = false;
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    if (isguestuser()) {
        $response['message'] = '게스트는 저장할 수 없습니다';
        $response['debug']['is_guest'] = true;
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    $response['debug']['logged_in'] = true;
    $response['debug']['user_id'] = $USER->id;
    
    // 3. 입력 데이터
    $input_raw = file_get_contents("php://input");
    error_log('입력 데이터: ' . $input_raw);
    
    $input = json_decode($input_raw, true);
    if (!$input) {
        $response['message'] = '입력 데이터가 없거나 잘못되었습니다';
        $response['debug']['input_raw'] = $input_raw;
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    $response['debug']['input_received'] = true;
    $response['debug']['section'] = $input['section'] ?? 'none';
    
    // 4. 테이블 확인
    error_log('테이블 확인');
    $dbman = $DB->get_manager();
    $table = new xmldb_table('alt42t_exam_user_info');
    
    if (!$dbman->table_exists($table)) {
        $response['message'] = 'alt42t_exam_user_info 테이블이 없습니다';
        $response['debug']['table_exists'] = false;
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    $response['debug']['table_exists'] = true;
    
    // 5. 섹션 0 처리 (기본 정보)
    $section = isset($input['section']) ? intval($input['section']) : 0;
    
    if ($section === 0) {
        error_log('섹션 0 처리 시작');
        
        // 기존 데이터 확인
        $existing = $DB->get_record('alt42t_exam_user_info', array('userid' => $USER->id));
        
        if ($existing) {
            // UPDATE
            error_log('기존 데이터 업데이트');
            $existing->school = $input['school'] ?? $existing->school;
            $existing->grade = $input['grade'] ?? $existing->grade;
            $existing->exam_type = $input['examType'] ?? $existing->exam_type;
            $existing->timemodified = time();
            
            $DB->update_record('alt42t_exam_user_info', $existing);
            
            $response['success'] = true;
            $response['message'] = '기본 정보가 업데이트되었습니다';
            $response['debug']['action'] = 'update';
            $response['debug']['record_id'] = $existing->id;
        } else {
            // INSERT
            error_log('새 데이터 생성');
            $data = new stdClass();
            $data->userid = $USER->id;
            $data->school = $input['school'] ?? '';
            $data->grade = $input['grade'] ?? '';
            $data->exam_type = $input['examType'] ?? '';
            $data->timecreated = time();
            $data->timemodified = time();
            
            $newid = $DB->insert_record('alt42t_exam_user_info', $data);
            
            $response['success'] = true;
            $response['message'] = '기본 정보가 저장되었습니다';
            $response['debug']['action'] = 'insert';
            $response['debug']['new_id'] = $newid;
        }
        
        // 저장된 데이터 확인
        $saved = $DB->get_record('alt42t_exam_user_info', array('userid' => $USER->id));
        $response['debug']['saved_data'] = array(
            'school' => $saved->school,
            'grade' => $saved->grade,
            'exam_type' => $saved->exam_type
        );
    } else {
        $response['message'] = "섹션 {$section}은 아직 구현되지 않았습니다";
    }
    
} catch (Exception $e) {
    error_log('save_debug.php 오류: ' . $e->getMessage());
    error_log('save_debug.php 스택: ' . $e->getTraceAsString());
    
    $response = array(
        'success' => false,
        'message' => '오류: ' . $e->getMessage(),
        'debug' => array(
            'error' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine()
        )
    );
}

// 결과 출력
error_log('응답: ' . json_encode($response, JSON_UNESCAPED_UNICODE));
echo json_encode($response, JSON_UNESCAPED_UNICODE);
exit;
?>