<?php
// 출력 버퍼 초기화
ob_start();

try {
    // Moodle 설정
    require_once('/home/moodle/public_html/moodle/config.php');
    global $DB, $USER;
    
    // 세션 체크
    if (!isloggedin() || isguestuser()) {
        ob_clean();
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array(
            'success' => false,
            'message' => '로그인이 필요합니다'
        ), JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    // POST 데이터
    $input = json_decode(file_get_contents("php://input"), true);
    
    if (!$input) {
        ob_clean();
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array(
            'success' => false,
            'message' => '입력 데이터가 없습니다'
        ), JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    $section = isset($input['section']) ? intval($input['section']) : 0;
    
    // 섹션별 처리
    if ($section == 0) {
        // 기본 정보 저장
        
        // 1. alt42t_exam_user_info 테이블 (이미 id가 primary key)
        $existing = $DB->get_record('alt42t_exam_user_info', array('userid' => $USER->id));
        
        if ($existing) {
            $existing->school = $input['school'] ?? $existing->school;
            $existing->grade = $input['grade'] ?? $existing->grade;
            $existing->exam_type = $input['examType'] ?? $existing->exam_type;
            $existing->timemodified = time();
            
            $DB->update_record('alt42t_exam_user_info', $existing);
        } else {
            $record = new stdClass();
            $record->userid = $USER->id;
            $record->school = $input['school'] ?? '';
            $record->grade = $input['grade'] ?? '';
            $record->exam_type = $input['examType'] ?? '';
            $record->timecreated = time();
            $record->timemodified = time();
            
            $DB->insert_record('alt42t_exam_user_info', $record);
        }
        
        // 2. alt42t_users 테이블
        $sql = "SELECT * FROM {alt42t_users} WHERE userid = ?";
        $user_record = $DB->get_record_sql($sql, array($USER->id));
        
        if ($user_record) {
            // UPDATE
            $sql = "UPDATE {alt42t_users} 
                    SET school_name = ?, grade = ?, timemodified = ?
                    WHERE userid = ?";
            $DB->execute($sql, array(
                $input['school'] ?? '',
                intval($input['grade'] ?? 1),
                time(),
                $USER->id
            ));
        } else {
            // INSERT
            $sql = "INSERT INTO {alt42t_users} 
                    (userid, name, school_name, grade, created_at, timecreated, timemodified)
                    VALUES (?, ?, ?, ?, NOW(), ?, ?)";
            $DB->execute($sql, array(
                $USER->id,
                $USER->firstname . ' ' . $USER->lastname,
                $input['school'] ?? '',
                intval($input['grade'] ?? 1),
                time(),
                time()
            ));
        }
        
        // 3. alt42t_exams 테이블
        $exam_type_map = array(
            '1mid' => '1학기 중간고사',
            '1final' => '1학기 기말고사',
            '2mid' => '2학기 중간고사',
            '2final' => '2학기 기말고사'
        );
        
        $exam_type_korean = $exam_type_map[$input['examType']] ?? '1학기 중간고사';
        
        $sql = "SELECT * FROM {alt42t_exams} WHERE userid = ? AND exam_type = ?";
        $exam_record = $DB->get_record_sql($sql, array($USER->id, $exam_type_korean));
        
        if (!$exam_record) {
            $sql = "INSERT INTO {alt42t_exams} 
                    (school_name, grade, exam_type, userid, timecreated, timemodified)
                    VALUES (?, ?, ?, ?, ?, ?)";
            $DB->execute($sql, array(
                $input['school'] ?? '',
                intval($input['grade'] ?? 1),
                $exam_type_korean,
                $USER->id,
                time(),
                time()
            ));
        }
        
        $response = array(
            'success' => true,
            'message' => '기본 정보가 저장되었습니다'
        );
        
    } else if ($section == 1) {
        // 시험 일정 저장
        $existing = $DB->get_record('alt42t_exam_user_info', array('userid' => $USER->id));
        
        if (!$existing) {
            $response = array(
                'success' => false,
                'message' => '기본 정보를 먼저 저장해주세요'
            );
        } else {
            // alt42t_exam_user_info 업데이트
            if (isset($input['startDate'])) $existing->exam_start_date = $input['startDate'];
            if (isset($input['endDate'])) $existing->exam_end_date = $input['endDate'];
            if (isset($input['mathDate'])) $existing->math_exam_date = $input['mathDate'];
            if (isset($input['status'])) $existing->exam_status = $input['status'];
            if (isset($input['examScope'])) $existing->exam_scope = $input['examScope'];
            $existing->timemodified = time();
            
            $DB->update_record('alt42t_exam_user_info', $existing);
            
            // alt42t_exam_dates 테이블에도 저장
            // 먼저 exam_id 찾기
            $sql = "SELECT exam_id FROM {alt42t_exams} WHERE userid = ? ORDER BY exam_id DESC LIMIT 1";
            $exam = $DB->get_record_sql($sql, array($USER->id));
            
            if ($exam) {
                $sql = "SELECT * FROM {alt42t_exam_dates} WHERE user_id = ? AND exam_id = ?";
                $exam_date = $DB->get_record_sql($sql, array($USER->id, $exam->exam_id));
                
                if ($exam_date) {
                    // UPDATE
                    $sql = "UPDATE {alt42t_exam_dates} 
                            SET start_date = ?, end_date = ?, math_date = ?, 
                                status = ?, exam_scope = ?, timemodified = ?
                            WHERE user_id = ? AND exam_id = ?";
                    $DB->execute($sql, array(
                        $input['startDate'] ?? date('Y-m-d'),
                        $input['endDate'] ?? date('Y-m-d'),
                        $input['mathDate'] ?? date('Y-m-d'),
                        $input['status'] ?? '예상',
                        $input['examScope'] ?? '',
                        time(),
                        $USER->id,
                        $exam->exam_id
                    ));
                } else {
                    // INSERT
                    $sql = "INSERT INTO {alt42t_exam_dates} 
                            (exam_id, user_id, exam_scope, start_date, end_date, math_date, 
                             status, created_at, userid, timecreated, timemodified)
                            VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), ?, ?, ?)";
                    $DB->execute($sql, array(
                        $exam->exam_id,
                        $USER->id,
                        $input['examScope'] ?? '',
                        $input['startDate'] ?? date('Y-m-d'),
                        $input['endDate'] ?? date('Y-m-d'),
                        $input['mathDate'] ?? date('Y-m-d'),
                        $input['status'] ?? '예상',
                        $USER->id,
                        time(),
                        time()
                    ));
                }
            }
            
            $response = array(
                'success' => true,
                'message' => '시험 일정이 저장되었습니다'
            );
        }
        
    } else if ($section == 3) {
        // 학습 상태 저장
        $existing = $DB->get_record('alt42t_exam_user_info', array('userid' => $USER->id));
        
        if (!$existing) {
            $response = array(
                'success' => false,
                'message' => '기본 정보를 먼저 저장해주세요'
            );
        } else {
            $existing->study_status = $input['studyStatus'] ?? '';
            $existing->timemodified = time();
            
            $DB->update_record('alt42t_exam_user_info', $existing);
            
            // alt42t_study_status 테이블에도 저장
            $sql = "SELECT exam_id FROM {alt42t_exams} WHERE userid = ? ORDER BY exam_id DESC LIMIT 1";
            $exam = $DB->get_record_sql($sql, array($USER->id));
            
            if ($exam) {
                $sql = "SELECT * FROM {alt42t_study_status} WHERE user_id = ? AND exam_id = ?";
                $status = $DB->get_record_sql($sql, array($USER->id, $exam->exam_id));
                
                if ($status) {
                    // UPDATE
                    $sql = "UPDATE {alt42t_study_status} 
                            SET status = ?, timemodified = ?
                            WHERE user_id = ? AND exam_id = ?";
                    $DB->execute($sql, array(
                        $input['studyStatus'] ?? '진행중',
                        time(),
                        $USER->id,
                        $exam->exam_id
                    ));
                } else {
                    // INSERT
                    $sql = "INSERT INTO {alt42t_study_status} 
                            (user_id, exam_id, status, created_at, userid, timecreated, timemodified)
                            VALUES (?, ?, ?, NOW(), ?, ?, ?)";
                    $DB->execute($sql, array(
                        $USER->id,
                        $exam->exam_id,
                        $input['studyStatus'] ?? '진행중',
                        $USER->id,
                        time(),
                        time()
                    ));
                }
            }
            
            $response = array(
                'success' => true,
                'message' => '학습 상태가 저장되었습니다'
            );
        }
    } else {
        $response = array(
            'success' => false,
            'message' => '잘못된 섹션입니다: ' . $section
        );
    }
    
} catch (Exception $e) {
    error_log('save_custom.php 오류: ' . $e->getMessage());
    $response = array(
        'success' => false,
        'message' => '오류: ' . $e->getMessage()
    );
}

// 출력
ob_clean();
header('Content-Type: application/json; charset=utf-8');
echo json_encode($response, JSON_UNESCAPED_UNICODE);
exit;
?>