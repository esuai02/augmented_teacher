<?php
header('Content-Type: application/json; charset=utf-8');

include_once("/home/moodle/public_html/moodle/config.php"); 
global $DB, $USER;
require_login();

// JSON 입력 데이터 받기
$input_raw = file_get_contents("php://input");
$input = json_decode($input_raw, true);

// 디버깅용 로그
error_log('save_exam_data_simple.php - Raw input: ' . $input_raw);
error_log('save_exam_data_simple.php - Decoded data: ' . json_encode($input));
error_log('save_exam_data_simple.php - Current user ID: ' . $USER->id);

// 입력 데이터 검증
if (!$input) {
    echo json_encode([
        'success' => false,
        'message' => '입력 데이터가 없습니다',
        'raw_input' => $input_raw
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// 테이블 존재 확인
$dbman = $DB->get_manager();
$table = new xmldb_table('alt42t_exam_user_info');
if (!$dbman->table_exists($table)) {
    error_log('ERROR: alt42t_exam_user_info 테이블이 존재하지 않습니다!');
    echo json_encode([
        'success' => false,
        'message' => 'alt42t_exam_user_info 테이블이 존재하지 않습니다'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// userid 확인
$userid = isset($input['userid']) ? intval($input['userid']) : $USER->id;
$section = isset($input['section']) ? intval($input['section']) : 0;

error_log('save_exam_data_simple.php - Using userid: ' . $userid . ', section: ' . $section);

// 섹션별 필수 필드 검증
$requiredFields = [];
if ($section === 0) {
    $requiredFields = ['school', 'grade', 'examType'];
} else if ($section === 1) {
    $requiredFields = ['startDate', 'endDate'];
}

foreach ($requiredFields as $field) {
    if (!isset($input[$field]) || empty(trim($input[$field]))) {
        echo json_encode([
            'success' => false,
            'message' => "필수 필드가 누락되었습니다: $field",
            'missing_field' => $field,
            'received_data' => $input
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

try {
    $now = time();
    
    // Section별 처리
    if ($section === 0) {
        // 기본 정보 저장 (학교, 학년, 시험종류)
        // mdl_alt42t_exam_user_info 테이블에만 저장 (기존 방식 유지)
        $existing = $DB->get_record('alt42t_exam_user_info', array('userid' => $userid));
        
        $data = new stdClass();
        $data->userid = $userid;
        
        if (isset($input['school'])) {
            $data->school = trim($input['school']);
        }
        if (isset($input['grade'])) {
            $data->grade = strval($input['grade']);
        }
        if (isset($input['examType'])) {
            $data->exam_type = trim($input['examType']);
        }
        
        if ($existing) {
            $data->id = $existing->id;
            $data->timemodified = $now;
            
            error_log('Section 0 UPDATE - Before: ' . json_encode($existing));
            error_log('Section 0 UPDATE - Data to save: ' . json_encode($data));
            
            $DB->update_record('alt42t_exam_user_info', $data);
            $message = "기본 정보가 업데이트되었습니다.";
            
            // 저장 후 확인
            $after = $DB->get_record('alt42t_exam_user_info', array('id' => $existing->id));
            error_log('Section 0 UPDATE - After: ' . json_encode($after));
        } else {
            $data->timecreated = $now;
            $data->timemodified = $now;
            
            error_log('Section 0 INSERT - Data to save: ' . json_encode($data));
            
            $newid = $DB->insert_record('alt42t_exam_user_info', $data);
            $message = "기본 정보가 저장되었습니다. (ID: $newid)";
            
            // 저장 후 확인
            $after = $DB->get_record('alt42t_exam_user_info', array('id' => $newid));
            error_log('Section 0 INSERT - After: ' . json_encode($after));
        }
        
    } else if ($section === 1) {
        // 시험 일정 저장
        $exam_info = $DB->get_record('alt42t_exam_user_info', array('userid' => $userid));
        
        if (!$exam_info) {
            throw new Exception('기본 정보를 먼저 저장해주세요.');
        }
        
        // 기존 데이터를 복사하고 새 데이터로 덮어쓰기
        $data = clone $exam_info;
        
        if (isset($input['startDate']) && !empty($input['startDate'])) {
            $data->exam_start_date = $input['startDate'];
        }
        if (isset($input['endDate']) && !empty($input['endDate'])) {
            $data->exam_end_date = $input['endDate'];
        }
        if (isset($input['mathDate']) && !empty($input['mathDate'])) {
            $data->math_exam_date = $input['mathDate'];
        }
        if (isset($input['status'])) {
            $data->exam_status = $input['status'];
        }
        if (isset($input['examScope'])) {
            $data->exam_scope = $input['examScope'];
        }
        
        $data->timemodified = $now;
        
        error_log('Section 1 업데이트 데이터: ' . json_encode($data));
        
        $DB->update_record('alt42t_exam_user_info', $data);
        $message = "시험 일정이 저장되었습니다.";
        
    } else if ($section === 3) {
        // 학습 상태 저장
        $exam_info = $DB->get_record('alt42t_exam_user_info', array('userid' => $userid));
        
        if (!$exam_info) {
            throw new Exception('기본 정보를 먼저 저장해주세요.');
        }
        
        // 기존 데이터를 복사하고 새 데이터로 덮어쓰기
        $data = clone $exam_info;
        $data->study_status = $input['studyStatus'];
        $data->timemodified = $now;
        
        error_log('Section 3 업데이트 데이터: ' . json_encode($data));
        
        $DB->update_record('alt42t_exam_user_info', $data);
        $message = "학습 상태가 저장되었습니다.";
        
    } else {
        $message = "알 수 없는 섹션입니다.";
    }
    
    // 저장 후 검증
    $saved_data = $DB->get_record('alt42t_exam_user_info', array('userid' => $userid));
    
    echo json_encode([
        'success' => true,
        'message' => $message,
        'saved_data' => $saved_data,
        'section' => $section
    ], JSON_UNESCAPED_UNICODE);
    
} catch (dml_exception $e) {
    // Moodle 데이터베이스 관련 오류
    error_log('save_exam_data_simple.php DB 오류: ' . $e->getMessage());
    error_log('오류 코드: ' . $e->errorcode);
    error_log('디버그 정보: ' . $e->debuginfo);
    
    echo json_encode([
        'success' => false,
        'message' => '데이터베이스 오류: ' . $e->getMessage(),
        'errorcode' => $e->errorcode,
        'debuginfo' => $e->debuginfo
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    error_log('save_exam_data_simple.php 일반 오류: ' . $e->getMessage());
    
    echo json_encode([
        'success' => false,
        'message' => '저장 중 오류 발생: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>