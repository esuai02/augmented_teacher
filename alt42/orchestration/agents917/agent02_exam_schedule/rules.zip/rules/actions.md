# Agent 02 - Exam Schedule Actions

## 수행 가능한 액션 목록

### 일정 관리
- `schedule_exam_preparation`: 시험 대비 일정 생성
- `adjust_timeline`: 타임라인 조정
- `set_priority`: 우선순위 설정

### 전략 제안
- `recommend_study_strategy`: 학습 전략 추천
- `suggest_focus_areas`: 집중 영역 제안
- `create_review_plan`: 복습 계획 생성

### 알림/리마인더
- `send_exam_reminder`: 시험 리마인더 발송
- `alert_urgency`: 긴급도 알림

### 리소스 제안
- `recommend_materials`: 학습 자료 추천
- `suggest_practice_tests`: 모의고사 제안

