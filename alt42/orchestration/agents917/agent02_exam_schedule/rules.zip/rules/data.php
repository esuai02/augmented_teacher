<?php
/**
 * Agent 02 - Exam Schedule Data Provider
 * File: agent02_exam_schedule/rules/data.php
 * 
 * 데이터 소스:
 * - mdl_alt42_exam_schedule: 시험 일정 테이블 (userid, exam_date, d_day, exam_name, target_score 등) ✅ 존재 확인됨
 * - mdl_user: 학생 기본 정보 ✅ 존재 확인됨
 * 
 * TODO: 다음 데이터 소스가 필요합니다:
 * - 학사 일정/코스 캘린더: Moodle 코스 일정 데이터 연동 필요
 * - 과목 공지: 코스 내 공지사항 데이터 연동 필요
 * - 최근 범위 업데이트: 시험 범위 변경 이력 수집 로직 필요
 */

include_once("/home/moodle/public_html/moodle/config.php");
global $DB, $USER;
require_login();

/**
 * 시험 일정 데이터 수집
 * 
 * @param int $studentid 학생 ID
 * @return array 시험 일정 컨텍스트 데이터
 */
function getExamScheduleContext($studentid) {
    global $DB;
    
    $context = [
        'student_id' => $studentid,
        'upcoming_exams' => [],
        'exam_urgency' => null,
        'exam_subjects' => [],
        'd_day' => null
    ];
    
    try {
        // 시험 일정 조회 (mdl_alt42_exam_schedule 테이블)
        $examSchedule = $DB->get_record('mdl_alt42_exam_schedule', ['userid' => $studentid], '*', IGNORE_MISSING);
        
        if ($examSchedule) {
            $today = time();
            $examDate = isset($examSchedule->exam_date) ? $examSchedule->exam_date : null;
            
            if ($examDate) {
                $d_day = floor(($examDate - $today) / 86400);
                $context['upcoming_exams'][] = [
                    'exam_name' => $examSchedule->exam_name ?? '',
                    'exam_date' => $examDate,
                    'd_day' => $d_day,
                    'target_score' => $examSchedule->target_score ?? null
                ];
                $context['d_day'] = $d_day;
                $context['exam_urgency'] = $d_day <= 3 ? 'urgent' : ($d_day <= 10 ? 'moderate' : 'normal');
            }
        }
        
    } catch (Exception $e) {
        error_log("Error in getExamScheduleContext: " . $e->getMessage() . " [File: " . __FILE__ . ", Line: " . __LINE__ . "]");
    }
    
    return $context;
}

/**
 * 룰 평가를 위한 컨텍스트 준비
 */
function prepareRuleContext($studentid) {
    $context = getExamScheduleContext($studentid);
    $context['timestamp'] = date('Y-m-d\TH:i:s\Z');
    return $context;
}
